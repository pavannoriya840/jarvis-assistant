package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.util.Log
import com.jarvis.assistant.data.AppDatabase
import kotlinx.coroutines.*

/**
 * INSTAGRAM AUTOMATOR 📸
 *
 * - Like reels: feed scroll karo, like karo, aage badho
 * - Smart comments: reel dekh ke relevant comment likho
 * - Post reel: video select → caption → post
 *
 * SAFETY (account ban se bachao!):
 * - Human-like delays (har action ke beech 8-20 sec)
 * - Daily limits: max 200 likes, 30 comments (configurable)
 * - Random breaks: har 20 actions ke baad 2-5 min ka break
 */
class InstagramAutomator(private val context: Context) {

    companion object {
        const val MAX_LIKES_PER_DAY = 200
        const val MAX_COMMENTS_PER_DAY = 30
    }

    private val prefs get() =
        context.getSharedPreferences("jarvis_insta", Context.MODE_PRIVATE)

    private fun todayKey(): String {
        return java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
            .format(java.util.Date())
    }

    private fun likesToday(): Int = prefs.getInt("likes_${todayKey()}", 0)
    private fun commentsToday(): Int = prefs.getInt("comments_${todayKey()}", 0)
    private fun bumpLikes() = prefs.edit().putInt("likes_${todayKey()}", likesToday() + 1).apply()
    private fun bumpComments() = prefs.edit().putInt("comments_${todayKey()}", commentsToday() + 1).apply()

    /** Instagram kholo */
    private suspend fun openInstagram(): Boolean = withContext(Dispatchers.Main) {
        try {
            val pm = context.packageManager
            val intent = pm.getLaunchIntentForPackage("com.instagram.android") ?: return@withContext false
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            delay(3000)
            true
        } catch (e: Exception) { false }
    }

    /**
     * Reels like karo
     * @param count kitne reels like karne hain
     */
    suspend fun likeReels(
        count: Int,
        taskId: String = "",
        onProgress: (done: Int) -> Unit = {}
    ) = withContext(Dispatchers.Default) {
        if (!openInstagram()) {
            onProgress(-1); return@withContext
        }
        val svc = JarvisAccessibilityService.instance ?: return@withContext
        var done = 0
        var target = count

        // Daily limit check
        if (likesToday() >= MAX_LIKES_PER_DAY) {
            Log.d("Insta", "Daily like limit reached!")
            return@withContext
        }
        target = minOf(target, MAX_LIKES_PER_DAY - likesToday())

        // Reels tab kholo (bottom navigation)
        withContext(Dispatchers.Main) { svc.tap(500, 2200) { } } // reels icon (approx)
        delay(2500)

        while (done < target) {
            // Task control check
            if (taskId.isNotBlank()) {
                val cp = AppDatabase.get(context).taskDao().byId(taskId)
                if (cp == null || cp.status == "failed") break
                if (cp.status == "paused") { delay(5000); continue }
            }

            // Like button dabao (dil wala — double tap bhi kaam karta hai!)
            withContext(Dispatchers.Main) {
                // Double-tap center = like (sabse reliable!)
                svc.tap(500, 1100) { }
                delay(300)
                svc.tap(500, 1100) { }
            }
            delay(1500)
            done++
            bumpLikes()
            onProgress(done)

            // Random break har 20 likes ke baad
            if (done % 20 == 0) {
                delay((120000 + Math.random() * 180000).toLong()) // 2-5 min
            } else {
                // Next reel: upar swipe
                withContext(Dispatchers.Main) { svc.swipe(500, 1600, 500, 400, 400) }
                delay((8000 + Math.random() * 12000).toLong()) // 8-20 sec human delay
            }
        }
        Log.d("Insta", "Liked $done reels!")
    }

    /**
     * Reels pe smart comments karo
     * @param count kitne reels pe comment
     * @param style "funny" | "supportive" | "hinglish"
     */
    suspend fun commentOnReels(
        count: Int,
        style: String = "hinglish",
        taskId: String = "",
        onProgress: (done: Int) -> Unit = {}
    ) = withContext(Dispatchers.Default) {
        val apiKey = PromptManager(context).getApiKey()
        if (apiKey.isBlank() || !openInstagram()) {
            onProgress(-1); return@withContext
        }
        val svc = JarvisAccessibilityService.instance ?: return@withContext
        var done = 0
        var target = minOf(count, MAX_COMMENTS_PER_DAY - commentsToday())
        if (target <= 0) return@withContext

        withContext(Dispatchers.Main) { svc.tap(500, 2200) { } }
        delay(2500)

        while (done < target) {
            if (taskId.isNotBlank()) {
                val cp = AppDatabase.get(context).taskDao().byId(taskId)
                if (cp == null || cp.status == "failed") break
                if (cp.status == "paused") { delay(5000); continue }
            }

            // Reel dekho 5 sec (samajhne ke liye)
            delay(5000)

            // Screen se andaza lagao reel kis baare me hai
            val screenText = withContext(Dispatchers.Main) { svc.readScreen().take(300) }

            // Comment banao
            val comment = generateComment(screenText, style, apiKey)
            if (comment.isNotBlank()) {
                withContext(Dispatchers.Main) {
                    // Comment icon tap karo
                    svc.tap(850, 1400) { }
                    delay(2000)
                    // Type karo
                    svc.typeText("", comment)
                    delay(1500)
                    // Post karo
                    svc.clickText("Post")
                }
                delay(2000)
                // Wapas jao
                withContext(Dispatchers.Main) { svc.goBack() }
                done++
                bumpComments()
                onProgress(done)
            }

            // Next reel
            withContext(Dispatchers.Main) { svc.swipe(500, 1600, 500, 400, 400) }
            delay((15000 + Math.random() * 20000).toLong()) // 15-35 sec (comment me time lagta hai)
        }
    }

    /** Reel ke hisaab se comment banao */
    private suspend fun generateComment(screenText: String, style: String, apiKey: String): String {
        val client = GeminiClient(apiKey)
        val stylePrompt = when (style) {
            "funny" -> "funny aur witty"
            "supportive" -> "supportive aur encouraging"
            else -> "natural Hinglish"
        }
        val resp = client.chat(
            """Instagram reel pe $stylePrompt comment likho.
               Reel ke baare me: $screenText
               Rules: sirf 1 line, max 15 words, human jaise, emoji max 1.
               Sirf comment do, kuch aur nahi.""",
            "", "Comment likho:"
        ).getOrNull()?.trim()?.take(100) ?: ""
        return resp.lines().firstOrNull()?.trim() ?: ""
    }

    /**
     * Reel post karo
     * @param caption caption text
     */
    suspend fun postReel(caption: String, onProgress: (String) -> Unit = {}): Boolean =
        withContext(Dispatchers.Default) {
            if (!openInstagram()) return@withContext false
            val svc = JarvisAccessibilityService.instance ?: return@withContext false

            onProgress("Plus button dhoondh raha hun...")
            withContext(Dispatchers.Main) {
                // Create (+) button — usually top ya bottom me
                if (!svc.clickText("Create")) svc.tap(500, 150) { }
                delay(2500)
                // Reel select karo
                if (!svc.clickText("Reel")) svc.clickText("REEL")
                delay(2000)
            }

            onProgress("Video select karo (tumhe manually karna hoga, 30 sec wait kar raha hun)...")
            // Yahan user ko video select karne do — full auto file picking risky hai
            delay(30000)

            withContext(Dispatchers.Main) {
                // Next/arrow dabao
                svc.tap(950, 150) { }
                delay(2500)
                // Caption likho
                svc.clickText("caption") || svc.clickText("Caption")
                delay(1000)
                svc.typeText("", caption)
                delay(2000)
                // Share/Post dabao
                svc.clickText("Share") || svc.clickText("Post")
            }
            delay(5000)
            onProgress("Reel post ho gaya! 🎉")
            true
        }
}
