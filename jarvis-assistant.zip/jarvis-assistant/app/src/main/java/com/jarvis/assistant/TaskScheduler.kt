package com.jarvis.assistant

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.*
import com.jarvis.assistant.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

/**
 * TaskScheduler: reminders + daily routine alerts.
 * - One-time reminders: AlarmManager (exact)
 * - Recurring/daily: WorkManager
 * - Due reminders pe notification + Jarvis bolke yaad dilata hai
 */
class TaskScheduler(private val context: Context) {

    companion object {
        const val CHANNEL_ID = "jarvis_reminders"
        const val ACTION_REMIND = "com.jarvis.assistant.REMIND"
        const val EXTRA_TITLE = "title"
        const val EXTRA_ID = "reminder_id"
    }

    private val dao = AppDatabase.get(context).reminderDao()
    private val scope = CoroutineScope(Dispatchers.IO)

    fun ensureChannel() {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Jarvis Reminders", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "Jarvis ke reminders aur routine alerts"
            nm.createNotificationChannel(ch)
        }
    }

    /** Naya reminder lagao */
    fun schedule(title: String, detail: String, triggerAtMillis: Long, recurring: String? = null, onDone: (Long) -> Unit = {}) {
        scope.launch {
            val id = dao.insert(
                com.jarvis.assistant.data.Reminder(
                    title = title, detail = detail,
                    triggerAt = triggerAtMillis, recurring = recurring
                )
            )
            setExactAlarm(id, title, triggerAtMillis)
            onDone(id)
        }
    }

    private fun setExactAlarm(reminderId: Long, title: String, triggerAt: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            action = ACTION_REMIND
            putExtra(EXTRA_ID, reminderId)
            putExtra(EXTRA_TITLE, title)
        }
        val pi = PendingIntent.getBroadcast(
            context, reminderId.toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        } catch (e: SecurityException) {
            am.set(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        }
    }

    /** Daily routine check — har subah 8 baje routine summary */
    fun scheduleDailyBriefing(hour: Int = 8, minute: Int = 0) {
        val req = PeriodicWorkRequestBuilder<DailyBriefingWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(calculateDelay(hour, minute), TimeUnit.MILLISECONDS)
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "daily_briefing", ExistingPeriodicWorkPolicy.UPDATE, req
        )
    }

    /** 🌙 DREAM CYCLE — roz raat 3 baje (charging pe) */
    fun scheduleDreamCycle() {
        val req = PeriodicWorkRequestBuilder<DreamWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(calculateDelay(3, 0), TimeUnit.MILLISECONDS)
            .setConstraints(
                Constraints.Builder()
                    .setRequiresCharging(true)
                    .setRequiresBatteryNotLow(true)
                    .build()
            )
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "dream_cycle", ExistingPeriodicWorkPolicy.UPDATE, req
        )
    }

    /** 📋 EVENING DIGEST — roz raat 9 baje notification triage */
    fun scheduleEveningDigest() {
        val req = PeriodicWorkRequestBuilder<DigestWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(calculateDelay(21, 0), TimeUnit.MILLISECONDS)
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "evening_digest", ExistingPeriodicWorkPolicy.UPDATE, req
        )
    }

    private fun calculateDelay(hour: Int, minute: Int): Long {
        val now = java.util.Calendar.getInstance()
        val target = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, hour)
            set(java.util.Calendar.MINUTE, minute)
            set(java.util.Calendar.SECOND, 0)
        }
        if (target.before(now)) target.add(java.util.Calendar.DAY_OF_MONTH, 1)
        return target.timeInMillis - now.timeInMillis
    }

    fun notify(title: String, text: String) {
        ensureChannel()
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notif = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Jarvis: $title")
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        nm.notify(System.currentTimeMillis().toInt(), notif)
    }
}

/** Alarm fire hone pe reminder dikhao */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TaskScheduler.ACTION_REMIND) return
        val title = intent.getStringExtra(TaskScheduler.EXTRA_TITLE) ?: "Reminder"
        val id = intent.getLongExtra(TaskScheduler.EXTRA_ID, -1)

        TaskScheduler(context).notify(title, "Yaad dilaya Jarvis ne!")

        // Recurring hai to dobara lagao
        CoroutineScope(Dispatchers.IO).launch {
            val dao = AppDatabase.get(context).reminderDao()
            dao.markDone(id)
            // TODO: recurring ke liye next occurrence schedule karo
        }

        // Jarvis bolke bhi yaad dilaye
        VoiceManager.speakStatic(context, "Reminder: $title")
    }
}

/** Roz subah ka briefing worker */
class DailyBriefingWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        // TODO: MemoryManager se aaj ke tasks/routine nikalo aur notify karo
        TaskScheduler(applicationContext).notify(
            "Good Morning!",
            "Aaj ka din shuru ho gaya. Kuch yaad dilana hai to bolo!"
        )
        return Result.success()
    }
}

/** Shaam ka notification digest worker */
class DigestWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        return try {
            NotificationTriage(applicationContext).sendEveningDigest()
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
