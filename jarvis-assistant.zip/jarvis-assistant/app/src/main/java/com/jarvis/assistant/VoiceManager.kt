package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * VoiceManager: sunna (SpeechRecognizer) + bolna (TTS).
 * Hindi (hi-IN) preferred, fallback English.
 */
class VoiceManager(
    private val context: Context,
    private val onResult: (String) -> Unit,
    private val onError: (String) -> Unit = {}
) {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val hi = tts?.setLanguage(Locale("hi", "IN"))
                if (hi == TextToSpeech.LANG_MISSING_DATA || hi == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.setLanguage(Locale.US)
                }
                ttsReady = true
            }
        }
    }

    fun speak(text: String, onDone: () -> Unit = {}) {
        if (!ttsReady) {
            onDone()
            return
        }
        val id = System.currentTimeMillis().toString()
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(u: String?) {}
            override fun onError(u: String?) { onDone() }
            override fun onDone(u: String?) { onDone() }
        })
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    fun stopSpeaking() {
        tts?.stop()
    }

    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("Speech recognition available nahi hai")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val heard = list?.firstOrNull()?.trim() ?: ""
                if (heard.isNotEmpty()) onResult(heard) else onError("Kuch sunai nahi diya")
            }
            override fun onError(error: Int) { onError("Sunne me dikkat (code $error)") }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        recognizer?.startListening(intent)
    }

    fun stopListening() {
        recognizer?.stopListening()
    }

    fun destroy() {
        recognizer?.destroy()
        tts?.shutdown()
    }

    companion object {
        /** Bina instance ke quick speak (reminders ke liye) */
        fun speakStatic(context: Context, text: String) {
            val tts = TextToSpeech(context) { status ->
                // one-shot, no callback tracking needed
            }
            // Note: real implementation me utterance listener lagana chahiye;
            // simplicity ke liye direct speak:
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                tts.setLanguage(Locale("hi", "IN"))
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "static")
            }, 500)
        }
    }
}
