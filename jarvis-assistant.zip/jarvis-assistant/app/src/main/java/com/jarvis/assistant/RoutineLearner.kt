package com.jarvis.assistant

import android.content.Context
import com.jarvis.assistant.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

/**
 * ROUTINE LEARNING: User ke daily patterns seekho.
 *
 * Kaise kaam karta hai:
 * - Har command ke saath time + day note karo
 * - Jab koi pattern 3+ baar repeat ho (jaise "roz subah 9 baje Zomato"),
 *   to use routine memory me save karo
 * - ProactiveEngine phir sahi time pe suggest karega
 */
class RoutineLearner(context: Context) {

    private val dao = AppDatabase.get(context).memoryDao()
    private val scope = CoroutineScope(Dispatchers.IO)

    // In-memory pattern counter: "hour:command_signature" -> count
    private val patternCounts = mutableMapOf<String, Int>()
    private val patternExamples = mutableMapOf<String, String>()

    /** Har command pe call karo */
    fun observe(command: String) {
        scope.launch {
            val cal = Calendar.getInstance()
            val hour = cal.get(Calendar.HOUR_OF_DAY)
            val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)

            // Command ka signature banao (numbers/names hata ke)
            val signature = signatureOf(command)
            if (signature.isBlank()) return@launch

            val key = "$dayOfWeek:$hour:$signature"
            val count = (patternCounts[key] ?: 0) + 1
            patternCounts[key] = count
            if (!patternExamples.containsKey(key)) {
                patternExamples[key] = command
            }

            // 3 baar repeat = pattern found!
            if (count == 3) {
                val example = patternExamples[key] ?: command
                val dayName = dayName(dayOfWeek)
                dao.insert(
                    com.jarvis.assistant.data.Memory(
                        category = "routine",
                        summary = "User $dayName ko ~$hour baje aksar ye karta hai: '$example'",
                        importance = 8
                    )
                )
            }
        }
    }

    private fun signatureOf(command: String): String {
        var s = command.lowercase().trim()
        // Numbers hatao
        s = s.replace(Regex("\\d+"), "#")
        // Bahut chhota ya generic command ignore karo
        if (s.length < 4) return ""
        if (s in listOf("haan", "nahi", "ok", "theek hai", "wapas", "home")) return ""
        return s.take(40)
    }

    private fun dayName(dayOfWeek: Int): String = when (dayOfWeek) {
        Calendar.MONDAY -> "Somvaar"
        Calendar.TUESDAY -> "Mangalvaar"
        Calendar.WEDNESDAY -> "Budhvaar"
        Calendar.THURSDAY -> "Guruvaar"
        Calendar.FRIDAY -> "Shukravaar"
        Calendar.SATURDAY -> "Shanivaar"
        Calendar.SUNDAY -> "Ravivaar"
        else -> ""
    }

    /** Is waqt ke liye koi learned routine hai? */
    suspend fun routineForNow(): List<com.jarvis.assistant.data.Memory> {
        val cal = Calendar.getInstance()
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
        val dayName = dayName(dayOfWeek)
        // Is din + is hour ke aas-paas ki routines dhoondho
        val all = dao.byCategory("routine", 20)
        return all.filter {
            it.summary.contains(dayName) ||
            it.summary.contains("~$hour baje") ||
            it.summary.contains("roz", ignoreCase = true)
        }.take(3)
    }
}
