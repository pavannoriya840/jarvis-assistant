package com.jarvis.assistant

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * SELF-OPTIMIZER 📊 — Jarvis khud ko behtar banata hai!
 *
 * A/B TESTING apne methods pe:
 * 1. Har skill ka success rate track hota hai (SkillLibrary me)
 * 2. Optimizer dekhta hai: "kaunsa method kitna successful hai?"
 * 3. Kharab methods ko Gemini se improve karwata hai
 * 4. Naya method test karta hai → behtar hai to replace!
 *
 * Example:
 *   "WhatsApp chat kholne ka Method A: 90% success"
 *   "Method B: 40% success → B ko improve karo ya hatao!"
 */
class SelfOptimizer(private val context: Context) {

    /**
     * Weekly optimization run (DreamCycle se bhi call ho sakta hai)
     */
    suspend fun optimize(onProgress: (String) -> Unit = {}): String =
        withContext(Dispatchers.Default) {
            val apiKey = PromptManager(context).getApiKey()
            if (apiKey.isBlank()) return@withContext "API key nahi hai"

            onProgress("📊 Apne methods analyze kar raha hun...")
            val dao = AppDatabase.get(context).skillDao()
            val skills = withContext(Dispatchers.IO) { dao.all() }

            if (skills.isEmpty()) return@withContext "Abhi koi skill nahi — pehle kuch kaam karo!"

            val report = mutableListOf<String>()
            var improved = 0

            // Kharab skills dhoondho (success < 60%, 3+ uses)
            val bad = skills.filter { it.successRate < 0.6f && it.useCount >= 3 }

            for (skill in bad.take(3)) { // ek run me max 3
                onProgress("🔧 '${skill.name}' improve kar raha hun (${(skill.successRate * 100).toInt()}% success)...")

                val client = GeminiClient(apiKey)
                val better = client.chat(
                    """Ek automation skill hai jo aksar fail hoti hai:
                       Naam: ${skill.name}
                       Trigger: ${skill.trigger}
                       Steps: ${skill.stepsJson.take(500)}
                       Success rate: ${(skill.successRate * 100).toInt()}%

                       Behtar steps suggest karo — kya badalna chahiye?
                       Sirf JSON array me naye steps do: [{"action": "...", "target": "...", "value": "..."}]
                       Agar improve nahi ho sakta to "SKIP" likho.""",
                    "", "Improve karo:"
                ).getOrNull()?.trim()

                if (!better.isNullOrBlank() && !better.contains("SKIP")) {
                    try {
                        // Naye steps save karo (purane backup ke saath)
                        val clean = better.substringAfter("[").substringBeforeLast("]")
                        withContext(Dispatchers.IO) {
                            // Purane steps ko memory me backup karo
                            MemoryManager(context).remember(
                                "fact",
                                "Skill '${skill.name}' optimized: purane steps backup me",
                                importance = 5
                            )
                            // Naye steps se update (delete + re-insert simple approach)
                            dao.delete(skill)
                            dao.insert(
                                com.jarvis.assistant.data.Skill(
                                    name = skill.name,
                                    trigger = skill.trigger,
                                    stepsJson = "[$clean]",
                                    successRate = 0.5f, // reset — phir se prove karega!
                                    useCount = 0
                                )
                            )
                        }
                        improved++
                        report.add("✅ '${skill.name}' improved!")
                    } catch (e: Exception) {
                        Log.e("Optimizer", "improve fail: ${e.message}")
                    }
                }
            }

            // Acchi skills ki tareef (memory me)
            val best = skills.filter { it.successRate > 0.9f && it.useCount >= 5 }
                .take(3)
            if (best.isNotEmpty()) {
                val bestNames = best.joinToString { s -> s.name }
                withContext(Dispatchers.IO) {
                    MemoryManager(context).remember(
                        "learning",
                        "Best methods (keep using): $bestNames",
                        importance = 6
                    )
                }
            }

            val totalSkills = skills.size
            if (improved == 0) "Sab methods already best hain! 💪 ($totalSkills skills checked)"
            else "Optimization complete! $improved skills improve kiye:\n${report.joinToString("\n")}"
        }
}
