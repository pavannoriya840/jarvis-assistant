package com.jarvis.assistant

import kotlinx.serialization.json.*

/**
 * FUNCTION CALLING: Gemini ko real tools do!
 *
 * Ab Gemini sirf text nahi bolega — wo khud decide karega kaunsa
 * function call karna hai, aur Jarvis use execute karega.
 *
 * Example:
 *   User: "Mummy ko 5 baje call karne ka reminder lagao"
 *   Gemini: { "function": "schedule_reminder", "args": {"title": "Mummy ko call", "time": "17:00"} }
 *   Jarvis: ✅ Reminder lag gaya!
 */
object GeminiFunctions {

    /** Gemini ko bhejne wale function definitions (OpenAPI style) */
    fun definitions(): JsonArray = buildJsonArray {
        addJsonObject {
            put("name", "schedule_reminder")
            put("description", "User ke liye reminder lagao. Time natural language me bhi chalega.")
            putJsonObject("parameters") {
                put("type", "object")
                putJsonObject("properties") {
                    putJsonObject("title") {
                        put("type", "string")
                        put("description", "Reminder ka title, jaise 'Mummy ko call karna'")
                    }
                    putJsonObject("in_minutes") {
                        put("type", "integer")
                        put("description", "Kitne minute baad yaad dilana hai")
                    }
                    putJsonObject("at_time") {
                        put("type", "string")
                        put("description", "Exact time HH:MM format me, jaise '17:00'")
                    }
                }
                putJsonArray("required") { add("title") }
            }
        }
        addJsonObject {
            put("name", "open_app")
            put("description", "Phone me koi app kholo")
            putJsonObject("parameters") {
                put("type", "object")
                putJsonObject("properties") {
                    putJsonObject("app_name") {
                        put("type", "string")
                        put("description", "App ka naam, jaise 'whatsapp', 'zomato'")
                    }
                }
                putJsonArray("required") { add("app_name") }
            }
        }
        addJsonObject {
            put("name", "tap_text")
            put("description", "Screen pe kisi text wale button/option pe tap karo")
            putJsonObject("parameters") {
                put("type", "object")
                putJsonObject("properties") {
                    putJsonObject("text") {
                        put("type", "string")
                        put("description", "Wo text jo button pe likha hai")
                    }
                }
                putJsonArray("required") { add("text") }
            }
        }
        addJsonObject {
            put("name", "type_text")
            put("description", "Screen pe khule input field me text type karo")
            putJsonObject("parameters") {
                put("type", "object")
                putJsonObject("properties") {
                    putJsonObject("text") {
                        put("type", "string")
                        put("description", "Type karne wala text")
                    }
                    putJsonObject("hint") {
                        put("type", "string")
                        put("description", "Field ka hint (optional)")
                    }
                }
                putJsonArray("required") { add("text") }
            }
        }
        addJsonObject {
            put("name", "scroll")
            put("description", "Screen scroll karo")
            putJsonObject("parameters") {
                put("type", "object")
                putJsonObject("properties") {
                    putJsonObject("direction") {
                        put("type", "string")
                        put("description", "'down' ya 'up'")
                    }
                }
                putJsonArray("required") { add("direction") }
            }
        }
        addJsonObject {
            put("name", "go_back")
            put("description", "Back button dabao")
            putJsonObject("parameters") {
                put("type", "object")
                putJsonObject("properties") { }
            }
        }
        addJsonObject {
            put("name", "run_macro")
            put("description", "Pehle se saved macro chalao")
            putJsonObject("parameters") {
                put("type", "object")
                putJsonObject("properties") {
                    putJsonObject("macro_name") {
                        put("type", "string")
                        put("description", "Macro ka naam")
                    }
                }
                putJsonArray("required") { add("macro_name") }
            }
        }
        addJsonObject {
            put("name", "remember")
            put("description", "User ke baare me koi important baat yaad rakho")
            putJsonObject("parameters") {
                put("type", "object")
                putJsonObject("properties") {
                    putJsonObject("fact") {
                        put("type", "string")
                        put("description", "Yaad rakhne wali baat, 1 line me")
                    }
                    putJsonObject("category") {
                        put("type", "string")
                        put("description", "'preference', 'routine', 'fact' me se ek")
                    }
                }
                putJsonArray("required") { add("fact") }
            }
        }
        addJsonObject {
            put("name", "read_screen")
            put("description", "Current screen pe kya dikh raha hai, wo text padho")
            putJsonObject("parameters") {
                put("type", "object")
                putJsonObject("properties") { }
            }
        }
    }

    /** Function call ka result — Gemini ko wapas bhejo taaki wo aage decide kare */
    data class FunctionResult(
        val name: String,
        val success: Boolean,
        val output: String
    )
}
