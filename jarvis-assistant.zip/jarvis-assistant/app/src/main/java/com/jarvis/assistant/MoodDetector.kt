package com.jarvis.assistant

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar

/**
 * MOOD DETECTOR 😊 — tumhare mood ke hisaab se behave karega!
 *
 * Kaise detect karta hai:
 * - Command ke words se (caps, "jaldi", "yaar", "please")
 * - Time se (raat ko thaka hua, subah fresh)
 * - Recent chat history se
 *
 * Moods: normal | urgent | tired | happy | frustrated
 *
 * Har mood pe response style badalta hai:
 * - urgent → super short, no bakwas
 * - tired → calm, kam sawal
 * - happy → thodi masti OK
 * - frustrated → extra careful, confirm karke kaam
 */
class MoodDetector(private val context: Context) {

    enum class Mood { NORMAL, URGENT, TIRED, HAPPY, FRUSTRATED }

    /**
     * Command text se mood detect karo (fast, on-device!)
     */
    fun detectMood(command: String): Mood {
        val lower = command.lowercase()
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)

        // URGENT: jaldi wale words, caps
        if (lower.contains(Regex("jaldi|urgent|abhi|turant|immediately"))) return Mood.URGENT
        if (command.length > 5 && command == command.uppercase()) return Mood.URGENT

        // FRUSTRATED: gussa wale words
        if (lower.contains(Regex("bekar|bakwas|stupid|idiot|gussa|dobara mat"))) return Mood.FRUSTRATED

        // HAPPY: khushi wale words, emoji
        if (lower.contains(Regex("badhiya|mast|awesome|love|shabash|wah"))) return Mood.HAPPY

        // TIRED: raat ko der tak, ya thakan wale words
        if (hour >= 23 || hour < 5) return Mood.TIRED
        if (lower.contains(Regex("thak gaya|neend|tired|sleepy"))) return Mood.TIRED

        return Mood.NORMAL
    }

    /**
     * Mood ke hisaab se response style
     */
    fun styleFor(mood: Mood): String = when (mood) {
        Mood.URGENT -> "Super short jawab, sirf kaam ki baat, koi sawal nahi. Action pe focus."
        Mood.FRUSTRATED -> "Calm aur careful. Pehle maafi jaisa tone, phir confirm karke kaam karo. Galti mat karo."
        Mood.TIRED -> "Soft tone, kam words, zyada sawal mat pucho. Seedha kaam karo."
        Mood.HAPPY -> "Thodi masti allowed! Friendly aur energetic."
        Mood.NORMAL -> "Normal Jarvis style: short, decisive Hinglish."
    }

    /**
     * Gemini prompt me mood context add karo
     */
    suspend fun moodContext(command: String): String = withContext(Dispatchers.Default) {
        val mood = detectMood(command)
        // Yaad rakho (pattern learning ke liye)
        if (mood != Mood.NORMAL) {
            withContext(Dispatchers.IO) {
                MemoryManager(context).remember(
                    "fact", "User mood tha: $mood", importance = 3
                )
            }
        }
        "User ka mood: $mood. Style: ${styleFor(mood)}"
    }
}
