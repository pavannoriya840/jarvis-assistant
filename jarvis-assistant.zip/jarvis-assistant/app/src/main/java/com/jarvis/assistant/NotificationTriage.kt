package com.jarvis.assistant

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * NOTIFICATION TRIAGE 🔔 — smart notification manager!
 *
 * Din bhar ki 100+ notifications me se:
 * - 🔴 IMPORTANT → turant batao (paise, mummy ka message, OTP)
 * - 🟡 NORMAL → rehne do
 * - ⚪ SPAM → auto-dismiss karo!
 *
 * Shaam ko ek DIGEST: "Aaj ye 5 cheezein important thin"
 */
class NotificationTriage(private val context: Context) {

    data class TriageResult(
        val important: List<JarvisNotificationListener.NotifInfo>,
        val spam: List<JarvisNotificationListener.NotifInfo>,
        val digest: String
    )

    /**
     * Recent notifications ko triage karo
     */
    suspend fun triage(autoDismissSpam: Boolean = true): TriageResult =
        withContext(Dispatchers.Default) {
            val recent = JarvisNotificationListener.getRecent()
            val important = mutableListOf<JarvisNotificationListener.NotifInfo>()
            val spam = mutableListOf<JarvisNotificationListener.NotifInfo>()

            for (n in recent) {
                when (classify(n)) {
                    "important" -> important.add(n)
                    "spam" -> {
                        spam.add(n)
                        if (autoDismissSpam) dismissNotification(n)
                    }
                    else -> { /* normal — rehne do */ }
                }
            }

            val digest = buildDigest(important)
            TriageResult(important, spam, digest)
        }

    /** Notification classify karo */
    private fun classify(n: JarvisNotificationListener.NotifInfo): String {
        val text = "${n.title} ${n.text}".lowercase()
        val app = n.app.lowercase()

        // SPAM patterns
        if (text.contains(Regex("offer|discount|sale|win prize|congratulations.*won|limited time"))) return "spam"
        if (app.contains("game") && text.contains(Regex("come back|reward waiting|energy full"))) return "spam"
        if (text.contains(Regex("subscribe|premium.*free"))) return "spam"

        // IMPORTANT patterns
        if (n.isOtp) return "important"
        if (text.contains(Regex("debited|credited|transaction|payment failed"))) return "important"
        if (text.contains(Regex("delivered|arriving|out for delivery"))) return "important"
        if (text.contains(Regex("meeting|interview|deadline|urgent"))) return "important"
        if (text.contains(Regex("mummy|mama|papa|bhai"))) return "important"

        return "normal"
    }

    private fun dismissNotification(n: JarvisNotificationListener.NotifInfo) {
        // NotificationListenerService se dismiss hota — yahan mark karo
        Log.d("Triage", "⚪ Spam dismissed: [${n.app}] ${n.title.take(30)}")
    }

    private fun buildDigest(important: List<JarvisNotificationListener.NotifInfo>): String {
        if (important.isEmpty()) return "Aaj koi important notification nahi aayi. Sab shaant! 😌"
        val lines = important.take(5).map { "• [${it.app}] ${it.title}: ${it.text.take(60)}" }
        return "Aaj ki important cheezein:\n${lines.joinToString("\n")}"
    }

    /** Shaam ka digest bhejo */
    suspend fun sendEveningDigest() {
        val result = triage(autoDismissSpam = true)
        if (result.important.isNotEmpty() || result.spam.isNotEmpty()) {
            TaskScheduler(context).notify(
                "Jarvis 📋 Shaam ka Digest",
                "${result.digest}\n\n${result.spam.size} spam notifications saaf ki! 🧹"
            )
        }
    }
}
