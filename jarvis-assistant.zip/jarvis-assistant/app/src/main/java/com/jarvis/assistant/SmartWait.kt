package com.jarvis.assistant

/**
 * SMART WAIT — Phase A (lean core)
 *
 * Research: "fixed sleep() flakiness ka baap hai!"
 * Rule: kabhi Thread.sleep(3000) mat lagao — CONDITION pe wait karo.
 * Koi nayi dependency nahi. Poll-based (service change nahi chahiye).
 */
object SmartWait {

    private const val POLL_MS = 250L

    /** Ye text screen pe dikhe tab tak wait karo. Timeout pe false. */
    fun forText(
        service: JarvisAccessibilityService,
        query: String,
        timeoutMs: Long = 8000
    ): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            if (service.isTextVisible(query)) return true
            Thread.sleep(POLL_MS)
        }
        return false
    }

    /** Ye text screen se GAYAB ho jaye tab tak wait karo (loading khatam!). */
    fun forGone(
        service: JarvisAccessibilityService,
        query: String,
        timeoutMs: Long = 8000
    ): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            if (!service.isTextVisible(query)) return true
            Thread.sleep(POLL_MS)
        }
        return false
    }

    /**
     * UI settle hone tak wait karo — screen text [settleMs] tak na badle.
     * Event-hook nahi chahiye, isliye text-hash polling. Lean!
     */
    fun forStable(
        service: JarvisAccessibilityService,
        settleMs: Long = 600,
        timeoutMs: Long = 8000
    ): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        var lastHash = 0
        var stableSince = System.currentTimeMillis()
        while (System.currentTimeMillis() < end) {
            val h = try { service.readScreen().hashCode() } catch (_: Exception) { 0 }
            val now = System.currentTimeMillis()
            if (h != lastHash) {
                lastHash = h
                stableSince = now
            } else if (now - stableSince >= settleMs) {
                return true
            }
            Thread.sleep(POLL_MS)
        }
        return false
    }
}
