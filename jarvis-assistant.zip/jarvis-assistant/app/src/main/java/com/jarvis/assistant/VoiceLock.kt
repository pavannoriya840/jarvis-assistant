package com.jarvis.assistant

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * VOICE LOCK 🎭 — sirf TUMHARI awaz!
 *
 * (Honest approach: saccha speaker-recognition ML model heavy hai.
 *  Isliye passphrase challenge — sensitive actions se pehle!)
 *
 * Kaise kaam karta hai:
 * - Normal commands: koi rok nahi
 * - SENSITIVE actions (naye contact ko message, public post, rule delete):
 *   Jarvis puchega: "Pehchano kaun? Apna secret word bolo!"
 * - Sahi word → action, galat → block + user ko notify
 *
 * Secret word Settings me set hota hai (default: "jarvis boss")
 */
class VoiceLock(private val context: Context) {

    companion object {
        // Sensitive action types
        val SENSITIVE_ACTIONS = listOf(
            "send_message", "post", "delete", "rule_delete",
            "payment", "share_location"
        )
    }

    private val prefs get() =
        context.getSharedPreferences("jarvis_voicelock", Context.MODE_PRIVATE)

    fun getSecretWord(): String =
        prefs.getString("secret_word", "jarvis boss") ?: "jarvis boss"

    fun setSecretWord(word: String) {
        prefs.edit().putString("secret_word", word.lowercase().trim()).apply()
    }

    fun isEnabled(): Boolean = prefs.getBoolean("enabled", true)

    fun setEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("enabled", enabled).apply()
    }

    /**
     * Kya is action ke liye voice verification chahiye?
     */
    fun needsVerification(actionType: String): Boolean {
        if (!isEnabled()) return false
        return SENSITIVE_ACTIONS.any { actionType.contains(it, ignoreCase = true) }
    }

    /**
     * Spoken text verify karo (wake word ke baad bola gaya)
     */
    suspend fun verify(spokenText: String): Boolean = withContext(Dispatchers.Default) {
        val secret = getSecretWord()
        val ok = spokenText.lowercase().contains(secret.lowercase())
        if (!ok) {
            // Galat! User ko batao (ho sakta hai koi aur try kar raha ho!)
            withContext(Dispatchers.IO) {
                MemoryManager(context).remember(
                    "learning",
                    "Voice lock failed attempt: '${spokenText.take(30)}'",
                    importance = 8
                )
            }
            TaskScheduler(context).notify(
                "Jarvis 🎭",
                "Kisi ne sensitive action try kiya lekin secret word galat tha!"
            )
        }
        ok
    }
}
