package com.jarvis.assistant

import android.content.Context
import android.util.Log
import com.jarvis.assistant.data.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * CROSS-APP FLOW 🔗 — apps ke beech DATA utha ke kaam!
 *
 * Example: "Kal ki flight ke liye cab book karo"
 *   1. 📧 Notification se flight details nikalo (airline, time)
 *   2. 🚕 Cab app kholo, pickup/drop set karo
 *   3. ⏰ Alarm lagao (flight se 3 ghante pehle)
 *   4. 📋 Sab ek report me batao!
 *
 * Data sources (privacy-safe):
 * - Notifications (flight bookings, delivery, bills)
 * - Calendar (agar connected)
 * - User ki memory
 */
class CrossAppFlow(private val context: Context) {

    /**
     * Smart multi-app task: context jama karo → plan banao → execute karo
     */
    suspend fun smartTask(
        command: String,
        onProgress: (String) -> Unit = {}
    ): String = withContext(Dispatchers.Default) {
        val apiKey = PromptManager(context).getApiKey()
        if (apiKey.isBlank()) return@withContext "API key nahi hai!"

        onProgress("🔗 Apps se data jama kar raha hun...")

        // 1. Context jama karo (notifications + memory + reminders)
        val ctx = gatherCrossAppContext()

        // 2. Gemini se plan banao
        val client = GeminiClient(apiKey)
        val plan = client.chat(
            """Tum cross-app planner ho. User ne kaha: "$command"
               Available context:
               $ctx

               Plan banao — kaunsi apps me kya karna hai, kis order me.
               Sirf actionable steps do, numbered list me. Max 8 steps.
               Agar koi zaroori data missing hai to pehle batao kya chahiye.""",
            "", "Plan banao:"
        ).getOrNull()?.trim() ?: return@withContext "Plan nahi ban paya"

        onProgress("📋 Plan ready! Execute kar raha hun...")

        // 3. MultiAgentBrain se execute karo!
        val brain = MultiAgentBrain(context)
        val result = brain.solve(
            goal = "$command\n\nPlan:\n$plan",
            onProgress = onProgress
        )

        // 4. Seekho!
        MemoryManager(context).remember(
            "fact", "Cross-app task: $command", importance = 6
        )

        result
    }

    /** Saare sources se context jama karo */
    private suspend fun gatherCrossAppContext(): String = withContext(Dispatchers.IO) {
        val sb = StringBuilder()

        // Notifications se (flight, delivery, bills)
        val notifs = JarvisNotificationListener.getRecent().take(15)
        if (notifs.isNotEmpty()) {
            sb.append("Recent notifications:\n")
            for (n in notifs) {
                // Sirf useful wali (travel, money, delivery)
                val t = "${n.title} ${n.text}".lowercase()
                if (t.contains(Regex("flight|booking|pnr|train|hotel|bill|payment|delivery"))) {
                    sb.append("- [${n.app}] ${n.title}: ${n.text.take(100)}\n")
                }
            }
        }

        // Reminders
        val reminders = AppDatabase.get(context).reminderDao().upcoming().take(5)
        if (reminders.isNotEmpty()) {
            sb.append("Upcoming:\n")
            reminders.forEach { sb.append("- ${it.title}\n") }
        }

        // Relevant memories
        val mems = MemoryManager(context).recallBlock(10)
        if (mems.isNotBlank()) sb.append("User context:\n$mems\n")

        // Time
        val time = java.text.SimpleDateFormat("EEEE, dd MMM, hh:mm a", java.util.Locale.getDefault())
            .format(java.util.Date())
        sb.append("Abhi: $time\n")

        sb.toString().ifBlank { "Koi special context nahi mila." }
    }

    /**
     * Quick flows (common patterns, bina Gemini ke — fast!)
     */
    suspend fun quickFlow(type: String): String = withContext(Dispatchers.Default) {
        when (type.lowercase()) {
            "morning" -> {
                // Subah ka routine: briefing + reminders + weather type info
                val brief = ProactiveEngine(context) {}.morningBriefing()
                "☀️ Good morning!\n$brief"
            }
            "travel_prep" -> {
                smartTask("Aane wali travel ke liye taiyaari karo (cab + alarm + packing reminder)")
            }
            else -> "Ye quick flow nahi pata. Bolo jaise 'travel ki taiyaari karo'"
        }
    }
}
