package com.jarvis.assistant

import android.content.Context
import android.util.Log
import com.jarvis.assistant.data.AppDatabase
import com.jarvis.assistant.data.AutomationRule
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*

/**
 * RULE ENGINE 🔮 — ULTRAGOD LEVEL!
 *
 * Voice se bolo: "Jab mummy ka WhatsApp message aaye to mujhe bata dena"
 * → Jarvis khud rule banayega → hamesha ke liye active!
 *
 * Examples:
 * - "Jab bank se paise kate to bol dena" → notification trigger
 * - "Roz subah 7 baje mera alarm lagana" → time trigger
 * - "Jab Instagram kholu to 30 min baad yaad dilana" → app trigger
 *
 * Ye Jarvis ko sach me GOD-LEVEL banata hai — wo tumhare liye
 * HAMESHA kaam karta hai, bina bole!
 */
class RuleEngine(private val context: Context) {

    private val json = Json { ignoreUnknownKeys = true }

    /**
     * Voice command se rule banao!
     * "jab ... to ..." pattern samjho
     */
    suspend fun createRuleFromVoice(command: String): String = withContext(Dispatchers.IO) {
        val apiKey = PromptManager(context).getApiKey()
        if (apiKey.isBlank()) return@withContext "API key nahi hai!"

        val client = GeminiClient(apiKey)
        val resp = client.chat(
            """Tum automation rule parser ho. User ne kaha: "$command"
               Isko JSON rule me convert karo. Sirf JSON do, kuch aur nahi:
               {
                 "name": "rule ka naam (short)",
                 "triggerType": "notification" | "time" | "app_open",
                 "trigger": {"app": "app name ya empty", "from": "contact ya empty", "contains": "keyword ya empty", "time": "HH:MM ya empty"},
                 "actionType": "notify" | "speak" | "remind",
                 "action": {"message": "kya karna hai", "in_minutes": 30}
               }
               Example: "jab mummy ka whatsapp aaye to batana" →
               {"name": "Mummy WhatsApp alert", "triggerType": "notification",
                "trigger": {"app": "whatsapp", "from": "mummy", "contains": "", "time": ""},
                "actionType": "speak", "action": {"message": "Mummy ka WhatsApp aaya hai!", "in_minutes": 0}}""",
            "", "Rule JSON banao:"
        ).getOrNull() ?: return@withContext "Rule samajh nahi aaya"

        try {
            val clean = resp.substringAfter("{").substringBeforeLast("}")
            val obj = json.parseToJsonElement("{$clean}").jsonObject

            val rule = AutomationRule(
                name = obj["name"]?.jsonPrimitive?.content ?: command.take(30),
                triggerType = obj["triggerType"]?.jsonPrimitive?.content ?: "notification",
                triggerJson = (obj["trigger"]?.jsonObject ?: buildJsonObject {}).toString(),
                actionType = obj["actionType"]?.jsonPrimitive?.content ?: "notify",
                actionJson = (obj["action"]?.jsonObject ?: buildJsonObject {}).toString()
            )
            AppDatabase.get(context).ruleDao().insert(rule)
            "Rule ban gaya! 🔮 '${rule.name}' — ab ye hamesha active rahega!"
        } catch (e: Exception) {
            Log.e("RuleEngine", "parse fail: ${e.message}")
            "Rule samajh nahi aaya, dobara bolo — jaise 'jab X ho to Y karna'"
        }
    }

    /** Notification aayi → rules check karo */
    suspend fun onNotification(app: String, title: String, text: String) =
        withContext(Dispatchers.IO) {
            val rules = AppDatabase.get(context).ruleDao().enabled()
                .filter { it.triggerType == "notification" }
            for (rule in rules) {
                if (matchesTrigger(rule, app, title, text)) {
                    Log.d("RuleEngine", "🔮 Rule triggered: ${rule.name}")
                    fireAction(rule)
                }
            }
        }

    /** Time-based rules check karo (AutonomousService se call hota hai) */
    suspend fun onTimeTick() = withContext(Dispatchers.IO) {
        val rules = AppDatabase.get(context).ruleDao().enabled()
            .filter { it.triggerType == "time" }
        val now = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
            .format(java.util.Date())
        for (rule in rules) {
            try {
                val trigger = json.parseToJsonElement(rule.triggerJson).jsonObject
                val ruleTime = trigger["time"]?.jsonPrimitive?.content ?: continue
                if (ruleTime == now) {
                    Log.d("RuleEngine", "🔮 Time rule triggered: ${rule.name}")
                    fireAction(rule)
                }
            } catch (e: Exception) { }
        }
    }

    /** App khula → rules check karo */
    suspend fun onAppOpen(packageName: String) = withContext(Dispatchers.IO) {
        val rules = AppDatabase.get(context).ruleDao().enabled()
            .filter { it.triggerType == "app_open" }
        for (rule in rules) {
            try {
                val trigger = json.parseToJsonElement(rule.triggerJson).jsonObject
                val app = trigger["app"]?.jsonPrimitive?.content ?: continue
                if (packageName.contains(app, ignoreCase = true)) {
                    fireAction(rule)
                }
            } catch (e: Exception) { }
        }
    }

    private fun matchesTrigger(rule: AutomationRule, app: String, title: String, text: String): Boolean {
        return try {
            val t = json.parseToJsonElement(rule.triggerJson).jsonObject
            val appMatch = t["app"]?.jsonPrimitive?.content?.let {
                it.isBlank() || app.contains(it, ignoreCase = true)
            } ?: true
            val fromMatch = t["from"]?.jsonPrimitive?.content?.let {
                it.isBlank() || title.contains(it, ignoreCase = true)
            } ?: true
            val containsMatch = t["contains"]?.jsonPrimitive?.content?.let {
                it.isBlank() || text.contains(it, ignoreCase = true)
            } ?: true
            appMatch && fromMatch && containsMatch
        } catch (e: Exception) { false }
    }

    private suspend fun fireAction(rule: AutomationRule) {
        try {
            val action = json.parseToJsonElement(rule.actionJson).jsonObject
            val message = action["message"]?.jsonPrimitive?.content ?: rule.name
            when (rule.actionType) {
                "notify" -> TaskScheduler(context).notify("Jarvis 🔮", message)
                "speak" -> {
                    TaskScheduler(context).notify("Jarvis 🔮", message)
                    VoiceManager.speakStatic(context, message)
                }
                "remind" -> {
                    val mins = action["in_minutes"]?.jsonPrimitive?.intOrNull ?: 0
                    TaskScheduler(context).apply {
                        ensureChannel()
                        schedule(message, "", System.currentTimeMillis() + mins * 60000L)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("RuleEngine", "fire fail: ${e.message}")
        }
    }

    suspend fun listRules(): List<AutomationRule> = withContext(Dispatchers.IO) {
        AppDatabase.get(context).ruleDao().all()
    }

    suspend fun deleteRule(id: Long) = withContext(Dispatchers.IO) {
        AppDatabase.get(context).ruleDao().all().firstOrNull { it.id == id }?.let {
            AppDatabase.get(context).ruleDao().delete(it)
        }
        Unit
    }
}
