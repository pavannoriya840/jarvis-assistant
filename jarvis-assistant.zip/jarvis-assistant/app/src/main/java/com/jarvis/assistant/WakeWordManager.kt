package com.jarvis.assistant

import android.content.Context
import android.util.Log

/**
 * WAKE WORD: "Hey Jarvis" bolte hi assistant jag jaye.
 *
 * Implementation: Picovoice Porcupine (free for personal use)
 * Setup:
 * 1. https://console.picovoice.ai pe free account banao
 * 2. AccessKey lo
 * 3. build.gradle me add karo: implementation("ai.picovoice:porcupine-android:3.0.2")
 * 4. Neeche ACCESS_KEY me apni key daalo
 *
 * Bina key ke: ye class safely disabled rehti hai, app normal kaam karegi.
 */
class WakeWordManager(
    private val context: Context,
    private val onWake: () -> Unit
) {
    companion object {
        // 👇 Apni Picovoice AccessKey yahan daalo (https://console.picovoice.ai)
        private const val ACCESS_KEY = "YOUR_PICOVOICE_KEY_HERE"
        private const val TAG = "WakeWord"
    }

    private var porcupine: Any? = null // ai.picovoice.porcupine.Porcupine
    private var running = false

    fun isAvailable(): Boolean = ACCESS_KEY != "YOUR_PICOVOICE_KEY_HERE"

    /**
     * Wake word listening shuru karo.
     * Reflection use kar rahe hain taaki dependency optional rahe —
     * key/dependency na ho to app crash nahi hogi.
     */
    fun start() {
        if (!isAvailable()) {
            Log.d(TAG, "Wake word disabled — no API key")
            return
        }
        try {
            val managerClass = Class.forName("ai.picovoice.porcupine.PorcupineManager")
            val builderClass = Class.forName("ai.picovoice.porcupine.PorcupineManager\$Builder")

            val builder = builderClass.getDeclaredConstructor().newInstance()
            builderClass.getMethod("setAccessKey", String::class.java).invoke(builder, ACCESS_KEY)
            // Built-in "jarvis" keyword (English). Custom Hindi keyword ke liye
            // Picovoice console se .ppn file banao aur setKeywordPath() use karo.
            val keywordClass = Class.forName("ai.picovoice.porcupine.Porcupine\$BuiltInKeyword")
            val jarvisKeyword = keywordClass.enumConstants.first {
                it.toString().equals("JARVIS", ignoreCase = true)
            }
            builderClass.getMethod("setKeyword", keywordClass).invoke(builder, jarvisKeyword)
            builderClass.getMethod("setWakeWordCallback", Function0::class.java)
                .invoke(builder, fun() {
                    android.os.Handler(android.os.Looper.getMainLooper()).post { onWake() }
                })

            porcupine = builderClass.getMethod("build", Context::class.java).invoke(builder, context)
            porcupine?.javaClass?.getMethod("start")?.invoke(porcupine)
            running = true
            Log.d(TAG, "Wake word listening started")
        } catch (e: Exception) {
            Log.e(TAG, "Wake word start failed: ${e.message}")
        }
    }

    fun stop() {
        try {
            porcupine?.javaClass?.getMethod("stop")?.invoke(porcupine)
            porcupine?.javaClass?.getMethod("delete")?.invoke(porcupine)
        } catch (e: Exception) {
            Log.e(TAG, "Wake word stop failed: ${e.message}")
        }
        running = false
    }

    fun isRunning(): Boolean = running
}
