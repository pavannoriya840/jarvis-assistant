package com.jarvis.assistant

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import java.util.ArrayDeque

/**
 * OPEN WAKE WORD — "Hey Jarvis" detection, bilkul FREE!
 *
 * ✅ Koi account nahi, koi API key nahi, koi company email nahi
 * ✅ 100% offline — audio phone se bahar nahi jata
 * ✅ openWakeWord ka pre-trained "hey_jarvis" model (Apache 2.0)
 *
 * Pipeline (openWakeWord v0.5.1 jaisa):
 *   Mic (16kHz) → 80ms chunks → melspectrogram.tflite → embedding_model.tflite
 *   → hey_jarvis_v0.1.tflite → probability ≥ 0.5 = WAKE!
 *
 * Models `app/src/main/assets/` me bundled hain (~3.7MB total).
 */
class OpenWakeWordManager(
    private val context: Context,
    private val onWake: () -> Unit
) {
    companion object {
        private const val TAG = "JarvisWakeWord"
        private const val SAMPLE_RATE = 16000
        private const val CHUNK_SAMPLES = 1280   // 80ms @ 16kHz
        private const val MEL_OVERLAP = 480     // 160*3 (continuity ke liye)
        private const val MEL_WINDOW = 76       // embedding ke liye pichhle 76 mel frames
        private const val MEL_BINS = 32
        private const val EMBED_DIM = 96
        private const val JARVIS_FRAMES = 16    // classifier ke liye pichhle 16 embeddings
        private const val MAX_EMBED_BUFFER = 120
        private const val THRESHOLD = 0.5f
        private const val WARMUP_FRAMES = 5     // pehle 5 frames me detect mat karo
        private const val DEBOUNCE_MS = 2500L
    }

    private var melspec: Interpreter? = null
    private var embedder: Interpreter? = null
    private var jarvis: Interpreter? = null

    private var recorder: AudioRecord? = null
    private var running = false
    private var worker: Thread? = null

    // Streaming buffers
    private val rawBuffer = ArrayDeque<Float>()
    private val melBuffer = ArrayDeque<FloatArray>()
    private val embedBuffer = ArrayDeque<FloatArray>()
    private var framesProcessed = 0
    private var lastWakeAt = 0L

    // Reusable TFLite buffers
    private var melspecIn: ByteBuffer? = null
    private var melspecOut: ByteBuffer? = null
    private var melspecOutFrames = 0
    private var embedIn: ByteBuffer? = null
    private var embedOut: ByteBuffer? = null
    private var jarvisIn: ByteBuffer? = null
    private var jarvisOut: ByteBuffer? = null

    fun isRunning(): Boolean = running

    /** Start karo. False = mic/model problem. */
    fun start(): Boolean {
        if (running) return true
        try {
            // 1. Models load karo
            val opts = Interpreter.Options().apply { setNumThreads(2) }
            melspec = Interpreter(loadModel("melspectrogram.tflite"), opts)
            embedder = Interpreter(loadModel("embedding_model.tflite"), opts)
            jarvis = Interpreter(loadModel("hey_jarvis_v0.1.tflite"), opts)

            // 2. Melspec input hamesha [1, 1760] (1280 new + 480 overlap)
            val audioLen = MEL_OVERLAP + CHUNK_SAMPLES
            melspec!!.resizeInput(0, intArrayOf(1, audioLen))
            melspec!!.allocateTensors()
            val mOutShape = melspec!!.getOutputTensor(0).shape() // [1, F, 1, 32]
            melspecOutFrames = mOutShape[1]
            Log.d(TAG, "melspec output frames per chunk: $melspecOutFrames")

            melspecIn = ByteBuffer.allocateDirect(audioLen * 4).order(ByteOrder.nativeOrder())
            melspecOut = ByteBuffer.allocateDirect(mOutShape.reduce { a, b -> a * b } * 4)
                .order(ByteOrder.nativeOrder())

            // 3. Embedding buffers: [1, 76, 32, 1] → 96 floats
            embedIn = ByteBuffer.allocateDirect(MEL_WINDOW * MEL_BINS * 4).order(ByteOrder.nativeOrder())
            embedOut = ByteBuffer.allocateDirect(EMBED_DIM * 4).order(ByteOrder.nativeOrder())

            // 4. Jarvis buffers: [1, 16, 96] → 1 float
            jarvisIn = ByteBuffer.allocateDirect(JARVIS_FRAMES * EMBED_DIM * 4).order(ByteOrder.nativeOrder())
            jarvisOut = ByteBuffer.allocateDirect(4).order(ByteOrder.nativeOrder())

            // 5. Mic shuru karo
            val minBuf = AudioRecord.getMinBufferSize(
                SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBuf <= 0) {
                Log.e(TAG, "Mic available nahi")
                return false
            }
            recorder = AudioRecord(
                MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                minBuf * 4
            )
            if (recorder!!.state != AudioRecord.STATE_INITIALIZED) {
                Log.e(TAG, "AudioRecord init fail")
                return false
            }
            recorder!!.startRecording()

            // 6. Worker thread
            running = true
            worker = Thread(::listenLoop, "jarvis-wakeword").apply { start() }
            Log.d(TAG, "Wake word listening shuru — 'Hey Jarvis' bolo!")
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Wake word start fail: ${e.message}", e)
            stop()
            return false
        }
    }

    fun stop() {
        running = false
        try { worker?.join(1000) } catch (_: Exception) {}
        worker = null
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { melspec?.close() } catch (_: Exception) {}
        try { embedder?.close() } catch (_: Exception) {}
        try { jarvis?.close() } catch (_: Exception) {}
        melspec = null; embedder = null; jarvis = null
        rawBuffer.clear(); melBuffer.clear(); embedBuffer.clear()
        framesProcessed = 0
    }

    private fun loadModel(name: String): MappedByteBuffer {
        val fd = context.assets.openFd(name)
        val input = FileInputStream(fd.fileDescriptor)
        val mapped = input.channel.map(FileChannel.MapMode.READ_ONLY, fd.startOffset, fd.declaredLength)
        input.close()
        return mapped
    }

    private fun listenLoop() {
        val pcm = ShortArray(CHUNK_SAMPLES)
        val rec = recorder ?: return
        while (running) {
            try {
                val read = rec.read(pcm, 0, CHUNK_SAMPLES)
                if (read > 0) {
                    val prob = processChunk(pcm, read)
                    if (prob >= THRESHOLD && framesProcessed >= WARMUP_FRAMES) {
                        val now = System.currentTimeMillis()
                        if (now - lastWakeAt > DEBOUNCE_MS) {
                            lastWakeAt = now
                            Log.d(TAG, "🔔 Hey Jarvis detected! (score ${"%.2f".format(prob)})")
                            android.os.Handler(android.os.Looper.getMainLooper()).post { onWake() }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "listenLoop error: ${e.message}")
                try { Thread.sleep(200) } catch (_: Exception) {}
            }
        }
    }

    /**
     * Ek 80ms chunk process karo. Returns: wake-word probability (0..1).
     */
    private fun processChunk(pcm: ShortArray, read: Int): Float {
        // 1. Raw buffer me daalo (float me convert karke)
        for (i in 0 until read) rawBuffer.addLast(pcm[i].toFloat())
        val maxRaw = MEL_OVERLAP + CHUNK_SAMPLES + 160
        while (rawBuffer.size > maxRaw) rawBuffer.removeFirst()
        if (rawBuffer.size < MEL_OVERLAP + CHUNK_SAMPLES) return 0f

        // 2. Aakhri 1760 samples nikalo → [1, 1760]
        val audioLen = MEL_OVERLAP + CHUNK_SAMPLES
        val rawList = rawBuffer.toList()
        val start = rawList.size - audioLen
        val inBuf = melspecIn!!
        inBuf.rewind()
        val fb = inBuf.asFloatBuffer()
        for (i in 0 until audioLen) fb.put(rawList[start + i])
        inBuf.rewind()

        // 3. Melspectrogram chalao
        val outBuf = melspecOut!!
        outBuf.rewind()
        melspec!!.run(inBuf, outBuf)
        outBuf.rewind()
        val outFb = outBuf.asFloatBuffer()

        // Output layout [1, F, 1, 32] → har frame ke 32 bins + transform (x/10 + 2)
        for (f in 0 until melspecOutFrames) {
            val frame = FloatArray(MEL_BINS)
            for (b in 0 until MEL_BINS) {
                frame[b] = outFb.get(f * MEL_BINS + b) / 10f + 2f
            }
            melBuffer.addLast(frame)
        }
        while (melBuffer.size > 400) melBuffer.removeFirst()
        if (melBuffer.size < MEL_WINDOW) return 0f

        // 4. Pichhle 76 mel frames → [1, 76, 32, 1] → embedding (96-dim)
        val melList = melBuffer.toList()
        val mStart = melList.size - MEL_WINDOW
        val eIn = embedIn!!
        eIn.rewind()
        val eFb = eIn.asFloatBuffer()
        for (i in 0 until MEL_WINDOW) {
            val frame = melList[mStart + i]
            for (b in 0 until MEL_BINS) eFb.put(frame[b])
        }
        eIn.rewind()
        val eOut = embedOut!!
        eOut.rewind()
        embedder!!.run(eIn, eOut)
        eOut.rewind()
        val eOutFb = eOut.asFloatBuffer()
        val embedding = FloatArray(EMBED_DIM) { eOutFb.get(it) }
        embedBuffer.addLast(embedding)
        while (embedBuffer.size > MAX_EMBED_BUFFER) embedBuffer.removeFirst()

        framesProcessed++
        if (embedBuffer.size < JARVIS_FRAMES) return 0f

        // 5. Pichhle 16 embeddings → [1, 16, 96] → probability
        val embList = embedBuffer.toList()
        val eStart = embList.size - JARVIS_FRAMES
        val jIn = jarvisIn!!
        jIn.rewind()
        val jFb = jIn.asFloatBuffer()
        for (i in 0 until JARVIS_FRAMES) {
            val emb = embList[eStart + i]
            for (d in 0 until EMBED_DIM) jFb.put(emb[d])
        }
        jIn.rewind()
        val jOut = jarvisOut!!
        jOut.rewind()
        jarvis!!.run(jIn, jOut)
        jOut.rewind()
        return jOut.asFloatBuffer().get(0)
    }
}
