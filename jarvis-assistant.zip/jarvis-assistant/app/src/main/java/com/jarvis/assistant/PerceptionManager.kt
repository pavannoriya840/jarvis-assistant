package com.jarvis.assistant

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest

/**
 * SMART PERCEPTION — har baar screenshot NAHI! 💰
 *
 * 4 Tiers (saste se mehenga):
 *   Tier 0: CACHE — "ye screen pehle dekhi hai!" (₹0, instant ⚡)
 *   Tier 1: SCREEN DUMP — accessibility tree text (₹0, fast)
 *   Tier 2: ON-DEVICE VISION — phone me hi colors/shapes (₹0, medium)
 *   Tier 3: GEMINI VISION — full AI (💰, sirf jab zaroori)
 *
 * Rule: hamesha saste tier se shuru karo, zaroorat pade to upar jao!
 * Isse ~95% API cost bachti hai!
 */
class PerceptionManager(private val context: Context) {

    data class PerceptionResult(
        val tier: Int,
        val description: String,
        val screenText: String = "",
        val cached: Boolean = false
    )

    private val cache = ScreenCache()
    private val policy = PerAppPolicy(context)

    /**
     * Screen ko samjho. Goal ke hisaab se sahi tier choose karo.
     * @param forceTier -1 = auto (smart), 0-3 = specific tier
     */
    suspend fun perceive(goal: String, forceTier: Int = -1): PerceptionResult =
        withContext(Dispatchers.Default) {
            val svc = JarvisAccessibilityService.instance
            val pkg = svc?.currentPackage() ?: "unknown"

            // Per-app policy check karo
            val appPolicy = policy.getPolicy(pkg)

            // Tier 0: Cache check (agar policy allow kare)
            if (forceTier == -1 || forceTier == 0) {
                val fingerprint = screenFingerprint(pkg)
                val hit = cache.get(fingerprint)
                if (hit != null && appPolicy.useCache) {
                    Log.d("Perceive", "⚡ Cache HIT! (₹0)")
                    return@withContext PerceptionResult(0, hit, cached = true)
                }
            }

            // Tier 1: Screen dump (accessibility tree)
            if ((forceTier == -1 || forceTier == 1) && appPolicy.allowDump) {
                val text = svc?.readScreen()?.take(1500) ?: ""
                if (text.isNotBlank() && isDumpSufficient(text, goal)) {
                    val desc = "Screen pe ye dikh raha hai:\n$text"
                    if (appPolicy.useCache) cache.put(screenFingerprint(pkg), desc)
                    Log.d("Perceive", "📝 Tier 1 dump sufficient (₹0)")
                    return@withContext PerceptionResult(1, desc, text)
                }
            }

            // Tier 2: On-device vision (screenshot nahi, sirf agar zaroori)
            // (Yahan basic analysis — asli screenshot Tier 3 me)
            if (forceTier == 2) {
                return@withContext PerceptionResult(2, "On-device analysis: screen me interactive elements hain, dump se poori jaankari nahi mili.")
            }

            // Tier 3: Gemini Vision (screenshot + AI) — LAST RESORT
            if ((forceTier == -1 || forceTier == 3) && appPolicy.allowScreenshot) {
                Log.d("Perceive", "👁️ Tier 3 Gemini Vision (💰)")
                // Screenshot via MediaProjection hota to yahan lagta
                // Abhi: accessibility + goal ko Gemini text se samjhao
                val apiKey = PromptManager(context).getApiKey()
                if (apiKey.isNotBlank()) {
                    val screenText = svc?.readScreen()?.take(1000) ?: ""
                    val client = GeminiClient(apiKey)
                    val answer = client.chat(
                        "Tum screen analyzer ho. Screen text se batao user ke goal ke liye kya karna chahiye. Short jawab.",
                        "", "Goal: $goal\nScreen:\n$screenText"
                    ).getOrNull()
                    if (answer != null) {
                        if (appPolicy.useCache) cache.put(screenFingerprint(pkg), answer)
                        return@withContext PerceptionResult(3, answer, screenText)
                    }
                }
            } else if (!appPolicy.allowScreenshot) {
                Log.d("Perceive", "🚫 Is app me screenshot allowed nahi (policy)")
            }

            // Kuch na mila to dump wapas do
            val text = svc?.readScreen()?.take(800) ?: ""
            PerceptionResult(1, "Screen:\n$text", text)
        }

    /** Screen dump goal ke liye kaafi hai ya nahi? */
    private fun isDumpSufficient(text: String, goal: String): Boolean {
        // Agar goal me koi specific cheez dhoondhni hai aur wo text me hai → kaafi
        val keywords = goal.lowercase().split(" ").filter { it.length > 3 }
        val matches = keywords.count { text.lowercase().contains(it) }
        // Kam se kam 1 keyword mile ya text lamba ho → dump kaafi
        return matches > 0 || text.length > 200
    }

    /** Screen ka fingerprint (cache key) */
    private fun screenFingerprint(pkg: String): String {
        val svc = JarvisAccessibilityService.instance
        val text = svc?.readScreen()?.take(500) ?: ""
        val raw = "$pkg:${text.hashCode()}"
        return MessageDigest.getInstance("MD5")
            .digest(raw.toByteArray())
            .joinToString("") { "%02x".format(it) }
    }

    /** On-device color analysis (Tier 2 helper) — dominant colors nikalo */
    fun analyzeColors(bitmap: Bitmap): Map<String, Int> {
        val w = bitmap.width
        val h = bitmap.height
        val counts = mutableMapOf<String, Int>()
        // Har 10th pixel sample karo (fast!)
        for (y in 0 until h step 10) {
            for (x in 0 until w step 10) {
                val pixel = bitmap.getPixel(x, y)
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF
                val name = when {
                    r > 150 && g < 100 && b < 100 -> "red"
                    r < 100 && g > 150 && b < 100 -> "green"
                    r < 100 && g < 100 && b > 150 -> "blue"
                    r > 150 && g > 150 && b < 100 -> "yellow"
                    r > 200 && g > 200 && b > 200 -> "white"
                    r < 60 && g < 60 && b < 60 -> "black"
                    else -> "other"
                }
                counts[name] = (counts[name] ?: 0) + 1
            }
        }
        return counts
    }
}

/**
 * SCREEN CACHE — purani screens yaad rakho! 🧠
 * Same screen dobara dikhe → dobara analyze mat karo → ₹0!
 */
class ScreenCache(maxSize: Int = 100) {
    private val map = object : LinkedHashMap<String, String>(maxSize, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean {
            return size > maxSize
        }
    }

    @Synchronized fun get(key: String): String? = map[key]
    @Synchronized fun put(key: String, value: String) { map[key] = value }
    @Synchronized fun clear() { map.clear() }
    @Synchronized fun size(): Int = map.size
}
