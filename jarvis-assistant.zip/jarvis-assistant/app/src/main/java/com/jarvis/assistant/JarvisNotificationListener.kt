package com.jarvis.assistant

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import java.util.ArrayDeque
import kotlinx.coroutines.launch

/**
 * NOTIFICATION LISTENER — Jarvis ki "khabar" wali aankh 👁️
 *
 * Phone pe aane wali notifications padhta hai:
 * - OTP auto-detect (bolke bata sakta hai)
 * - Important messages / delivery updates track karta hai
 * - AutonomyEngine ko context deta hai
 *
 * User ko Settings > Notifications > "Jarvis" ko access dena hoga.
 * Privacy: saara data phone me hi rehta hai, kahin nahi jata.
 */
class JarvisNotificationListener : NotificationListenerService() {

    data class NotifInfo(
        val app: String,
        val title: String,
        val text: String,
        val time: Long,
        val isOtp: Boolean = false
    )

    companion object {
        private const val TAG = "JarvisNotif"
        private const val MAX_KEEP = 30
        private val recent = ArrayDeque<NotifInfo>()

        @Synchronized
        fun getRecent(): List<NotifInfo> = recent.toList()

        @Synchronized
        private fun add(n: NotifInfo) {
            recent.addFirst(n)
            while (recent.size > MAX_KEEP) recent.removeLast()
        }

        private val OTP_REGEX = Regex("\\b\\d{4,8}\\b")

        /** Kya ye OTP jaisa lag raha hai? */
        fun looksLikeOtp(title: String, text: String): Boolean {
            val combined = "$title $text"
            return OTP_REGEX.containsMatchIn(combined) &&
                    combined.contains(Regex("otp|verification|code|kode", RegexOption.IGNORE_CASE))
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            val pkg = sbn.packageName
            // Khud ki aur system noise wali notifications skip karo
            if (pkg == packageName) return
            if (pkg in listOf("android", "com.android.systemui")) return

            val extras = sbn.notification.extras
            val title = extras.getCharSequence("android.title")?.toString() ?: ""
            val text = extras.getCharSequence("android.text")?.toString() ?: ""
            if (title.isBlank() && text.isBlank()) return
            // Ongoing (music, downloads) skip karo
            if (sbn.isOngoing) return

            val appLabel = try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
            } catch (_: Exception) { pkg }

            val isOtp = looksLikeOtp(title, text)
            add(NotifInfo(appLabel, title, text, System.currentTimeMillis(), isOtp))

            if (isOtp) {
                Log.d(TAG, "OTP aaya: $appLabel")
                // OTP aate hi bolke batao (agar autonomous mode ON hai)
                if (AutonomousService.isEnabled(this)) {
                    val code = OTP_REGEX.find("$title $text")?.value ?: ""
                    VoiceManager.speakStatic(this, "OTP aaya hai: ${code.toCharArray().joinToString(" ")}")
                }
            }

            // 🔮 ULTRAGOD: Automation rules check karo!
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                try {
                    RuleEngine(this@JarvisNotificationListener).onNotification(appLabel, title, text)
                } catch (e: Exception) {
                    Log.e(TAG, "rule check fail: ${e.message}")
                }
            }

            // Important notification → turant think cycle
            if (AutonomousService.isEnabled(this) && isImportant(pkg, title, text)) {
                startService(
                    android.content.Intent(this, AutonomousService::class.java).apply {
                        action = AutonomousService.ACTION_THINK_NOW
                    }
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "notif error: ${e.message}")
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {}

    /** Kaunsi notifications "important" hain? */
    private fun isImportant(pkg: String, title: String, text: String): Boolean {
        val t = "$title $text".lowercase()
        // Banking / money alerts
        if (t.contains(Regex("debited|credited|transaction|payment|upi"))) return true
        // Delivery
        if (t.contains(Regex("delivered|shipped|out for delivery|arriving"))) return true
        // OTP already handled separately
        return false
    }
}
