package com.jarvis.assistant.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [Memory::class, Reminder::class, Macro::class, PendingApproval::class,
                TaskCheckpoint::class, Skill::class, AutomationRule::class],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun memoryDao(): MemoryDao
    abstract fun reminderDao(): ReminderDao
    abstract fun macroDao(): MacroDao
    abstract fun approvalDao(): ApprovalDao
    abstract fun taskDao(): TaskDao
    abstract fun skillDao(): SkillDao
    abstract fun ruleDao(): RuleDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "jarvis.db"
                ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
            }
    }
}
