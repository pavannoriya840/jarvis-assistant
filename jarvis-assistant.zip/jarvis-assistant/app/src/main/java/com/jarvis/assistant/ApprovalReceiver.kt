package com.jarvis.assistant

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.jarvis.assistant.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Approval ka jawab: user ne notification me "Haan, kar do" ya "Rehne do" dabaya.
 */
class ApprovalReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(AutonomyEngine.EXTRA_APPROVAL_ID, -1)
        if (id < 0) return

        // Notification hatao
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(id.toInt())

        CoroutineScope(Dispatchers.IO).launch {
            val dao = AppDatabase.get(context).approvalDao()
            // Purane approvals saaf karo (24h se purane)
            dao.prune(System.currentTimeMillis() - 24 * 60 * 60 * 1000L)

            when (intent.action) {
                AutonomyEngine.ACTION_APPROVE -> {
                    val approval = dao.byId(id)
                    if (approval == null) {
                        Log.d("JarvisAuto", "Approval $id nahi mila (expire ho gaya?)")
                        return@launch
                    }
                    dao.deleteById(id)
                    try {
                        val result = AutonomyEngine(context).executeApproved(approval)
                        Log.d("JarvisAuto", "Approved action done: $result")
                        VoiceManager.speakStatic(context, result)
                    } catch (e: Exception) {
                        Log.e("JarvisAuto", "Approved action fail: ${e.message}")
                    }
                }
                AutonomyEngine.ACTION_DENY -> {
                    dao.deleteById(id)
                    Log.d("JarvisAuto", "User ne mana kiya (approval $id)")
                    // Seekho: user ne mana kiya — is type ke suggestion kam karo
                    MemoryManager(context).remember(
                        "learning",
                        "User ne autonomous suggestion mana kiya",
                        importance = 4
                    )
                }
            }
        }
    }
}
