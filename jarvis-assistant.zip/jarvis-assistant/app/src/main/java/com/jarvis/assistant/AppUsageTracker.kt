package com.jarvis.assistant

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Process
import android.provider.Settings
import android.util.Log

/**
 * APP USAGE TRACKER — tumhari aadatien seekhne ke liye 📊
 *
 * UsageStats se pata chalta hai:
 * - Kaunsa app kab khola (time patterns)
 * - Kitni der use kiya
 *
 * Ye data RoutineLearner ko milta hai → Jarvis aur smart suggestions deta hai.
 * Jaise: "Roz raat 10 baje YouTube kholte ho" → routine ban jayegi!
 *
 * Permission: Settings > Special app access > Usage access > Jarvis ON karna hoga.
 */
class AppUsageTracker(private val context: Context) {

    fun hasPermission(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun openSettings() {
        context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }

    /** Aaj sabse zyada use kiye apps (package → minutes) */
    fun getTopAppsToday(limit: Int = 5): List<Pair<String, Long>> {
        if (!hasPermission()) return emptyList()
        return try {
            val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val start = now - 24 * 60 * 60 * 1000L
            val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, now)
                ?: return emptyList()
            stats.filter { it.totalTimeInForeground > 60 * 1000 } // 1 min se zyada
                .sortedByDescending { it.totalTimeInForeground }
                .take(limit)
                .map {
                    val label = try {
                        val pm = context.packageManager
                        pm.getApplicationLabel(pm.getApplicationInfo(it.packageName, 0)).toString()
                    } catch (_: Exception) { it.packageName }
                    label to (it.totalTimeInForeground / 60000)
                }
        } catch (e: Exception) {
            Log.e("JarvisUsage", "usage error: ${e.message}")
            emptyList()
        }
    }

    /** Is waqt kaunsa app foreground me hai? */
    fun currentApp(): String {
        if (!hasPermission()) return ""
        return try {
            val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val events = usm.queryEvents(now - 60 * 1000L, now)
            var lastPkg = ""
            val event = android.app.usage.UsageEvents.Event()
            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                if (event.eventType == android.app.usage.UsageEvents.Event.MOVE_TO_FOREGROUND) {
                    lastPkg = event.packageName
                }
            }
            lastPkg
        } catch (e: Exception) {
            ""
        }
    }
}
