package com.jarvis.assistant

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

/**
 * PROACTIVE ENGINE: Bina puche sahi time pe sahi suggestion.
 *
 * Examples:
 * - Subah 9 baje: "Roz is time Zomato kholte ho, biryani order kar dun?"
 * - Raat 11 baje: "Kal subah 7 baje ka alarm lagaya nahi, laga dun?"
 * - 3 din se koi reminder pending: "Ye kaam abhi bhi pending hai"
 */
class ProactiveEngine(
    private val context: Context,
    private val onSuggest: (String) -> Unit
) {
    private val scope = CoroutineScope(Dispatchers.IO)
    private val routineLearner = RoutineLearner(context)
    private val memoryManager = MemoryManager(context)

    /** App khulne / periodic check pe call karo */
    fun check(onDone: () -> Unit = {}) {
        scope.launch {
            val suggestions = mutableListOf<String>()

            // 1. Routine-based suggestions
            val routines = routineLearner.routineForNow()
            for (r in routines) {
                suggestions.add("⏰ Routine: ${r.summary}\nKya main ye abhi kar dun?")
            }

            // 2. Pending reminders
            val dao = com.jarvis.assistant.data.AppDatabase.get(context).reminderDao()
            val upcoming = dao.upcoming().take(3)
            for (rem in upcoming) {
                val inMins = (rem.triggerAt - System.currentTimeMillis()) / 60000
                if (inMins in 0..120) {
                    suggestions.add("📌 ${inMins} min me: ${rem.title}")
                }
            }

            // 3. Time-based smart nudges
            val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            when (hour) {
                in 6..8 -> {
                    // Subah: aaj ka plan pucho (sirf agar koi routine nahi mili)
                    if (suggestions.isEmpty()) {
                        suggestions.add("☀️ Good morning! Aaj ka kya plan hai? Kuch yaad dilana ho to batao.")
                    }
                }
                22, 23 -> {
                    suggestions.add("🌙 Raat ho gayi! Kal subah ke liye alarm ya reminder lagana hai?")
                }
            }

            if (suggestions.isNotEmpty()) {
                // Sabse pehli (most relevant) suggestion do
                kotlinx.coroutines.withContext(Dispatchers.Main) {
                    onSuggest(suggestions.first())
                }
            }
            onDone()
        }
    }

    /** Har user command pe routine learner ko feed karo */
    fun observeCommand(command: String) {
        routineLearner.observe(command)
    }

    /** Subah ka briefing text (CrossAppFlow "morning" quick flow ke liye) */
    suspend fun morningBriefing(): String = kotlinx.coroutines.withContext(Dispatchers.IO) {
        val sb = StringBuilder()
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        sb.append(if (hour < 12) "☀️ Good morning!" else "Namaste!")
        val dao = com.jarvis.assistant.data.AppDatabase.get(context).reminderDao()
        val upcoming = dao.upcoming().take(5)
        if (upcoming.isNotEmpty()) {
            sb.append("\n📌 Aaj ke reminders:")
            for (rem in upcoming) sb.append("\n- ${rem.title}")
        }
        val routines = routineLearner.routineForNow()
        if (routines.isNotEmpty()) {
            sb.append("\n⏰ Routine: ${routines.first().summary}")
        }
        sb.toString()
    }
}
