package com.jarvis.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.jarvis.assistant.data.AppDatabase
import com.jarvis.assistant.data.TaskCheckpoint
import kotlinx.coroutines.*
import java.util.UUID

/**
 * LONG-TASK ENGINE — ghanto chalne wale tasks! ⏳
 *
 * Features:
 * - CHECKPOINT: har step ke baad progress save → crash/restart ke baad WAHIN SE resume!
 * - Progress notification: "127/200 done (63%)" + Pause/Resume/Stop buttons
 * - Human-like pacing: har action ke beech random delay (bot detection se bachao)
 * - Auto-retry: step fail → 3 baar retry → phir bhi fail to pause karke user ko batao
 *
 * Task types: "generic" | "chat" (WhatsApp) | "instagram" | "game"
 */
class LongTaskEngine(private val context: Context) {

    companion object {
        const val CHANNEL_ID = "jarvis_longtask"
        const val ACTION_PAUSE = "com.jarvis.assistant.TASK_PAUSE"
        const val ACTION_RESUME = "com.jarvis.assistant.TASK_RESUME"
        const val ACTION_STOP = "com.jarvis.assistant.TASK_STOP"
        const val EXTRA_TASK_ID = "task_id"
    }

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val activeJobs = mutableMapOf<String, Job>()

    data class TaskHandle(val taskId: String, val goal: String)

    /**
     * Naya lamba task shuru karo.
     * @param worker har step pe call hoga: (stepIndex, taskId) -> Boolean (success?)
     */
    suspend fun startTask(
        goal: String,
        taskType: String,
        totalSteps: Int,
        worker: suspend (step: Int, taskId: String) -> Boolean,
        onProgress: (done: Int, total: Int) -> Unit = { _, _ -> }
    ): TaskHandle = withContext(Dispatchers.IO) {
        val taskId = UUID.randomUUID().toString().take(8)
        val dao = AppDatabase.get(context).taskDao()
        dao.insert(TaskCheckpoint(taskId, goal, taskType, "running", 0, totalSteps))

        val job = scope.launch {
            var step = 0
            while (isActive && step < totalSteps) {
                // Pause check
                val cp = dao.byId(taskId)
                if (cp == null || cp.status == "failed") break
                if (cp.status == "paused") {
                    delay(2000)
                    continue
                }

                showProgress(taskId, goal, step, totalSteps)
                onProgress(step, totalSteps)

                // Step execute karo (3 attempts)
                var ok = false
                repeat(3) { attempt ->
                    if (ok) return@repeat
                    try {
                        ok = worker(step, taskId)
                    } catch (e: Exception) {
                        ok = false
                    }
                    if (!ok && attempt < 2) delay(3000)
                }

                if (!ok) {
                    // 3 fail → pause karke user ko batao
                    dao.update(taskId, "paused", step, "{}")
                    notifyUser("Jarvis ⏸️", "Task ruk gaya step $step pe: $goal. Resume karne ke liye notification dabao.")
                    break
                }

                step++
                dao.update(taskId, "running", step, "{}")

                // Human-like pacing: 2-6 sec random delay
                delay((2000 + Math.random() * 4000).toLong())
            }

            val final = dao.byId(taskId)
            if (final != null && final.currentStep >= totalSteps) {
                dao.update(taskId, "done", step, "{}")
                notifyUser("Jarvis 🎉", "Task complete! $goal")
                VoiceManager.speakStatic(context, "Task complete ho gaya: $goal")
            }
            cancelNotification(taskId)
            activeJobs.remove(taskId)
        }
        activeJobs[taskId] = job
        TaskHandle(taskId, goal)
    }

    /** Pause hua task resume karo (wahin se jahan ruka tha!) */
    suspend fun resumeTask(taskId: String) = withContext(Dispatchers.IO) {
        val dao = AppDatabase.get(context).taskDao()
        val cp = dao.byId(taskId) ?: return@withContext
        if (cp.status == "done") return@withContext
        dao.update(taskId, "running", cp.currentStep, cp.stateJson)
        // Note: worker dobara attach karna hoga — caller resumeTaskWithWorker use kare
    }

    suspend fun pauseTask(taskId: String) = withContext(Dispatchers.IO) {
        AppDatabase.get(context).taskDao().update(taskId, "paused",
            AppDatabase.get(context).taskDao().byId(taskId)?.currentStep ?: 0, "{}")
        activeJobs[taskId]?.cancel()
    }

    suspend fun stopTask(taskId: String) = withContext(Dispatchers.IO) {
        AppDatabase.get(context).taskDao().update(taskId, "failed",
            AppDatabase.get(context).taskDao().byId(taskId)?.currentStep ?: 0, "{}")
        activeJobs[taskId]?.cancel()
        activeJobs.remove(taskId)
        cancelNotification(taskId)
        notifyUser("Jarvis 🛑", "Task rok diya gaya.")
    }

    suspend fun resumableTasks(): List<TaskCheckpoint> = withContext(Dispatchers.IO) {
        AppDatabase.get(context).taskDao().resumable()
    }

    // ============ Progress Notification ============

    private fun showProgress(taskId: String, goal: String, done: Int, total: Int) {
        ensureChannel()
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val pct = if (total > 0) (done * 100 / total) else 0

        val pausePi = pendingAction(ACTION_PAUSE, taskId, taskId.hashCode())
        val stopPi = pendingAction(ACTION_STOP, taskId, taskId.hashCode() + 1)

        val notif = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Jarvis kaam kar raha hai 🤖 ($pct%)")
            .setContentText("$done/$total — $goal")
            .setProgress(total, done, false)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Pause", pausePi)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPi)
            .build()
        nm.notify(taskId.hashCode(), notif)
    }

    private fun cancelNotification(taskId: String) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(taskId.hashCode())
    }

    private fun notifyUser(title: String, text: String) {
        ensureChannel()
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notif = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .build()
        nm.notify(System.currentTimeMillis().toInt(), notif)
    }

    private fun pendingAction(action: String, taskId: String, reqCode: Int): PendingIntent {
        val intent = Intent(context, TaskControlReceiver::class.java).apply {
            this.action = action
            putExtra(EXTRA_TASK_ID, taskId)
        }
        return PendingIntent.getBroadcast(
            context, reqCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun ensureChannel() {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Jarvis Long Tasks", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(ch)
        }
    }
}
