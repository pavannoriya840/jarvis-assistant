package com.jarvis.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.jarvis.assistant.data.AppDatabase
import com.jarvis.assistant.data.PendingApproval
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import java.text.SimpleDateFormat
import java.util.*

/**
 * AUTONOMY ENGINE — Jarvis ka "khud sochne wala" dimaag 🧠
 *
 * Har think-cycle me:
 * 1. Context jama karo (time, pending reminders, notifications, routines, app usage)
 * 2. Gemini se pucho: "kuch karna chahiye?"
 * 3. Actions ko classify karo:
 *    - SAFE → khud execute karo (suchna dena, reminder lagana, info)
 *    - NEEDS_APPROVAL → user se pucho (paise, message, delete, bahari action)
 * 4. Jo kiya, use memory me log karo (seekhta jaye)
 *
 * GUARDRAILS (kabhi nahi todega):
 * - Paise kharch / order place → hamesha approval
 * - Kisi ko message bhejna → hamesha approval
 * - Kuch delete karna → hamesha approval
 */
class AutonomyEngine(private val context: Context) {

    companion object {
        const val CHANNEL_ID = "jarvis_autonomy"
        const val ACTION_APPROVE = "com.jarvis.assistant.APPROVE"
        const val ACTION_DENY = "com.jarvis.assistant.DENY"
        const val EXTRA_APPROVAL_ID = "approval_id"

        private val THINK_PROMPT = """
            Tum Jarvis ke autonomous planner ho. Tumhe current context diya jayega.
            Faisla karo: kya abhi user ke liye kuch USEFUL karna chahiye?

            Sirf JSON array me jawab do (koi extra text nahi). Har item:
            {"type": "notify|remind|open_app|run_macro|suggest", "title": "...", "detail": "...", "risk": "safe|needs_approval", "payload": {...}}

            Types:
            - notify: sirf ek suchna (safe)
            - remind: reminder lagao — payload: {"title": "...", "in_minutes": 30} (safe)
            - open_app: app kholo — payload: {"app_name": "..."} (needs_approval, kyunki screen badal jayegi)
            - run_macro: macro chalao — payload: {"macro_name": "..."} (needs_approval)
            - suggest: user se sawal pucho — payload: {"question": "..."} (safe)

            Risk rules (STRICT):
            - "safe": notify, remind, suggest — inme user ka kuch kharch nahi, kuch delete nahi
            - "needs_approval": open_app, run_macro, paise/message/delete wali har cheez
            - Paise kharch karne wala ya message bhejne wala action KABHI suggest mat karo

            Agar kuch karne layak nahi lagta to khaali array [] do. Max 2 actions.
            Har roz ke routine time pe halka reminder OK hai, lekin har cycle me spam mat karo.
        """.trimIndent()
    }

    data class AutoAction(
        val type: String,
        val title: String,
        val detail: String,
        val risk: String,
        val payload: JsonObject
    )

    private val json = Json { ignoreUnknownKeys = true }

    /**
     * Ek think cycle: context → Gemini → actions → execute/approve
     * Returns: kya-kya kiya uska summary
     */
    suspend fun think(): String = withContext(Dispatchers.IO) {
        val apiKey = PromptManager(context).getApiKey()
        if (apiKey.isBlank()) return@withContext "API key nahi hai"

        val ctx = gatherContext()
        val client = SmartGeminiClient(apiKey)

        // Gemini se actions mango (plain chat, JSON expected)
        val simple = GeminiClient(apiKey)
        val resp = simple.chat(
            systemPrompt = THINK_PROMPT,
            memoryContext = "",
            userMessage = "Current context:\n$ctx\n\nActions (JSON array only):"
        ).getOrNull() ?: return@withContext "Gemini se jawab nahi aaya"

        val actions = parseActions(resp)
        if (actions.isEmpty()) return@withContext "Kuch karne layak nahi mila"

        val done = mutableListOf<String>()
        for (a in actions.take(2)) {
            if (a.risk == "safe") {
                executeSafe(a)
                done.add("✅ ${a.title}")
            } else {
                requestApproval(a)
                done.add("❓ Approval manga: ${a.title}")
            }
            // Jo kiya use yaad rakho (spam rokne ke liye)
            MemoryManager(context).remember(
                "fact",
                "Autonomous action (${timeNow()}): ${a.title} — ${a.detail}".take(150),
                importance = 3
            )
        }
        done.joinToString("\n")
    }

    /** Saare context ek jagah jama karo */
    private suspend fun gatherContext(): String {
        val sb = StringBuilder()
        val cal = Calendar.getInstance()
        sb.append("Time: ${timeNow()}, Day: ${dayName(cal.get(Calendar.DAY_OF_WEEK))}\n")

        // Pending reminders
        val db = AppDatabase.get(context)
        val upcoming = db.reminderDao().upcoming().take(5)
        if (upcoming.isNotEmpty()) {
            sb.append("Pending reminders:\n")
            for (r in upcoming) {
                val mins = (r.triggerAt - System.currentTimeMillis()) / 60000
                sb.append("- ${r.title} (${if (mins < 0) "overdue" else "$mins min me"})\n")
            }
        }

        // Recent notifications (important wali)
        val notifs = JarvisNotificationListener.getRecent().take(8)
        if (notifs.isNotEmpty()) {
            sb.append("Recent notifications:\n")
            for (n in notifs) sb.append("- [${n.app}] ${n.title}: ${n.text.take(80)}\n")
        }

        // Aaj ki learned routines
        val routines = RoutineLearner(context).routineForNow().take(3)
        if (routines.isNotEmpty()) {
            sb.append("Learned routines (is time pe):\n")
            for (r in routines) sb.append("- ${r.summary}\n")
        }

        // Top app usage aaj
        val usage = AppUsageTracker(context).getTopAppsToday(5)
        if (usage.isNotEmpty()) {
            val appNames = usage.joinToString { u -> u.first }
            sb.append("Aaj zyada use kiye apps: $appNames\n")
        }

        // Pichhle autonomous actions (spam rokne ke liye)
        val recentActions = db.memoryDao().search("Autonomous action", 5)
        if (recentActions.isNotEmpty()) {
            sb.append("Pichhle kuch actions (repeat mat karo):\n")
            for (m in recentActions) sb.append("- ${m.summary.take(100)}\n")
        }

        return sb.toString()
    }

    private fun parseActions(resp: String): List<AutoAction> {
        return try {
            // JSON array nikalo (```json blocks handle karo)
            val clean = resp.substringAfter("[").substringBeforeLast("]")
            val arr = json.parseToJsonElement("[$clean]").jsonArray
            arr.mapNotNull { el ->
                val o = el.jsonObject
                AutoAction(
                    type = o["type"]?.jsonPrimitive?.content ?: return@mapNotNull null,
                    title = o["title"]?.jsonPrimitive?.content ?: "",
                    detail = o["detail"]?.jsonPrimitive?.content ?: "",
                    risk = o["risk"]?.jsonPrimitive?.content ?: "needs_approval",
                    payload = o["payload"]?.jsonObject ?: buildJsonObject {}
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** SAFE actions khud execute karo */
    private suspend fun executeSafe(a: AutoAction) {
        when (a.type) {
            "notify", "suggest" -> {
                notifyUser("Jarvis 💡", "${a.title}\n${a.detail}")
                // Bolke bhi batao agar app khuli hai
                VoiceManager.speakStatic(context, "${a.title}. ${a.detail}")
            }
            "remind" -> {
                val title = a.payload["title"]?.jsonPrimitive?.content ?: a.title
                val mins = a.payload["in_minutes"]?.jsonPrimitive?.intOrNull ?: 30
                TaskScheduler(context).apply {
                    ensureChannel()
                    schedule(title, a.detail, System.currentTimeMillis() + mins * 60000L)
                }
                notifyUser("Jarvis ⏰", "Reminder lagaya: $title")
            }
        }
    }

    /** RISKY actions ke liye user se approval mango */
    private suspend fun requestApproval(a: AutoAction) {
        val id = AppDatabase.get(context).approvalDao().insert(
            PendingApproval(
                title = a.title,
                detail = a.detail,
                actionType = a.type,
                payloadJson = a.payload.toString()
            )
        )
        ensureChannel()
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val approveIntent = Intent(context, ApprovalReceiver::class.java).apply {
            action = ACTION_APPROVE
            putExtra(EXTRA_APPROVAL_ID, id)
        }
        val denyIntent = Intent(context, ApprovalReceiver::class.java).apply {
            action = ACTION_DENY
            putExtra(EXTRA_APPROVAL_ID, id)
        }
        val approvePi = PendingIntent.getBroadcast(
            context, (id * 2).toInt(), approveIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val denyPi = PendingIntent.getBroadcast(
            context, (id * 2 + 1).toInt(), denyIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Jarvis puch raha hai 🤖")
            .setContentText(a.title)
            .setStyle(NotificationCompat.BigTextStyle().bigText("${a.title}\n${a.detail}"))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .addAction(android.R.drawable.ic_menu_send, "Haan, kar do", approvePi)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Rehne do", denyPi)
            .setAutoCancel(true)
            .build()
        nm.notify(id.toInt(), notif)
    }

    /** Approval milne pe action execute karo */
    suspend fun executeApproved(approval: PendingApproval): String = withContext(Dispatchers.Main) {
        return@withContext when (approval.actionType) {
            "open_app" -> {
                val appName = try {
                    json.parseToJsonElement(approval.payloadJson).jsonObject["app_name"]?.jsonPrimitive?.content
                } catch (_: Exception) { null } ?: return@withContext "App naam nahi mila"
                val pm = context.packageManager
                val match = pm.getInstalledApplications(0).firstOrNull {
                    val label = try { pm.getApplicationLabel(it).toString() } catch (_: Exception) { "" }
                    label.contains(appName, ignoreCase = true)
                } ?: return@withContext "$appName nahi mila"
                val intent = pm.getLaunchIntentForPackage(match.packageName)
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    "$appName khol diya ✅"
                } else "Khol nahi paya"
            }
            "run_macro" -> {
                val macroName = try {
                    json.parseToJsonElement(approval.payloadJson).jsonObject["macro_name"]?.jsonPrimitive?.content
                } catch (_: Exception) { null } ?: return@withContext "Macro naam nahi mila"
                // Self-healing macro chalao
                val dao = AppDatabase.get(context).macroDao()
                val macro = withContext(Dispatchers.IO) { dao.byName(macroName.lowercase()) }
                    ?: return@withContext "Macro '$macroName' nahi mila"
                val steps = SelfHealingMacro.parseSteps(macro.stepsJson)
                val apiKey = PromptManager(context).getApiKey()
                val report = SelfHealingMacro(context).execute(steps, macroName, apiKey) {}
                report.message
            }
            "remind" -> {
                val payload = try { json.parseToJsonElement(approval.payloadJson).jsonObject }
                catch (_: Exception) { buildJsonObject {} }
                val title = payload["title"]?.jsonPrimitive?.content ?: approval.title
                val mins = payload["in_minutes"]?.jsonPrimitive?.intOrNull ?: 30
                TaskScheduler(context).apply {
                    ensureChannel()
                    schedule(title, approval.detail, System.currentTimeMillis() + mins * 60000L)
                }
                "Reminder lagaya: $title ✅"
            }
            else -> "Ye action type support nahi: ${approval.actionType}"
        }
    }

    private fun notifyUser(title: String, text: String) {
        ensureChannel()
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notif = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        nm.notify(System.currentTimeMillis().toInt(), notif)
    }

    private fun ensureChannel() {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Jarvis Autonomous", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "Jarvis ke autonomous actions aur approvals"
            nm.createNotificationChannel(ch)
        }
    }

    private fun timeNow(): String =
        SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())

    private fun dayName(d: Int): String = when (d) {
        Calendar.MONDAY -> "Somvaar"; Calendar.TUESDAY -> "Mangalvaar"
        Calendar.WEDNESDAY -> "Budhvaar"; Calendar.THURSDAY -> "Guruvaar"
        Calendar.FRIDAY -> "Shukravaar"; Calendar.SATURDAY -> "Shanivaar"
        Calendar.SUNDAY -> "Ravivaar"; else -> ""
    }
}
