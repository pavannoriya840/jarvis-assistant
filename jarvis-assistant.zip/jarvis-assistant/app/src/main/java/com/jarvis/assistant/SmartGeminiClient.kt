package com.jarvis.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * SMART Gemini client with FUNCTION CALLING + VISION.
 *
 * Agentic loop:
 * 1. Gemini ko prompt + tools bhejo
 * 2. Agar wo function call kare → execute karo → result wapas bhejo
 * 3. Jab tak wo final text jawab na de, loop chalao (max 5 rounds)
 */
class SmartGeminiClient(private val apiKey: String) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    private val json = Json { ignoreUnknownKeys = true }

    data class AgentResult(
        val finalReply: String,
        val functionsCalled: List<String>
    )

    /**
     * Agentic chat: Gemini tools use kar sakta hai.
     * @param executor function ko execute karne wala lambda
     */
    suspend fun agenticChat(
        systemPrompt: String,
        memoryContext: String,
        screenContext: String = "",
        userMessage: String,
        executor: suspend (name: String, args: JsonObject) -> GeminiFunctions.FunctionResult,
        model: String = "gemini-2.0-flash",
        maxRounds: Int = 5
    ): Result<AgentResult> = withContext(Dispatchers.IO) {
        try {
            val history = mutableListOf<JsonObject>()

            // System + user ka pehla message
            val firstPrompt = buildString {
                append(systemPrompt)
                append("\n\nTumhare paas ye TOOLS hain — zaroorat ho to use karo. Ek jawab me multiple tool calls kar sakte ho. Tool ka result milne ke baad aage decide karo.")
                append("\n\n[MEMORY]\n${memoryContext.ifBlank { "(koi nahi)" }}")
                if (screenContext.isNotBlank()) {
                    append("\n\n[CURRENT SCREEN]\n$screenContext")
                }
                append("\n\n[USER]: $userMessage")
            }
            history.add(userTurn(firstPrompt))

            val called = mutableListOf<String>()
            var rounds = 0

            while (rounds < maxRounds) {
                rounds++
                val response = callGemini(history, model).getOrElse { return@withContext Result.failure(it) }

                // Kya Gemini ne function call kiya?
                val functionCalls = extractFunctionCalls(response)
                if (functionCalls.isEmpty()) {
                    // Final text jawab
                    val text = extractText(response) ?: "Kuch samajh nahi aaya"
                    return@withContext Result.success(AgentResult(text.trim(), called))
                }

                // Har function call execute karo
                history.add(modelTurnWithCalls(response))
                for ((name, args) in functionCalls) {
                    called.add(name)
                    val result = executor(name, args)
                    history.add(functionResultTurn(name, result))
                }
            }

            Result.success(AgentResult("Bahut steps ho gaye, ruk raha hun. Bolo kya karun?", called))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * VISION: screenshot + prompt bhejo, Gemini image dekh ke jawab dega.
     * @param imageBase64 JPEG ka base64
     */
    suspend fun askWithVision(
        imageBase64: String,
        question: String,
        model: String = "gemini-2.0-flash"
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val body = buildJsonObject {
                putJsonArray("contents") {
                    addJsonObject {
                        putJsonArray("parts") {
                            addJsonObject { put("text", question) }
                            addJsonObject {
                                putJsonObject("inline_data") {
                                    put("mime_type", "image/jpeg")
                                    put("data", imageBase64)
                                }
                            }
                        }
                    }
                }
                putJsonObject("generationConfig") {
                    put("temperature", 0.3)
                    put("maxOutputTokens", 800)
                }
            }.toString()

            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey")
                .post(body.toRequestBody("application/json".toMediaType()))
                .build()

            http.newCall(request).execute().use { resp ->
                val text = resp.body?.string() ?: ""
                if (!resp.isSuccessful) return@withContext Result.failure(Exception("Vision error ${resp.code}"))
                val parsed = json.parseToJsonElement(text).jsonObject
                val reply = parsed["candidates"]?.jsonArray?.firstOrNull()?.jsonObject
                    ?.get("content")?.jsonObject?.get("parts")?.jsonArray
                    ?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content
                    ?: return@withContext Result.failure(Exception("Empty vision response"))
                Result.success(reply.trim())
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ============ Internal ============

    private fun userTurn(text: String) = buildJsonObject {
        put("role", "user")
        putJsonArray("parts") { addJsonObject { put("text", text) } }
    }

    private fun modelTurnWithCalls(response: JsonObject): JsonObject {
        // Gemini ke response ko history me model turn ki tarah add karo
        val candidate = response["candidates"]?.jsonArray?.firstOrNull()?.jsonObject
        val content = candidate?.get("content")?.jsonObject
        return buildJsonObject {
            put("role", "model")
            put("parts", content?.get("parts") ?: buildJsonArray { })
        }
    }

    private fun functionResultTurn(name: String, result: GeminiFunctions.FunctionResult) = buildJsonObject {
        put("role", "function")
        putJsonArray("parts") {
            addJsonObject {
                putJsonObject("functionResponse") {
                    put("name", name)
                    putJsonObject("response") {
                        put("success", result.success.toString())
                        put("output", result.output)
                    }
                }
            }
        }
    }

    private suspend fun callGemini(history: List<JsonObject>, model: String): Result<JsonObject> {
        return try {
            val body = buildJsonObject {
                putJsonArray("contents") { history.forEach { add(it) } }
                putJsonArray("tools") {
                    addJsonObject {
                        putJsonArray("function_declarations") {
                            GeminiFunctions.definitions().forEach { add(it) }
                        }
                    }
                }
                putJsonObject("generationConfig") {
                    put("temperature", 0.5)
                    put("maxOutputTokens", 600)
                }
            }.toString()

            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey")
                .post(body.toRequestBody("application/json".toMediaType()))
                .build()

            http.newCall(request).execute().use { resp ->
                val text = resp.body?.string() ?: ""
                if (!resp.isSuccessful) {
                    return Result.failure(Exception("Gemini ${resp.code}: ${text.take(200)}"))
                }
                Result.success(json.parseToJsonElement(text).jsonObject)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun extractFunctionCalls(response: JsonObject): List<Pair<String, JsonObject>> {
        val out = mutableListOf<Pair<String, JsonObject>>()
        val parts = response["candidates"]?.jsonArray?.firstOrNull()?.jsonObject
            ?.get("content")?.jsonObject?.get("parts")?.jsonArray ?: return out
        for (part in parts) {
            val fc = part.jsonObject["functionCall"]?.jsonObject ?: continue
            val name = fc["name"]?.jsonPrimitive?.content ?: continue
            val args = fc["args"]?.jsonObject ?: buildJsonObject { }
            out.add(name to args)
        }
        return out
    }

    private fun extractText(response: JsonObject): String? {
        val parts = response["candidates"]?.jsonArray?.firstOrNull()?.jsonObject
            ?.get("content")?.jsonObject?.get("parts")?.jsonArray ?: return null
        return parts.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content
    }
}
