package com.jarvis.assistant

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("jarvis_settings")

/**
 * Jarvis apna system prompt khud edit kar sakta hai — aur user bhi Settings se.
 * Default prompt Hinglish Jarvis personality ke saath.
 */
class PromptManager(private val context: Context) {

    companion object {
        private val PROMPT_KEY = stringPreferencesKey("system_prompt")
        private val API_KEY = stringPreferencesKey("gemini_api_key")
        private val WAKE_WORD = stringPreferencesKey("wake_word")

        const val DEFAULT_PROMPT = """
            Tum JARVIS ho — user ke phone ka AI assistant, Iron Man ke Jarvis jaisa.
            Tum Hinglish me baat karte ho (Hindi + English mix), short aur decisive.
            Tumhare paas phone control karne ki powers hain: apps kholna, screen tap karna,
            text type karna, scroll karna, reminders lagana, macros chalana.

            Rules:
            - Hamesha pehle samjho user kya chahta hai, phir action lo.
            - Agar command me multiple steps hain, unhe order me karo.
            - Agar kuch unclear hai, ek chhota sawaal pucho — lamba lecture mat do.
            - Kabhi jhooth mat bolo — agar kuch nahi kar sakte, seedha batao.
            - User ki privacy ka khayal rakho — sensitive data bahar mat bhejo.
            - Jawab hamesha 2-4 lines me, to-the-point.
        """.trimIndent()
    }

    suspend fun getPrompt(): String =
        context.dataStore.data.map { it[PROMPT_KEY] ?: DEFAULT_PROMPT }.first()

    suspend fun setPrompt(prompt: String) {
        context.dataStore.edit { it[PROMPT_KEY] = prompt }
    }

    suspend fun resetPrompt() {
        context.dataStore.edit { it[PROMPT_KEY] = DEFAULT_PROMPT }
    }

    suspend fun getApiKey(): String =
        context.dataStore.data.map { it[API_KEY] ?: "" }.first()

    suspend fun setApiKey(key: String) {
        context.dataStore.edit { it[API_KEY] = key }
    }

    suspend fun getWakeWord(): String =
        context.dataStore.data.map { it[WAKE_WORD] ?: "jarvis" }.first()

    suspend fun setWakeWord(word: String) {
        context.dataStore.edit { it[WAKE_WORD] = word.lowercase() }
    }
}
