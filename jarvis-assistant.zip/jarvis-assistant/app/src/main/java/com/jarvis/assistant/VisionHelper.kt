package com.jarvis.assistant

import android.content.Context
import android.graphics.Bitmap
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import android.util.Base64
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume

/**
 * VISION: Screen ka screenshot lo → Gemini Vision ko bhejo.
 *
 * Fayda: Accessibility text se jo na samjhe (images, complex UI,
 * Zomato/Flipkart ke product cards), wo Gemini "dekh" ke batayega.
 *
 * Note: MediaProjection ke liye user se ek baar permission leni hogi.
 */
object VisionHelper {

    /**
     * Screenshot lo aur base64 JPEG banao.
     * MediaProjection already granted hona chahiye.
     */
    suspend fun captureScreenshot(
        context: Context,
        mediaProjection: MediaProjection,
        width: Int,
        height: Int,
        density: Int
    ): String? = suspendCancellableCoroutine { cont ->
        try {
            val reader = ImageReader.newInstance(width, height, android.graphics.PixelFormat.RGBA_8888, 2)
            val surface = reader.surface
            val virtualDisplay = mediaProjection.createVirtualDisplay(
                "jarvis_capture", width, height, density,
                android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                surface, null, Handler(Looper.getMainLooper())
            )

            // Thoda wait taaki frame aa jaye
            Handler(Looper.getMainLooper()).postDelayed({
                try {
                    val image = reader.acquireLatestImage()
                    if (image != null) {
                        val planes = image.planes
                        val buffer = planes[0].buffer
                        val pixelStride = planes[0].pixelStride
                        val rowStride = planes[0].rowStride
                        val rowPadding = rowStride - pixelStride * width

                        val bitmap = Bitmap.createBitmap(
                            width + rowPadding / pixelStride, height,
                            Bitmap.Config.ARGB_8888
                        )
                        bitmap.copyPixelsFromBuffer(buffer)
                        image.close()

                        // Crop + compress
                        val cropped = Bitmap.createBitmap(bitmap, 0, 0, width, height)
                        // Chhota karo taaki API fast ho (max 768px)
                        val scaled = scaleDown(cropped, 768)
                        val base64 = bitmapToBase64(scaled)
                        cropped.recycle()
                        scaled.recycle()
                        bitmap.recycle()

                        virtualDisplay.release()
                        reader.close()
                        cont.resume(base64)
                    } else {
                        virtualDisplay.release()
                        reader.close()
                        cont.resume(null)
                    }
                } catch (e: Exception) {
                    try { virtualDisplay.release() } catch (_: Exception) {}
                    try { reader.close() } catch (_: Exception) {}
                    cont.resume(null)
                }
            }, 400)
        } catch (e: Exception) {
            cont.resume(null)
        }
    }

    private fun scaleDown(bitmap: Bitmap, maxSize: Int): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= maxSize && h <= maxSize) return bitmap
        val ratio = maxSize.toFloat() / maxOf(w, h)
        return Bitmap.createScaledBitmap(bitmap, (w * ratio).toInt(), (h * ratio).toInt(), true)
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val out = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 70, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    /**
     * Screenshot leke Gemini se pucho: "Is screen pe [goal] ke liye kahan tap karun?"
     * Returns: coordinates ya action description
     */
    suspend fun askWhereToTap(
        context: Context,
        mediaProjection: MediaProjection?,
        width: Int, height: Int, density: Int,
        goal: String,
        apiKey: String
    ): String? {
        if (mediaProjection == null) return null
        val base64 = captureScreenshot(context, mediaProjection, width, height, density)
            ?: return null
        val client = SmartGeminiClient(apiKey)
        val question = """
            Ye phone ki screenshot hai. User ka goal: "$goal"
            Batao: goal achieve karne ke liye screen pe KAHAN tap karna chahiye?
            Jawab is format me do: x=<0-1000>, y=<0-1000>, reason=<ek line>
            Agar goal already complete dikh raha hai to "DONE" likho.
            Agar samajh na aaye to "UNCLEAR: <wajah>" likho.
        """.trimIndent()
        return client.askWithVision(base64, question).getOrNull()
    }
}
