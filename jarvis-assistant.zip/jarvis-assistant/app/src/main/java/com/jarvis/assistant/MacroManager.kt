package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import com.jarvis.assistant.data.AppDatabase
import com.jarvis.assistant.data.Macro
import com.jarvis.assistant.data.MacroStep
import kotlinx.coroutines.*
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Macros: user apne multi-step tasks record karke naam de sakta hai.
 * Phir sirf bolna hai — "Jarvis, [macro name] chalao".
 *
 * Example: "zomato order" macro = Zomato kholo → search tap → "biryani" type →
 * pehla result tap → add to cart → checkout tap
 */
class MacroManager(private val context: Context) {

    private val dao = AppDatabase.get(context).macroDao()
    private val scope = CoroutineScope(Dispatchers.IO)

    // Recording state
    private var recording: MutableList<MacroStep>? = null
    private var recordingName: String = ""

    fun startRecording(name: String) {
        recordingName = name.lowercase().trim()
        recording = mutableListOf()
    }

    fun recordStep(step: MacroStep) {
        recording?.add(step)
    }

    fun stopAndSave(onDone: (Boolean) -> Unit) {
        val steps = recording
        recording = null
        if (steps.isNullOrEmpty()) {
            onDone(false)
            return
        }
        scope.launch {
            val json = Json.encodeToString(steps)
            dao.insert(Macro(name = recordingName, stepsJson = json))
            withContext(Dispatchers.Main) { onDone(true) }
        }
    }

    fun isRecording(): Boolean = recording != null

    suspend fun listMacros(): List<Macro> = dao.all()

    suspend fun deleteMacro(macro: Macro) = dao.delete(macro)

    /**
     * Macro chalao — har step ko order me execute karo.
     * ScreenController (accessibility) ke through actions hote hain.
     */
    fun runMacro(name: String, onStep: (String) -> Unit, onDone: (Boolean, String) -> Unit) {
        scope.launch {
            val macro = dao.byName(name.lowercase().trim())
            if (macro == null) {
                withContext(Dispatchers.Main) { onDone(false, "Macro '$name' nahi mila") }
                return@launch
            }
            val steps: List<MacroStep> = try {
                Json.decodeFromString(macro.stepsJson)
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { onDone(false, "Macro corrupt hai") }
                return@launch
            }

            val svc = JarvisAccessibilityService.instance
            withContext(Dispatchers.Main) { onStep("Macro '${macro.name}' chala raha hun (${steps.size} steps)...") }

            for ((i, step) in steps.withIndex()) {
                withContext(Dispatchers.Main) { onStep("Step ${i + 1}/${steps.size}: ${step.type}") }
                val ok = withContext(Dispatchers.Main) { executeStep(step) }
                if (!ok) {
                    withContext(Dispatchers.Main) { onDone(false, "Step ${i + 1} fail hua (${step.type})") }
                    return@launch
                }
                delay(800) // har step ke beech thoda wait taaki UI load ho
            }
            withContext(Dispatchers.Main) { onDone(true, "Macro complete!") }
            Unit
        }
    }

    private suspend fun executeStep(step: MacroStep): Boolean {
        val svc = JarvisAccessibilityService.instance ?: return false
        return suspendCancellableCoroutine(null) { cont ->
            when (step.type) {
                "tap" -> svc.tap(step.x, step.y) { cont.resume(it) }
                "swipe" -> {
                    svc.swipe(step.x, step.y, step.x2, step.y2)
                    cont.resume(true)
                }
                "type" -> cont.resume(svc.typeText("", step.text))
                "launch" -> {
                    val intent = context.packageManager.getLaunchIntentForPackage(step.packageName)
                    if (intent != null) {
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(intent)
                        cont.resume(true)
                    } else cont.resume(false)
                }
                "back" -> cont.resume(svc.goBack())
                "wait" -> {
                    // wait step ko runMacro ka delay handle karta hai
                    cont.resume(true)
                }
                else -> cont.resume(false)
            }
        }
    }
}
