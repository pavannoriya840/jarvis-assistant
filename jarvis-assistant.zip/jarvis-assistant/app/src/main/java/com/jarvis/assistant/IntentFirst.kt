package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock

/**
 * INTENT-FIRST — Phase A (lean core)
 *
 * Research: "screen tap karna LAST resort hai!"
 * Rule: har command pe pehle dekho — kya kaam Android Intent se ho sakta hai?
 * Intent = millisecond me, 100% deterministic, zero vision cost.
 * Na ho paye to false → phir UI automation (SmartTarget) use karo.
 */
object IntentFirst {

    /**
     * Command ko intent se handle karne ki koshish karo.
     * @return true = intent se ho gaya, UI ki zaroorat NAHI. false = UI automation karo.
     */
    fun tryHandle(ctx: Context, command: String): Boolean {
        val cmd = command.lowercase().trim()

        // --- App kholo: "whatsapp kholo", "open youtube" ---
        val openMatch = Regex("(?:kholo|open)\\s+(.+)").find(cmd)
        if (openMatch != null) {
            val appName = openMatch.groupValues[1].trim()
            if (openApp(ctx, appName)) return true
        }

        // --- Call: "mummy ko call karo", "call 98765..." ---
        val callMatch = Regex("(?:call karo|call)\\s+(.+)").find(cmd)
        if (callMatch != null) {
            val who = callMatch.groupValues[1].trim()
            dial(ctx, who)
            return true
        }

        // --- Alarm: "alarm lagao", "7 baje ka alarm" ---
        if (cmd.contains("alarm")) {
            val time = Regex("(\\d{1,2})\\s*(?::|baje)?\\s*(\\d{0,2})").find(cmd)
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                if (time != null) {
                    putExtra(AlarmClock.EXTRA_HOUR, time.groupValues[1].toIntOrNull() ?: 7)
                    putExtra(AlarmClock.EXTRA_MINUTES, time.groupValues[2].toIntOrNull() ?: 0)
                }
            }
            return launch(ctx, intent)
        }

        // --- URL kholo: "google.com kholo" ---
        val urlMatch = Regex("([a-z0-9-]+\\.(com|in|org|net|io)[^\\s]*)").find(cmd)
        if (urlMatch != null && (cmd.contains("kholo") || cmd.contains("open") || cmd.contains("site"))) {
            var url = urlMatch.value
            if (!url.startsWith("http")) url = "https://$url"
            return launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            })
        }

        return false // intent se nahi hua → UI automation karo
    }

    /** App naam se package dhoondh ke launch karo (common map + label match) */
    fun openApp(ctx: Context, appName: String): Boolean {
        val pm = ctx.packageManager
        val known = mapOf(
            "whatsapp" to "com.whatsapp",
            "youtube" to "com.google.android.youtube",
            "chrome" to "com.android.chrome",
            "gmail" to "com.google.android.gm",
            "maps" to "com.google.android.apps.maps",
            "camera" to "com.android.camera",
            "gallery" to "com.android.gallery3d",
            "play store" to "com.android.vending",
            "settings" to "com.android.settings",
            "clock" to "com.android.deskclock",
            "calculator" to "com.android.calculator2",
            "phone" to "com.android.dialer",
            "messages" to "com.google.android.apps.messaging",
            "drive" to "com.google.android.apps.docs",
            "photos" to "com.google.android.apps.photos"
        )
        // 1) known map
        known[appName.lowercase()]?.let { pkg ->
            pm.getLaunchIntentForPackage(pkg)?.let { return launch(ctx, it) }
        }
        // 2) installed apps me label match
        val q = appName.lowercase()
        pm.getInstalledApplications(0).firstOrNull { app ->
            pm.getApplicationLabel(app).toString().lowercase().contains(q)
        }?.let { app ->
            pm.getLaunchIntentForPackage(app.packageName)?.let { return launch(ctx, it) }
        }
        return false
    }

    /** Dialer kholo (CALL_PHONE permission nahi chahiye — user khud green dabayega) */
    fun dial(ctx: Context, who: String): Boolean {
        val uri = if (who.any { it.isDigit() }) "tel:$who" else "tel:"
        return launch(ctx, Intent(Intent.ACTION_DIAL, Uri.parse(uri)).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        })
    }

    /** SMS compose kholo */
    fun sms(ctx: Context, number: String, body: String = ""): Boolean {
        return launch(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
            if (body.isNotEmpty()) putExtra("sms_body", body)
        })
    }

    private fun launch(ctx: Context, intent: Intent): Boolean {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }
}
