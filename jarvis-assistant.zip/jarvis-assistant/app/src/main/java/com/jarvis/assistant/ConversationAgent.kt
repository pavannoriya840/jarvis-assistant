package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.serialization.json.*

/**
 * CONVERSATION AGENT 💬 — WhatsApp pe ghanto chat!
 *
 * Kaise kaam karta hai:
 * 1. Target contact ka chat kholo
 * 2. Notification se naye messages padho
 * 3. Tumhare style me jawab banao (purani chats + memory se seekh ke!)
 * 4. Human jaise type karo — ruk-ruk ke, jaldi nahi (spam flag se bachao!)
 * 5. Ghanto chal sakta hai — LongTaskEngine ke andar
 *
 * SAFETY:
 * - Sirf user ke bataye contacts se baat karega
 * - Sensitive topics pe user ko ping karega
 * - Kill-switch: notification se turant roko
 */
class ConversationAgent(private val context: Context) {

    private val json = Json { ignoreUnknownKeys = true }

    data class ChatMessage(val fromMe: Boolean, val text: String, val time: Long)

    /**
     * @param contact contact ka naam (jaise "Rahul")
     * @param durationMin kitne minute tak chat karni hai
     * @param context_hint kis baare me baat karni hai (optional)
     */
    suspend fun chatWith(
        contact: String,
        durationMin: Int,
        context_hint: String = "",
        taskId: String = "",
        onEvent: (String) -> Unit = {}
    ) = withContext(Dispatchers.Default) {
        val apiKey = PromptManager(context).getApiKey()
        if (apiKey.isBlank()) {
            onEvent("API key nahi hai!")
            return@withContext
        }

        // 1. WhatsApp kholo aur contact ka chat kholo
        onEvent("💬 $contact se baat shuru kar raha hun...")
        if (!openWhatsAppChat(contact)) {
            onEvent("❌ $contact ka chat nahi khul paya")
            return@withContext
        }

        // 2. Tumhara chatting style nikalo (memory se)
        val style = getChatStyle()
        val history = mutableListOf<ChatMessage>()
        val endTime = System.currentTimeMillis() + durationMin * 60 * 1000L
        var lastMsgCount = 0

        // 3. Chat loop
        while (System.currentTimeMillis() < endTime) {
            // Task pause/stop check
            if (taskId.isNotBlank()) {
                val cp = AppDatabase.get(context).taskDao().byId(taskId)
                if (cp == null || cp.status == "failed") break
                if (cp.status == "paused") { delay(5000); continue }
            }

            // Naye messages check karo (notification se)
            val newMsgs = getNewMessagesFrom(contact)
            if (newMsgs.size > lastMsgCount) {
                val fresh = newMsgs.drop(lastMsgCount)
                lastMsgCount = newMsgs.size
                for (m in fresh) {
                    history.add(ChatMessage(false, m, System.currentTimeMillis()))
                    onEvent("📩 $contact: ${m.take(50)}")
                }

                // Sensitive check
                val lastMsg = fresh.lastOrNull() ?: ""
                if (isSensitive(lastMsg)) {
                    onEvent("⚠️ Sensitive topic — user ko bata raha hun, jawab nahi de raha")
                    notifyUser("Jarvis 💬", "$contact ne sensitive baat ki: ${lastMsg.take(100)}")
                    continue
                }

                // Jawab banao
                val reply = generateReply(history, style, context_hint, contact, apiKey)
                if (reply.isNotBlank()) {
                    // Human-like delay: padhne ka time + sochne ka time
                    val thinkDelay = (5000 + Math.random() * 15000).toLong()
                    delay(thinkDelay)

                    // Type karo (human speed)
                    if (sendMessage(reply)) {
                        history.add(ChatMessage(true, reply, System.currentTimeMillis()))
                        onEvent("📤 Tum (Jarvis): ${reply.take(50)}")
                    }
                }
            }

            // Thoda wait phir dobara check (10-20 sec)
            delay((10000 + Math.random() * 10000).toLong())
        }

        onEvent("💬 Chat session khatam! ${history.size} messages.")
    }

    /** WhatsApp me contact ka chat kholo */
    private suspend fun openWhatsAppChat(contact: String): Boolean = withContext(Dispatchers.Main) {
        try {
            // WhatsApp kholo
            val pm = context.packageManager
            val wa = pm.getLaunchIntentForPackage("com.whatsapp") ?: return@withContext false
            wa.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(wa)
            delay(2500)

            val svc = JarvisAccessibilityService.instance ?: return@withContext false
            // Search dabao
            withContext(Dispatchers.Default) {
                if (!svc.clickText("Search") && !svc.clickText("search")) {
                    // Search icon try karo
                    svc.tap(900, 150) { }
                    delay(1000)
                }
            }
            delay(1000)
            // Contact naam type karo
            withContext(Dispatchers.Default) { svc.typeText("", contact) }
            delay(2000)
            // Pehla result tap karo
            withContext(Dispatchers.Default) { svc.clickText(contact) }
            delay(2000)
            true
        } catch (e: Exception) {
            Log.e("ConvAgent", "open chat fail: ${e.message}")
            false
        }
    }

    /** Notification se is contact ke naye messages nikalo */
    private fun getNewMessagesFrom(contact: String): List<String> {
        return JarvisNotificationListener.getRecent()
            .filter { it.app.contains("WhatsApp", ignoreCase = true) }
            .filter { it.title.contains(contact, ignoreCase = true) }
            .map { it.text }
            .reversed() // purane se naye
    }

    /** Tumhara chatting style (memory se) */
    private suspend fun getChatStyle(): String = withContext(Dispatchers.IO) {
        val mems = AppDatabase.get(context).memoryDao().byCategory("preference", 5)
        if (mems.isEmpty()) return@withContext "casual, friendly Hinglish"
        mems.joinToString("; ") { it.summary }
    }

    /** Gemini se human-like jawab banao */
    private suspend fun generateReply(
        history: List<ChatMessage>,
        style: String,
        hint: String,
        contact: String,
        apiKey: String
    ): String {
        val client = GeminiClient(apiKey)
        val histText = history.takeLast(10).joinToString("\n") {
            "${if (it.fromMe) "Tum" else contact}: ${it.text}"
        }
        val resp = client.chat(
            """Tum $contact se WhatsApp pe baat kar rahe ho, user ki taraf se.
               User ka style: $style
               ${if (hint.isNotBlank()) "Baat ka context: $hint" else ""}
               Rules:
               - Bilkul human jaise likho — short messages, natural
               - 1-2 lines max, kabhi lamba paragraph mat bhejo
               - Emoji kabhi-kabhi OK hai, zyada mat lagao
               - Agar samajh na aaye to sawal pucho
               - Sirf jawab do, koi explanation nahi""",
            "", "Chat history:\n$histText\n\nTumhara jawab:"
        ).getOrNull()?.trim() ?: ""
        // Sirf pehle 2 lines lo (human jaise)
        return resp.lines().take(2).joinToString("\n").take(200)
    }

    /** Message bhejo (accessibility se type + send) */
    private suspend fun sendMessage(text: String): Boolean = withContext(Dispatchers.Main) {
        try {
            val svc = JarvisAccessibilityService.instance ?: return@withContext false
            withContext(Dispatchers.Default) {
                // Message field me type karo
                if (!svc.typeText("", text)) {
                    // Field pe tap karke phir type karo
                    svc.tap(500, 1800) { }
                    delay(800)
                    svc.typeText("", text)
                }
            }
            delay(1500)
            // Send button dabao
            withContext(Dispatchers.Default) {
                svc.clickText("Send") || svc.clickById("com.whatsapp:id/send") || run {
                    // Send button aam taur pe right-bottom me hota hai
                    var ok = false
                    svc.tap(980, 1800) { ok = it }
                    // thoda wait karke result
                    ok
                }
            }
            delay(1000)
            true
        } catch (e: Exception) {
            Log.e("ConvAgent", "send fail: ${e.message}")
            false
        }
    }

    /** Sensitive topic check */
    private fun isSensitive(text: String): Boolean {
        val t = text.lowercase()
        return t.contains(Regex("otp|password|bank|account number|upi pin|cvv"))
    }

    private fun notifyUser(title: String, text: String) {
        TaskScheduler(context).notify(title, text)
    }
}
