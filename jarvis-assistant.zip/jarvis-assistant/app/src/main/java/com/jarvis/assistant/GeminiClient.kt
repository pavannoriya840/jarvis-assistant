package com.jarvis.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * Gemini API client (REST, generateContent).
 * Keeps prompts small: system prompt + top smart memories + current request.
 * Never sends full conversation history — that's what keeps Jarvis fast.
 */
class GeminiClient(private val apiKey: String) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    private val json = Json { ignoreUnknownKeys = true }

    suspend fun chat(
        systemPrompt: String,
        memoryContext: String,
        userMessage: String,
        model: String = "gemini-2.0-flash"
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val fullPrompt = buildString {
                append(systemPrompt)
                append("\n\n[MEMORY — user ke baare me jo tum jaante ho]\n")
                append(memoryContext.ifBlank { "(koi saved memory nahi)" })
                append("\n\n[USER]: ")
                append(userMessage)
                append("\n\n[JARVIS] (Hinglish me jawab do, chhota aur clear):")
            }

            val body = buildJsonObject {
                putJsonArray("contents") {
                    addJsonObject {
                        putJsonArray("parts") {
                            addJsonObject { put("text", fullPrompt) }
                        }
                    }
                }
                putJsonObject("generationConfig") {
                    put("temperature", 0.7)
                    put("maxOutputTokens", 500)
                }
            }.toString()

            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey")
                .post(body.toRequestBody("application/json".toMediaType()))
                .build()

            http.newCall(request).execute().use { resp ->
                val text = resp.body?.string() ?: ""
                if (!resp.isSuccessful) {
                    return@withContext Result.failure(Exception("Gemini error ${resp.code}: ${text.take(200)}"))
                }
                val parsed = json.parseToJsonElement(text).jsonObject
                val reply = parsed["candidates"]?.jsonArray
                    ?.firstOrNull()?.jsonObject
                    ?.get("content")?.jsonObject
                    ?.get("parts")?.jsonArray
                    ?.firstOrNull()?.jsonObject
                    ?.get("text")?.jsonPrimitive?.content
                    ?: return@withContext Result.failure(Exception("Empty Gemini response"))
                Result.success(reply.trim())
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Ask Gemini to extract a 1-line memory summary from an exchange.
     * Returns null if nothing worth remembering.
     */
    suspend fun extractMemory(
        userMessage: String,
        jarvisReply: String,
        model: String = "gemini-2.0-flash"
    ): String? = withContext(Dispatchers.IO) {
        try {
            val prompt = """
                Neeche user aur assistant ke beech ek baat-cheet hai.
                Agar isme user ke baare me koi DURABLE fact hai (preference, routine, naam, aadat, important task),
                to use 1 line me summarize karo Hindi/Hinglish me.
                Agar kuch yaad rakhne layak NAHI hai, to sirf "NONE" likho.

                User: $userMessage
                Jarvis: $jarvisReply

                Summary ya NONE:
            """.trimIndent()

            val body = buildJsonObject {
                putJsonArray("contents") {
                    addJsonObject {
                        putJsonArray("parts") {
                            addJsonObject { put("text", prompt) }
                        }
                    }
                }
                putJsonObject("generationConfig") {
                    put("temperature", 0.2)
                    put("maxOutputTokens", 100)
                }
            }.toString()

            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey")
                .post(body.toRequestBody("application/json".toMediaType()))
                .build()

            http.newCall(request).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext null
                val text = resp.body?.string() ?: return@withContext null
                val parsed = json.parseToJsonElement(text).jsonObject
                val out = parsed["candidates"]?.jsonArray
                    ?.firstOrNull()?.jsonObject
                    ?.get("content")?.jsonObject
                    ?.get("parts")?.jsonArray
                    ?.firstOrNull()?.jsonObject
                    ?.get("text")?.jsonPrimitive?.content
                    ?.trim() ?: return@withContext null
                if (out.equals("NONE", ignoreCase = true)) null else out
            }
        } catch (e: Exception) {
            null
        }
    }
}
