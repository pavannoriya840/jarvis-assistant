package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.*

/**
 * AccessibilityService: Jarvis ki "aankhein aur haath".
 * Screen read kar sakta hai, tap/swipe/type kar sakta hai.
 *
 * User ko Settings > Accessibility me manually enable karna hoga.
 */
class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: JarvisAccessibilityService? = null
            private set

        fun isEnabled(): Boolean = instance != null
    }

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    // ============ SCREEN READING ============

    /** Poori screen ka text nikalo (Jarvis "dekhe" kya hai) */
    fun readScreen(): String {
        val root = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        collectText(root, sb, 0)
        return sb.toString().trim()
    }

    private fun collectText(node: AccessibilityNodeInfo?, sb: StringBuilder, depth: Int) {
        if (node == null || depth > 12) return
        val text = node.text?.toString()?.trim()
        val desc = node.contentDescription?.toString()?.trim()
        if (!text.isNullOrEmpty()) sb.append(text).append("\n")
        else if (!desc.isNullOrEmpty()) sb.append("[$desc]\n")
        for (i in 0 until node.childCount) {
            collectText(node.getChild(i), sb, depth + 1)
        }
    }

    /** Screen pe koi text dikh raha hai? */
    fun isTextVisible(query: String): Boolean =
        readScreen().contains(query, ignoreCase = true)

    // ============ ACTIONS ============

    /** Kisi node pe click karo jisme ye text ho */
    fun clickText(query: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findByText(root, query) ?: return false
        return clickNode(node)
    }

    /** Kisi node pe click karo jisme ye viewId ho */
    fun clickById(viewId: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByViewId(viewId)
        val node = nodes.firstOrNull() ?: return false
        return clickNode(node)
    }

    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        // Pehle khud clickable hai to direct click
        if (node.isClickable) {
            return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        // Nahi to parent chain me clickable dhoondho
        var parent = node.parent
        while (parent != null) {
            if (parent.isClickable) return parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            parent = parent.parent
        }
        // Last resort: coordinates pe tap gesture
        val rect = android.graphics.Rect()
        node.getBoundsInScreen(rect)
        if (!rect.isEmpty) {
            tap(rect.centerX(), rect.centerY())
            return true
        }
        return false
    }

    /** Kisi editable field me text type karo */
    fun typeText(query: String, text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findEditable(root, query) ?: findEditableAny(root) ?: return false
        val args = Bundle()
        args.putCharSequence(
            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text
        )
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    /** Coordinates pe tap */
    fun tap(x: Int, y: Int, callback: ((Boolean) -> Unit)? = null) {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { callback?.invoke(true) }
            override fun onCancelled(g: GestureDescription?) { callback?.invoke(false) }
        }, null)
    }

    /** Swipe gesture */
    fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Long = 400) {
        val path = Path().apply {
            moveTo(x1.toFloat(), y1.toFloat())
            lineTo(x2.toFloat(), y2.toFloat())
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        dispatchGesture(gesture, null, null)
    }

    /** Neeche scroll */
    fun scrollDown() {
        val root = rootInActiveWindow ?: return
        val scrollable = findScrollable(root)
        scrollable?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
    }

    /** Upar scroll */
    fun scrollUp() {
        val root = rootInActiveWindow ?: return
        val scrollable = findScrollable(root)
        scrollable?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    /** Back button */
    fun goBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)

    /** Home button */
    fun goHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)

    // ============ HELPERS ============

    private fun findByText(node: AccessibilityNodeInfo?, query: String): AccessibilityNodeInfo? {
        if (node == null) return null
        val text = node.text?.toString() ?: ""
        val desc = node.contentDescription?.toString() ?: ""
        if (text.contains(query, ignoreCase = true) || desc.contains(query, ignoreCase = true)) {
            return node
        }
        for (i in 0 until node.childCount) {
            val found = findByText(node.getChild(i), query)
            if (found != null) return found
        }
        return null
    }

    private fun findEditable(node: AccessibilityNodeInfo?, hint: String): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isEditable) {
            val text = node.text?.toString() ?: ""
            val desc = node.contentDescription?.toString() ?: ""
            if (hint.isBlank() || text.contains(hint, ignoreCase = true) || desc.contains(hint, ignoreCase = true)) {
                return node
            }
        }
        for (i in 0 until node.childCount) {
            val found = findEditable(node.getChild(i), hint)
            if (found != null) return found
        }
        return null
    }

    private fun findEditableAny(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? =
        findEditable(node, "")

    private fun findScrollable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val found = findScrollable(node.getChild(i))
            if (found != null) return found
        }
        return null
    }

    /** Current foreground app ka package name */
    fun currentPackage(): String {
        val root = rootInActiveWindow ?: return ""
        return root.packageName?.toString() ?: ""
    }
}
