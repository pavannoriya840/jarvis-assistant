package com.jarvis.assistant

import android.content.Context
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.util.Base64
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.serialization.json.*
import okhttp3.*
import okio.ByteString
import java.util.concurrent.TimeUnit

/**
 * GEMINI LIVE CLIENT 🎙️👁️ — v5.0 TRANSCENDENT!
 *
 * Gemini 3.8 Live se real-time baat-cheet:
 * - Bolte-bolte jawab (interrupt kar sakte ho!)
 * - Baat karte-karte screen/camera dekh sakta hai
 * - Background me tools chalata hai, baat rukti nahi!
 * - 97 languages, auto-switch (Hinglish perfect!)
 *
 * API: WebSocket BidiGenerateContent (Gemini Live API)
 *
 * NOTE: Live model ID AI Studio me check karo — default neeche hai.
 * Settings me badal sakte ho agar "model not found" aaye.
 */
class GeminiLiveClient(private val context: Context) {

    companion object {
        private const val TAG = "GeminiLive"
        const val DEFAULT_MODEL = "models/gemini-3.8-live"
        private const val WS_URL = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"

        const val INPUT_RATE = 16000   // mic: 16kHz
        const val OUTPUT_RATE = 24000  // speaker: 24kHz
    }

    interface Listener {
        fun onText(text: String)              // model ka text jawab
        fun onInterrupted()                    // user ne beech me bola
        fun onConnected()
        fun onDisconnected(reason: String)
        fun onError(msg: String)
        fun onToolCall(name: String, args: JsonObject): String  // tool chalao, result do
    }

    private val json = Json { ignoreUnknownKeys = true }
    private var webSocket: WebSocket? = null
    private var listener: Listener? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var micJob: Job? = null
    private var playingJob: Job? = null
    @Volatile private var modelSpeaking = false

    fun setListener(l: Listener) { listener = l }

    /** Connect + setup (API key DataStore se) */
    fun connect(systemPrompt: String, tools: List<JsonObject> = emptyList()) {
        scope.launch {
            val apiKey = PromptManager(context).getApiKey()
            if (apiKey.isBlank()) {
                withContext(Dispatchers.Main) { listener?.onError("API key nahi hai!") }
                return@launch
            }
            val model = PromptManager(context).getLiveModel().ifBlank { DEFAULT_MODEL }
            val voice = PromptManager(context).getLiveVoice().ifBlank { "Charon" }
            withContext(Dispatchers.Main) { connectWithKey(apiKey, model, voice, systemPrompt, tools) }
        }
    }

    private fun connectWithKey(apiKey: String, model: String, voice: String, systemPrompt: String, tools: List<JsonObject>) {
        disconnect() // purana connection band karo

        val client = OkHttpClient.Builder()
            .readTimeout(0, TimeUnit.MILLISECONDS) // infinite for WS
            .pingInterval(20, TimeUnit.SECONDS)
            .build()

        val request = Request.Builder()
            .url("$WS_URL?key=$apiKey")
            .build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                Log.d(TAG, "Live connected!")
                sendSetup(model, voice, systemPrompt, tools)
            }

            override fun onMessage(ws: WebSocket, text: String) {
                handleServerMessage(text)
            }

            override fun onMessage(ws: WebSocket, bytes: ByteString) {
                handleServerMessage(bytes.utf8())
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                Log.e(TAG, "Live WS fail: ${t.message}")
                listener?.onError(t.message ?: "Connection fail")
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                listener?.onDisconnected(reason)
            }
        })
    }

    private fun sendSetup(model: String, voice: String, systemPrompt: String, tools: List<JsonObject>) {
        val setup = buildJsonObject {
            putJsonObject("setup") {
                put("model", model)
                putJsonObject("generationConfig") {
                    putJsonObject("speechConfig") {
                        putJsonObject("voiceConfig") {
                            putJsonObject("prebuiltVoiceConfig") {
                                put("voiceName", voice)
                            }
                        }
                    }
                    put("responseModalities", buildJsonArray { add("AUDIO") })
                }
                putJsonObject("systemInstruction") {
                    putJsonArray("parts") {
                        addJsonObject { put("text", systemPrompt) }
                    }
                }
                if (tools.isNotEmpty()) {
                    putJsonArray("tools") {
                        addJsonObject {
                            putJsonArray("functionDeclarations") {
                                tools.forEach { add(it) }
                            }
                        }
                    }
                }
                // Real-time audio input
                putJsonObject("realtimeInputConfig") {
                    put("automaticActivityDetection", buildJsonObject {
                        put("disabled", false)
                    })
                }
            }
        }
        webSocket?.send(setup.toString())
    }

    /** Mic shuru karo — continuous audio streaming */
    fun startMic() {
        stopMic()
        try {
            val bufSize = AudioRecord.getMinBufferSize(
                INPUT_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                INPUT_RATE, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, bufSize * 2
            )
            audioRecord?.startRecording()

            // Speaker shuru karo
            startSpeaker()

            micJob = scope.launch {
                val buf = ByteArray(2048)
                while (isActive) {
                    val read = audioRecord?.read(buf, 0, buf.size) ?: 0
                    if (read > 0) {
                        // User bol raha hai jab model bol raha tha → interruption!
                        if (modelSpeaking && isSpeech(buf, read)) {
                            modelSpeaking = false
                            playingJob?.cancel()
                            withContext(Dispatchers.Main) { listener?.onInterrupted() }
                        }
                        sendAudioChunk(buf.copyOf(read))
                    }
                }
            }
            listener?.onConnected()
        } catch (e: Exception) {
            Log.e(TAG, "mic fail: ${e.message}")
            listener?.onError("Mic nahi khul paya: ${e.message}")
        }
    }

    private fun startSpeaker() {
        val bufSize = AudioTrack.getMinBufferSize(
            OUTPUT_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        audioTrack = AudioTrack(
            AudioManager.STREAM_MUSIC, OUTPUT_RATE,
            AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
            bufSize * 2, AudioTrack.MODE_STREAM
        )
        audioTrack?.play()
    }

    private fun sendAudioChunk(pcm: ByteArray) {
        val b64 = Base64.encodeToString(pcm, Base64.NO_WRAP)
        val msg = buildJsonObject {
            putJsonObject("realtimeInput") {
                putJsonObject("audio") {
                    put("mimeType", "audio/pcm;rate=$INPUT_RATE")
                    put("data", b64)
                }
            }
        }
        webSocket?.send(msg.toString())
    }

    /** Text message bhejo (audio ke saath-saath) */
    fun sendText(text: String) {
        val msg = buildJsonObject {
            putJsonObject("clientContent") {
                putJsonArray("turns") {
                    addJsonObject {
                        put("role", "user")
                        putJsonArray("parts") {
                            addJsonObject { put("text", text) }
                        }
                    }
                }
                put("turnComplete", true)
            }
        }
        webSocket?.send(msg.toString())
    }

    /** Screen frame bhejo (live dekhne ke liye!) 👁️ */
    fun sendScreenFrame(jpegBytes: ByteArray) {
        val b64 = Base64.encodeToString(jpegBytes, Base64.NO_WRAP)
        val msg = buildJsonObject {
            putJsonObject("realtimeInput") {
                putJsonObject("video") {
                    put("mimeType", "image/jpeg")
                    put("data", b64)
                }
            }
        }
        webSocket?.send(msg.toString())
    }

    private fun handleServerMessage(text: String) {
        try {
            val obj = json.parseToJsonElement(text).jsonObject

            // Setup complete
            if (obj.containsKey("setupComplete")) {
                Log.d(TAG, "Setup complete!")
                scope.launch(Dispatchers.Main) { listener?.onConnected() }
                return
            }

            val serverContent = obj["serverContent"]?.jsonObject ?: return

            // Interruption
            if (serverContent["interrupted"]?.jsonPrimitive?.booleanOrNull == true) {
                modelSpeaking = false
                playingJob?.cancel()
                scope.launch(Dispatchers.Main) { listener?.onInterrupted() }
                return
            }

            // Model turn (text + audio + tool calls)
            val modelTurn = serverContent["modelTurn"]?.jsonObject
            modelTurn?.get("parts")?.jsonArray?.forEach { partEl ->
                val part = partEl.jsonObject
                // Text
                part["text"]?.jsonPrimitive?.contentOrNull?.let { t ->
                    if (t.isNotBlank()) scope.launch(Dispatchers.Main) { listener?.onText(t) }
                }
                // Audio
                part["inlineData"]?.jsonObject?.let { inline ->
                    val b64 = inline["data"]?.jsonPrimitive?.contentOrNull
                    if (b64 != null) playAudioChunk(Base64.decode(b64, Base64.DEFAULT))
                }
                // Tool call!
                part["functionCall"]?.jsonObject?.let { fc ->
                    val name = fc["name"]?.jsonPrimitive?.content ?: ""
                    val args = fc["args"]?.jsonObject ?: buildJsonObject {}
                    scope.launch {
                        val result = withContext(Dispatchers.Main) {
                            listener?.onToolCall(name, args) ?: "Tool nahi mila"
                        }
                        sendToolResult(fc["id"]?.jsonPrimitive?.contentOrNull, name, result)
                    }
                }
            }

            if (serverContent["turnComplete"]?.jsonPrimitive?.booleanOrNull == true) {
                modelSpeaking = false
            }
        } catch (e: Exception) {
            Log.e(TAG, "msg parse fail: ${e.message}")
        }
    }

    private fun playAudioChunk(pcm: ByteArray) {
        modelSpeaking = true
        playingJob = scope.launch {
            try {
                audioTrack?.write(pcm, 0, pcm.size)
            } catch (e: Exception) { Log.e(TAG, "play fail: ${e.message}") }
        }
    }

    private fun sendToolResult(id: String?, name: String, result: String) {
        val msg = buildJsonObject {
            putJsonObject("clientContent") {
                putJsonArray("turns") {
                    addJsonObject {
                        put("role", "user")
                        putJsonArray("parts") {
                            addJsonObject {
                                putJsonObject("functionResponse") {
                                    if (id != null) put("id", id)
                                    put("name", name)
                                    putJsonObject("response") {
                                        put("result", result)
                                    }
                                }
                            }
                        }
                    }
                }
                put("turnComplete", true)
            }
        }
        webSocket?.send(msg.toString())
    }

    /** Kya ye speech hai ya silence? (simple energy check) */
    private fun isSpeech(buf: ByteArray, len: Int): Boolean {
        var energy = 0L
        var i = 0
        while (i < len) {
            val sample = ((buf[i + 1].toInt() shl 8) or (buf[i].toInt() and 0xFF)).toShort()
            energy += sample * sample
            i += 2
        }
        val rms = Math.sqrt((energy / (len / 2)).toDouble())
        return rms > 500 // threshold
    }

    fun stopMic() {
        micJob?.cancel()
        micJob = null
        try { audioRecord?.stop(); audioRecord?.release() } catch (_: Exception) {}
        audioRecord = null
    }

    fun disconnect() {
        stopMic()
        try { audioTrack?.stop(); audioTrack?.release() } catch (_: Exception) {}
        audioTrack = null
        playingJob?.cancel()
        scope.coroutineContext.cancelChildren()
        try { webSocket?.close(1000, "bye") } catch (_: Exception) {}
        webSocket = null
        modelSpeaking = false
    }
}
