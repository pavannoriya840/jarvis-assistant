package com.jarvis.assistant

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.util.Log
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingClient
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices
import com.jarvis.assistant.data.AppDatabase
import com.jarvis.assistant.data.AutomationRule
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*

/**
 * LOCATION TRIGGERS 📍 — "Jab ghar pahunchu to..."
 *
 * Rule Engine ka location upgrade!
 * Examples:
 * - "Ghar pahunchu to WiFi on kar dena"
 * - "Office pahunchu to phone silent kar dena"
 * - "Market jau to shopping list yaad dilana"
 *
 * Technical: Google Play Services Geofencing (battery efficient!)
 */
class LocationTriggers(private val context: Context) {

    private val json = Json { ignoreUnknownKeys = true }
    private val geofencingClient: GeofencingClient by lazy {
        LocationServices.getGeofencingClient(context)
    }

    companion object {
        const val ACTION_GEOFENCE = "com.jarvis.assistant.GEOFENCE_EVENT"
        const val EXTRA_RULE_ID = "rule_id"
        const val EXTRA_TRANSITION = "transition" // "enter" | "exit"
    }

    /**
     * Voice se location rule banao!
     * "Jab ghar pahunchu to wifi on kar dena"
     */
    suspend fun createLocationRule(command: String): String = withContext(Dispatchers.IO) {
        val apiKey = PromptManager(context).getApiKey()
        if (apiKey.isBlank()) return@withContext "API key nahi hai!"

        val client = GeminiClient(apiKey)
        val resp = client.chat(
            """User ne kaha: "$command"
               Location rule ka JSON banao. Sirf JSON:
               {
                 "name": "rule naam",
                 "place": "ghar|office|market ya custom naam",
                 "transition": "enter|exit",
                 "actionType": "notify|speak|remind",
                 "action": {"message": "...", "in_minutes": 0}
               }""",
            "", "Location rule JSON:"
        ).getOrNull() ?: return@withContext "Samajh nahi aaya"

        try {
            val clean = resp.substringAfter("{").substringBeforeLast("}")
            val obj = json.parseToJsonElement("{$clean}").jsonObject
            val place = obj["place"]?.jsonPrimitive?.content ?: return@withContext "Jagah samajh nahi aayi"

            // Abhi current location lo aur geofence banao
            val location = getCurrentLocation() ?: return@withContext "Location nahi mil payi — GPS on karo!"
            val transition = obj["transition"]?.jsonPrimitive?.content ?: "enter"

            val rule = AutomationRule(
                name = obj["name"]?.jsonPrimitive?.content ?: command.take(30),
                triggerType = "location",
                triggerJson = buildJsonObject {
                    put("place", place)
                    put("transition", transition)
                    put("lat", location.first)
                    put("lng", location.second)
                    put("radius", 200) // 200 meter
                }.toString(),
                actionType = obj["actionType"]?.jsonPrimitive?.content ?: "notify",
                actionJson = (obj["action"]?.jsonObject ?: buildJsonObject {}).toString()
            )
            val ruleId = AppDatabase.get(context).ruleDao().insert(rule)

            // Geofence register karo!
            registerGeofence(ruleId, location.first, location.second, transition)

            "📍 Location rule ban gaya! '${rule.name}' — $place ${if (transition == "enter") "pahunchne" else "nikalne"} pe active hoga!"
        } catch (e: Exception) {
            Log.e("LocTrigger", "fail: ${e.message}")
            "Rule nahi ban paya: ${e.message}"
        }
    }

    @SuppressLint("MissingPermission")
    private fun registerGeofence(ruleId: Long, lat: Double, lng: Double, transition: String) {
        try {
            val geofence = Geofence.Builder()
                .setRequestId(ruleId.toString())
                .setCircularRegion(lat, lng, 200f)
                .setExpirationDuration(Geofence.NEVER_EXPIRE)
                .setTransitionTypes(
                    if (transition == "exit") Geofence.GEOFENCE_TRANSITION_EXIT
                    else Geofence.GEOFENCE_TRANSITION_ENTER
                )
                .build()

            val request = GeofencingRequest.Builder()
                .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
                .addGeofence(geofence)
                .build()

            val intent = Intent(context, GeofenceReceiver::class.java).apply {
                action = ACTION_GEOFENCE
            }
            val pi = PendingIntent.getBroadcast(
                context, ruleId.toInt(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            geofencingClient.addGeofences(request, pi)
            Log.d("LocTrigger", "Geofence registered: $ruleId")
        } catch (e: Exception) {
            Log.e("LocTrigger", "geofence fail: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    private suspend fun getCurrentLocation(): Pair<Double, Double>? = withContext(Dispatchers.IO) {
        try {
            val fused = LocationServices.getFusedLocationProviderClient(context)
            var result: Pair<Double, Double>? = null
            val task = fused.lastLocation
            // Simple blocking wait (max 10 sec)
            var waited = 0
            while (!task.isComplete && waited < 100) {
                Thread.sleep(100)
                waited++
            }
            task.result?.let { result = it.latitude to it.longitude }
            result
        } catch (e: Exception) {
            Log.e("LocTrigger", "location fail: ${e.message}")
            null
        }
    }
}

/** Geofence events receive karo */
class GeofenceReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != LocationTriggers.ACTION_GEOFENCE) return
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            try {
                val event = com.google.android.gms.location.GeofencingEvent.fromIntent(intent) ?: return@launch
                if (event.hasError()) return@launch
                val transition = when (event.geofenceTransition) {
                    Geofence.GEOFENCE_TRANSITION_ENTER -> "enter"
                    Geofence.GEOFENCE_TRANSITION_EXIT -> "exit"
                    else -> return@launch
                }
                for (geofence in event.triggeringGeofences ?: emptyList()) {
                    val ruleId = geofence.requestId.toLongOrNull() ?: continue
                    val rule = AppDatabase.get(context).ruleDao().all()
                        .firstOrNull { it.id == ruleId } ?: continue
                    Log.d("LocTrigger", "📍 Location rule fired: ${rule.name} ($transition)")
                    // Action fire karo (RuleEngine reuse!)
                    val action = kotlinx.serialization.json.Json.parseToJsonElement(rule.actionJson).jsonObject
                    val message = action["message"]?.jsonPrimitive?.content ?: rule.name
                    when (rule.actionType) {
                        "speak" -> {
                            TaskScheduler(context).notify("Jarvis 📍", message)
                            VoiceManager.speakStatic(context, message)
                        }
                        else -> TaskScheduler(context).notify("Jarvis 📍", message)
                    }
                }
            } catch (e: Exception) {
                Log.e("LocTrigger", "receiver fail: ${e.message}")
            }
        }
    }
}
