package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import com.jarvis.assistant.data.MacroStep
import kotlinx.coroutines.*
import kotlinx.serialization.json.Json

/**
 * SELF-HEALING MACRO EXECUTOR
 *
 * Normal macro: ek step fail = poora macro fail ❌
 * Self-healing: step fail → khud alternative dhoondho ✅
 *
 * Healing strategies:
 * 1. Text tap fail → screen dobara scan karo, milta-julta text dhoondho
 * 2. Coordinate tap fail → Gemini Vision se pucho "kahan tap karun?"
 * 3. App slow load → wait badha ke retry karo (3 attempts)
 * 4. Phir bhi fail → user ko batao kahan atka
 */
class SelfHealingMacro(private val context: Context) {

    data class HealReport(
        val success: Boolean,
        val stepsDone: Int,
        val totalSteps: Int,
        val healedSteps: List<Int>,  // kin steps pe healing lagi
        val failedAt: Int = -1,
        val message: String
    )

    suspend fun execute(
        steps: List<MacroStep>,
        goal: String = "",
        apiKey: String = "",
        onProgress: (String) -> Unit = {}
    ): HealReport = withContext(Dispatchers.Main) {
        val healed = mutableListOf<Int>()

        for ((i, step) in steps.withIndex()) {
            onProgress("Step ${i + 1}/${steps.size}: ${describe(step)}")

            var ok = executeStep(step)
            var attempts = 1

            // Retry with healing (max 3 attempts)
            while (!ok && attempts < 3) {
                attempts++
                onProgress("⚠️ Step ${i + 1} fail — khud fix kar raha hun (try $attempts)...")
                delay(1500) // UI ko load hone do

                ok = healAndRetry(step, goal, apiKey)
                if (ok) healed.add(i + 1)
            }

            if (!ok) {
                return@withContext HealReport(
                    success = false,
                    stepsDone = i,
                    totalSteps = steps.size,
                    healedSteps = healed,
                    failedAt = i + 1,
                    message = "Step ${i + 1} (${describe(step)}) pe atak gaya. Screen shayad badal gayi hai."
                )
            }
            delay(700)
        }

        HealReport(
            success = true,
            stepsDone = steps.size,
            totalSteps = steps.size,
            healedSteps = healed,
            message = if (healed.isEmpty()) "Macro complete! 🎉"
                      else "Macro complete! (${healed.size} steps khud fix kiye: ${healed.joinToString()}) 🎉"
        )
    }

    private suspend fun executeStep(step: MacroStep): Boolean {
        val svc = JarvisAccessibilityService.instance ?: return false
        return suspendCancellableCoroutine(null) { cont ->
            when (step.type) {
                "tap" -> svc.tap(step.x, step.y) { cont.resume(it) }
                "tap_text" -> cont.resume(svc.clickText(step.text))
                "swipe" -> { svc.swipe(step.x, step.y, step.x2, step.y2); cont.resume(true) }
                "type" -> cont.resume(svc.typeText("", step.text))
                "scroll" -> {
                    if (step.text == "up") svc.scrollUp() else svc.scrollDown()
                    cont.resume(true)
                }
                "launch" -> {
                    val intent = context.packageManager.getLaunchIntentForPackage(step.packageName)
                    if (intent != null) {
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(intent)
                        cont.resume(true)
                    } else cont.resume(false)
                }
                "back" -> cont.resume(svc.goBack())
                "wait" -> cont.resume(true)
                else -> cont.resume(false)
            }
        }
    }

    /**
     * Healing: step fail hone pe alternative try karo
     */
    private suspend fun healAndRetry(step: MacroStep, goal: String, apiKey: String): Boolean {
        val svc = JarvisAccessibilityService.instance ?: return false

        return when (step.type) {
            "tap_text" -> {
                // Strategy 1: screen dobara padho, partial match dhoondho
                val screenText = withContext(Dispatchers.Default) { svc.readScreen() }
                val words = step.text.split(" ")
                // Koi ek word bhi mile to uspe tap karo
                for (word in words) {
                    if (word.length > 2 && screenText.contains(word, ignoreCase = true)) {
                        if (svc.clickText(word)) return true
                    }
                }
                // Strategy 2: scroll karke dobara dhoondho
                svc.scrollDown()
                delay(1000)
                svc.clickText(step.text)
            }
            "tap" -> {
                // Coordinate tap fail → text-based try karo agar text hai
                if (step.text.isNotBlank()) {
                    svc.clickText(step.text)
                } else {
                    // Aas-paas tap karo (thoda offset)
                    suspendCancellableCoroutine(null) { cont ->
                        svc.tap(step.x + 20, step.y + 20) { cont.resume(it) }
                    }
                }
            }
            "type" -> {
                // Pehle field pe tap karo phir type karo
                delay(500)
                svc.typeText("", step.text)
            }
            "launch" -> {
                // App dobara kholne ki koshish
                delay(1000)
                val intent = context.packageManager.getLaunchIntentForPackage(step.packageName)
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    true
                } else false
            }
            else -> {
                delay(1000)
                executeStep(step)
            }
        }
    }

    private fun describe(step: MacroStep): String = when (step.type) {
        "tap" -> "Tap (${step.x}, ${step.y})"
        "tap_text" -> "Tap '${step.text}'"
        "type" -> "Type '${step.text.take(20)}'"
        "swipe" -> "Swipe"
        "scroll" -> "Scroll ${step.text}"
        "launch" -> "Open ${step.packageName}"
        "back" -> "Back"
        "wait" -> "Wait"
        else -> step.type
    }

    companion object {
        /** Macro JSON se steps nikalo */
        fun parseSteps(stepsJson: String): List<MacroStep> {
            return try {
                Json.decodeFromString(stepsJson)
            } catch (e: Exception) {
                emptyList()
            }
        }
    }
}
