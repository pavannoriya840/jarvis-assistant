package com.jarvis.assistant.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Smart memory: stores SUMMARIES, not full conversations.
 * Keeps Jarvis fast — never dumps whole history into context.
 */
@Entity(tableName = "memories")
data class Memory(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String,          // "preference" | "fact" | "routine" | "task" | "learning"
    val summary: String,           // 1-2 line summary
    val importance: Int = 5,       // 1-10, higher = recalled more often
    val createdAt: Long = System.currentTimeMillis(),
    val lastUsed: Long = System.currentTimeMillis(),
    val useCount: Int = 0
)

@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val detail: String = "",
    val triggerAt: Long,           // epoch millis
    val recurring: String? = null, // "daily" | "weekly" | null
    val done: Boolean = false
)

@Entity(tableName = "macros")
data class Macro(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,              // voice trigger, e.g. "order chai"
    val stepsJson: String,         // JSON list of MacroStep
    val createdAt: Long = System.currentTimeMillis()
)

/** One recorded UI action inside a macro */
data class MacroStep(
    val type: String,              // "tap" | "swipe" | "type" | "wait" | "launch" | "back"
    val x: Int = 0,
    val y: Int = 0,
    val x2: Int = 0,
    val y2: Int = 0,
    val text: String = "",
    val packageName: String = "",
    val waitMs: Long = 0
)
