package com.jarvis.assistant

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * PER-APP PERCEPTION POLICY 📋
 *
 * Har app ka apna rule:
 * - 🎮 Game me: "screenshot lo, har 500ms me check karo"
 * - 💬 WhatsApp me: "screenshot KABHI mat lo! Sirf text use karo" (privacy!)
 * - 🏦 Banking me: "kuch mat dekho!"
 *
 * User khud bhi rules set kar sakta hai!
 */
class PerAppPolicy(private val context: Context) {

    data class Policy(
        val allowScreenshot: Boolean = true,
        val allowDump: Boolean = true,
        val useCache: Boolean = true,
        val screenshotIntervalMs: Long = 2000,
        val note: String = ""
    )

    companion object {
        private val POLICY_KEY = stringPreferencesKey("per_app_policy")
        private val json = Json { ignoreUnknownKeys = true }

        /** Default policies — privacy-first! */
        fun defaultFor(packageName: String): Policy {
            val pkg = packageName.lowercase()
            return when {
                // Messaging: NO screenshots (privacy!)
                pkg.contains("whatsapp") || pkg.contains("telegram") ->
                    Policy(allowScreenshot = false, allowDump = true, useCache = true,
                        note = "Privacy: sirf text, screenshot kabhi nahi")
                // Banking: kuch mat dekho!
                pkg.contains("bank") || pkg.contains("paytm") || pkg.contains("phonepe") ||
                pkg.contains("gpay") || pkg.contains("bhim") ->
                    Policy(allowScreenshot = false, allowDump = false, useCache = false,
                        note = "Banking: Jarvis yahan kuch nahi dekhega!")
                // Games: frequent screenshots OK
                pkg.contains("game") ->
                    Policy(allowScreenshot = true, allowDump = true, useCache = true,
                        screenshotIntervalMs = 500, note = "Game: tez perception")
                else ->
                    Policy() // default: sab allowed
            }
        }
    }

    private val store = context.getSharedPreferences("jarvis_perapp", Context.MODE_PRIVATE)

    fun getPolicy(packageName: String): Policy {
        val saved = store.getString(packageName, null)
        if (saved != null) {
            return try {
                val parts = saved.split("|")
                Policy(
                    allowScreenshot = parts[0].toBoolean(),
                    allowDump = parts[1].toBoolean(),
                    useCache = parts[2].toBoolean(),
                    screenshotIntervalMs = parts[3].toLong(),
                    note = parts.getOrNull(4) ?: ""
                )
            } catch (e: Exception) { defaultFor(packageName) }
        }
        return defaultFor(packageName)
    }

    fun setPolicy(packageName: String, policy: Policy) {
        store.edit().putString(packageName,
            "${policy.allowScreenshot}|${policy.allowDump}|${policy.useCache}|${policy.screenshotIntervalMs}|${policy.note}"
        ).apply()
    }

    /** Is app me screenshot lena allowed hai? (jaldi check) */
    fun canScreenshot(packageName: String): Boolean = getPolicy(packageName).allowScreenshot
}
