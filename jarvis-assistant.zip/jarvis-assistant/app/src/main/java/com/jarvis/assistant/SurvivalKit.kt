package com.jarvis.assistant

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings

/**
 * SURVIVAL KIT — Phase A remaining (lean!)
 *
 * Research: Xiaomi/Samsung/Honor background apps ko maar dete hain!
 * 3 lean layers (poori 11-layer army nahi — jitni zaroorat, utna hi):
 *   1. Boot revive — reboot ke baad wapas aao
 *   2. Watchdog — har 30 min self-check (self-chaining alarm)
 *   3. Battery exemption — user se ek tap me "Unrestricted" dilwao
 */
object SurvivalKit {

    /** Phone restart ho to Jarvis wapas lao */
    class BootReceiver : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
                scheduleWatchdog(ctx.applicationContext)
                if (AutonomousService.isEnabled(ctx)) {
                    AutonomousService.setEnabled(ctx, true) // service restart
                }
            }
        }
    }

    /** Har 30 min me khud ko check karo — mari hui service ko jagao */
    class WatchdogReceiver : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            scheduleWatchdog(ctx.applicationContext) // self-chaining!
            if (AutonomousService.isEnabled(ctx)) {
                AutonomousService.setEnabled(ctx, true)
            }
        }
    }

    fun scheduleWatchdog(ctx: Context) {
        try {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(
                ctx, 0, Intent(ctx, WatchdogReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val triggerAt = System.currentTimeMillis() + 30 * 60 * 1000L
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            }
        } catch (_: Exception) { }
    }

    /** Battery optimization se exemption — ek tap me settings kholo */
    fun requestBatteryExemption(ctx: Context) {
        try {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(ctx.packageName)) {
                ctx.startActivity(Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:${ctx.packageName}")
                ).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
            }
        } catch (_: Exception) { }
    }

    fun isExempted(ctx: Context): Boolean {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(ctx.packageName)
    }
}
