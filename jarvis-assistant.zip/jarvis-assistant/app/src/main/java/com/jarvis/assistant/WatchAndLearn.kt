package com.jarvis.assistant

import android.content.Context
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.*
import kotlinx.serialization.json.*

/**
 * WATCH & LEARN 👀 — "Dekh ke Seekho" Mode!
 *
 * Tum ek baar kaam KHUD karo, Jarvis dekhega, phir khud karega!
 * Trial-and-error se 10x tez seekhta hai!
 *
 * Kaise:
 * 1. "Dekh ke seekho" bolo → Jarvis recording shuru karega
 * 2. Tum apna kaam karo (jaise form bharna)
 * 3. "Bas, seekh liya?" bolo → Jarvis steps samjhega
 * 4. Agli baar: "wo wala kaam karo" → Jarvis khud karega!
 *
 * Technical: AccessibilityEvents se user ke taps/text-changes record hote hain.
 */
class WatchAndLearn(private val context: Context) {

    data class RecordedStep(
        val type: String,       // "tap" | "type" | "scroll"
        val target: String,     // kis pe (text/desc)
        val value: String = "", // type kiya text
        val time: Long
    )

    companion object {
        @Volatile var recording = false
        val recordedSteps = mutableListOf<RecordedStep>()

        /** AccessibilityService se har event yahan aayega */
        @Synchronized
        fun onEvent(event: AccessibilityEvent) {
            if (!recording) return
            try {
                when (event.eventType) {
                    AccessibilityEvent.TYPE_VIEW_CLICKED -> {
                        val node = event.source ?: return
                        val text = node.text?.toString() ?: ""
                        val desc = node.contentDescription?.toString() ?: ""
                        val target = text.ifBlank { desc }.take(50)
                        if (target.isNotBlank()) {
                            recordedSteps.add(RecordedStep("tap", target, "", System.currentTimeMillis()))
                            Log.d("WatchLearn", "📹 Recorded tap: $target")
                        }
                        node.recycle()
                    }
                    AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> {
                        val text = event.text?.joinToString("")?.take(100) ?: ""
                        if (text.isNotBlank()) {
                            // Same field me repeat mat karo
                            val last = recordedSteps.lastOrNull()
                            if (last?.type != "type" || last.target != "field") {
                                recordedSteps.add(RecordedStep("type", "field", text, System.currentTimeMillis()))
                                Log.d("WatchLearn", "📹 Recorded type: ${text.take(20)}")
                            }
                        }
                    }
                    AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                        recordedSteps.add(RecordedStep("scroll", "down", "", System.currentTimeMillis()))
                    }
                }
                // Max 50 steps (zyada lamba demo mat lo!)
                if (recordedSteps.size > 50) recordedSteps.removeAt(0)
            } catch (e: Exception) {
                Log.e("WatchLearn", "record fail: ${e.message}")
            }
        }
    }

    fun startRecording(taskName: String) {
        recordedSteps.clear()
        recording = true
        Log.d("WatchLearn", "📹 Recording shuru: $taskName")
    }

    /** Recording band karo aur skill banao */
    suspend fun stopAndLearn(taskName: String): String = withContext(Dispatchers.Default) {
        recording = false
        val steps = recordedSteps.toList()
        if (steps.size < 2) {
            return@withContext "Kuch record nahi hua — dobara try karo, thoda slow kaam karo!"
        }

        // Steps ko clean karo (duplicates hatao)
        val clean = cleanSteps(steps)

        // Skill me save karo!
        val stepsJson = buildJsonArray {
            clean.forEach { s ->
                addJsonObject {
                    put("type", s.type)
                    put("target", s.target)
                    put("value", s.value)
                }
            }
        }.toString()

        SkillLibrary(context).saveSkill(
            name = taskName,
            trigger = taskName,
            stepsJson = stepsJson
        )

        // Memory me bhi yaad rakho
        MemoryManager(context).remember(
            "fact",
            "Dekh ke seekha '$taskName': ${clean.size} steps",
            importance = 8
        )

        "Seekh liya! 🎓 '$taskName' me ${clean.size} steps record kiye. Ab bolo '$taskName karo'!"
    }

    /** Duplicate/noise steps hatao */
    private fun cleanSteps(steps: List<RecordedStep>): List<RecordedStep> {
        val result = mutableListOf<RecordedStep>()
        for (s in steps) {
            val last = result.lastOrNull()
            // Same tap dobara → skip
            if (last != null && last.type == s.type && last.target == s.target &&
                (s.time - last.time) < 1000) continue
            result.add(s)
        }
        return result
    }

    fun isRecording(): Boolean = recording
    fun recordedCount(): Int = recordedSteps.size
}
