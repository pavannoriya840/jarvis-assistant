package com.jarvis.assistant.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.jarvis.assistant.McpClient
import com.jarvis.assistant.PromptManager
import com.jarvis.assistant.SurvivalKit
import com.jarvis.assistant.TaskScheduler
import com.jarvis.assistant.databinding.ActivitySettingsBinding
import kotlinx.coroutines.launch

/**
 * Settings: Gemini API key, system prompt edit, wake word, daily briefing time.
 * Jarvis apna prompt yahan se (ya voice command se) edit kar sakta hai.
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var prompts: PromptManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prompts = PromptManager(this)

        lifecycleScope.launch {
            binding.apiKeyInput.setText(prompts.getApiKey())
            binding.promptInput.setText(prompts.getPrompt())
            binding.wakeWordInput.setText(prompts.getWakeWord())
            binding.mcpUrlInput.setText(McpClient(this@SettingsActivity).serverUrl)
        }

        binding.saveButton.setOnClickListener {
            lifecycleScope.launch {
                prompts.setApiKey(binding.apiKeyInput.text.toString().trim())
                prompts.setPrompt(binding.promptInput.text.toString())
                prompts.setWakeWord(binding.wakeWordInput.text.toString().trim())
                McpClient(this@SettingsActivity).serverUrl =
                    binding.mcpUrlInput.text.toString().trim()
                // SurvivalKit: pehli baar battery exemption dilwao
                if (!SurvivalKit.isExempted(this@SettingsActivity)) {
                    SurvivalKit.requestBatteryExemption(this@SettingsActivity)
                }
                Toast.makeText(this@SettingsActivity, "Save ho gaya!", Toast.LENGTH_SHORT).show()
                finish()
            }
        }

        binding.resetPromptButton.setOnClickListener {
            lifecycleScope.launch {
                prompts.resetPrompt()
                binding.promptInput.setText(prompts.getPrompt())
                Toast.makeText(this@SettingsActivity, "Prompt reset ho gaya", Toast.LENGTH_SHORT).show()
            }
        }

        binding.briefingButton.setOnClickListener {
            TaskScheduler(this).scheduleDailyBriefing(8, 0)
            Toast.makeText(this, "Roz subah 8 baje briefing milegi!", Toast.LENGTH_SHORT).show()
        }

        binding.mcpTestButton.setOnClickListener {
            val url = binding.mcpUrlInput.text.toString().trim()
            if (url.isEmpty()) {
                Toast.makeText(this, "Pehle MCP server URL daalo!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            Toast.makeText(this, "MCP test kar raha hun...", Toast.LENGTH_SHORT).show()
            lifecycleScope.launch {
                val mcp = McpClient(this@SettingsActivity)
                mcp.serverUrl = url
                val result = mcp.listTools()
                val msg = result.fold(
                    onSuccess = { tools ->
                        val toolNames = tools.take(3).joinToString { t -> t.name }
                        "✅ MCP connected! ${tools.size} tools mile: $toolNames"
                    },
                    onFailure = { "❌ MCP fail: ${it.message}" }
                )
                Toast.makeText(this@SettingsActivity, msg, Toast.LENGTH_LONG).show()
            }
        }
    }
}
