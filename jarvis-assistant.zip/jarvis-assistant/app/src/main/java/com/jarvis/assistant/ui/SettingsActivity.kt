package com.jarvis.assistant.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.jarvis.assistant.PromptManager
import com.jarvis.assistant.TaskScheduler
import com.jarvis.assistant.databinding.ActivitySettingsBinding
import kotlinx.coroutines.launch

/**
 * Settings: Gemini API key, system prompt edit, wake word, daily briefing time.
 * Jarvis apna prompt yahan se (ya voice command se) edit kar sakta hai.
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var prompts: PromptManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prompts = PromptManager(this)

        lifecycleScope.launch {
            binding.apiKeyInput.setText(prompts.getApiKey())
            binding.promptInput.setText(prompts.getPrompt())
            binding.wakeWordInput.setText(prompts.getWakeWord())
        }

        binding.saveButton.setOnClickListener {
            lifecycleScope.launch {
                prompts.setApiKey(binding.apiKeyInput.text.toString().trim())
                prompts.setPrompt(binding.promptInput.text.toString())
                prompts.setWakeWord(binding.wakeWordInput.text.toString().trim())
                Toast.makeText(this@SettingsActivity, "Save ho gaya!", Toast.LENGTH_SHORT).show()
                finish()
            }
        }

        binding.resetPromptButton.setOnClickListener {
            lifecycleScope.launch {
                prompts.resetPrompt()
                binding.promptInput.setText(prompts.getPrompt())
                Toast.makeText(this@SettingsActivity, "Prompt reset ho gaya", Toast.LENGTH_SHORT).show()
            }
        }

        binding.briefingButton.setOnClickListener {
            TaskScheduler(this).scheduleDailyBriefing(8, 0)
            Toast.makeText(this, "Roz subah 8 baje briefing milegi!", Toast.LENGTH_SHORT).show()
        }
    }
}
