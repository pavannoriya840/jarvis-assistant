package com.jarvis.assistant.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Pending approval: Jarvis ne kuch RISKY karna chaha, user se permission maang raha hai.
 * Notification me "Haan kar do" / "Rehne do" buttons aate hain.
 */
@Entity(tableName = "pending_approvals")
data class PendingApproval(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val detail: String,
    val actionType: String,     // "open_app" | "run_macro" | "remind" | "custom"
    val payloadJson: String,    // action execute karne ke liye data
    val createdAt: Long = System.currentTimeMillis()
)
