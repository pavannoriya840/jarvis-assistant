package com.jarvis.assistant

/**
 * COMMAND SPLITTER — Phase C Smart Brain (lean!)
 *
 * "Mummy ko call karo AUR 5 baje reminder lagao"
 *   → ["Mummy ko call karo", "5 baje reminder lagao"]
 *
 * Rule: sirf tab split karo jab 2+ parts hon AUR kam se kam ek me action verb ho.
 * (Warna "aur" wale normal sentences toot jayenge!)
 */
object CommandSplitter {

    private val SPLIT_REGEX =
        Regex("\\s+(?:aur|or|phir|then|,)\\s+", RegexOption.IGNORE_CASE)

    private val VERBS = listOf(
        "karo", "lagao", "kholo", "bhejo", "batao", "call", "reminder",
        "message", "chalao", "band", "dekho", "nikalo", "set", "open",
        "bajao", "likho", "dhoondho", "search"
    )

    /** Multi-task command hai to parts do, nahi to null */
    fun split(cmd: String): List<String>? {
        val parts = cmd.split(SPLIT_REGEX)
            .map { it.trim() }
            .filter { it.length > 3 }
        if (parts.size < 2) return null
        val hasAction = parts.any { p -> VERBS.any { p.contains(it, ignoreCase = true) } }
        return if (hasAction) parts else null
    }
}
