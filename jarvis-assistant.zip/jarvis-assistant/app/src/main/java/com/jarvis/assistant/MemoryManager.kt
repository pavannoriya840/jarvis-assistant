package com.jarvis.assistant

import android.content.Context
import com.jarvis.assistant.data.AppDatabase
import com.jarvis.assistant.data.Memory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Smart memory: sirf summaries store hoti hain, poori conversation nahi.
 * Context me sirf top relevant memories jaati hain — isliye Jarvis slow nahi hota.
 */
class MemoryManager(context: Context) {

    private val dao = AppDatabase.get(context).memoryDao()
    private val scope = CoroutineScope(Dispatchers.IO)

    /** Recall: Gemini ko dene ke liye compact memory block banao */
    suspend fun recallBlock(maxItems: Int = 15): String {
        val mems = dao.topMemories(maxItems)
        if (mems.isEmpty()) return ""
        mems.forEach { dao.markUsed(it.id) }
        return mems.joinToString("\n") { "- [${it.category}] ${it.summary}" }
    }

    /** Keyword search (jab user kuch specific puche) */
    suspend fun search(keyword: String): List<Memory> {
        val res = dao.search(keyword)
        res.forEach { dao.markUsed(it.id) }
        return res
    }

    /** Nayi memory save karo (Gemini se extracted summary) */
    fun remember(category: String, summary: String, importance: Int = 5) {
        scope.launch {
            dao.insert(Memory(category = category, summary = summary, importance = importance))
        }
    }

    /** Purani bekaar memories saaf karo (month me ek baar call karo) */
    fun prune() {
        scope.launch {
            val monthAgo = System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000
            dao.pruneWeak(monthAgo)
        }
    }

    /** User ne kuch sikhaya — learning ke roop me save karo */
    fun learn(summary: String) = remember("learning", summary, importance = 7)

    /** Daily routine ka pattern save karo */
    fun saveRoutine(summary: String) = remember("routine", summary, importance = 8)
}
