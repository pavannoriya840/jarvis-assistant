package com.jarvis.assistant

/**
 * HINGLISH HONESTY GUARD — Phase C Smart Brain (lean!)
 *
 * Research finding: Hinglish me AI models 2.5x zyada FAKE "ho gaya!" bolte hain!
 * Rule: Hinglish command pe action ke baad EVIDENCE verify karo —
 * bina proof ke "ho gaya" kabhi mat bolo!
 */
object HinglishGuard {

    /** Kya ye command Hinglish me hai? */
    fun isHinglish(cmd: String): Boolean {
        // Devanagari script = pakka Hinglish/Hindi
        if (cmd.any { it in '\u0900'..'\u097F' }) return true
        // Roman Hinglish markers (kam se kam 2)
        val markers = listOf(
            "karo", "hai", "nahi", "kya", "mujhe", "mera", "tum",
            "batao", "lagao", "kholo", "mein", "raha", "rahi", "wala", "wali"
        )
        val lower = " $cmd ".lowercase()
        return markers.count { lower.contains(" $it ") || lower.contains(" $it,") } >= 2
    }

    /**
     * Action ke baad evidence check karo.
     * @param check evidence ka lambda — jaise { svc.isTextVisible("Reminder set") }
     */
    fun verify(check: () -> Boolean, timeoutMs: Long = 4000): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            try {
                if (check()) return true
            } catch (_: Exception) { }
            Thread.sleep(300)
        }
        return false
    }
}
