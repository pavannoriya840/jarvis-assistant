package com.jarvis.assistant

import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

/**
 * PRIVILEGE MANAGER — Shizuku auto-detect + fallback chain 🛡️
 *
 * Har privileged kaam is layer se guzarta hai:
 *   1. SHIZUKU (agar ON hai) → ADB-level powers, sabse tez
 *   2. ACCESSIBILITY (agar ON hai) → UI automation
 *   3. BASIC → sirf batayega "ye manually karo", ya notification bhejega
 *
 * User ko kabhi pata nahi chalega kaunsa method use hua — bas kaam hoga!
 *
 * Shizuku se milne wali powers (bina root!):
 * - Silent permission grants (pm grant)
 * - System settings read/write
 * - Shell commands (dumpsys, cmd, etc.)
 * - App ops control
 */
class PrivilegeManager(private val context: Context) {

    enum class Level { SHIZUKU, ACCESSIBILITY, BASIC }

    companion object {
        private const val TAG = "PrivilegeMgr"
    }

    /** Current sabse powerful available level */
    fun currentLevel(): Level {
        return when {
            isShizukuReady() -> Level.SHIZUKU
            JarvisAccessibilityService.isEnabled() -> Level.ACCESSIBILITY
            else -> Level.BASIC
        }
    }

    /** Kya Shizuku chal raha hai aur permission mili hai? */
    fun isShizukuReady(): Boolean {
        return try {
            Shizuku.pingBinder() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) {
            false
        }
    }

    /** Kya Shizuku app installed hai (chahe abhi OFF ho)? */
    fun isShizukuInstalled(): Boolean {
        return try {
            context.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0)
            true
        } catch (e: Exception) {
            try {
                // Naya package name bhi check karo
                context.packageManager.getPackageInfo("rikka.shizuku", 0)
                true
            } catch (_: Exception) { false }
        }
    }

    /** Shizuku permission mango (pehli baar) */
    fun requestShizukuPermission(code: Int, activity: android.app.Activity) {
        try {
            if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                Shizuku.requestPermission(code)
            }
        } catch (e: Exception) {
            Log.e(TAG, "shizuku perm request fail: ${e.message}")
        }
    }

    /**
     * Shell command chalao (sirf SHIZUKU level pe).
     * Returns output ya null (agar Shizuku nahi hai).
     */
    suspend fun shell(cmd: String): String? = withContext(Dispatchers.IO) {
        if (!isShizukuReady()) return@withContext null
        try {
            val process = newShizukuProcess(arrayOf("sh", "-c", cmd)) ?: return@withContext null
            val out = process.inputStream.bufferedReader().readText()
            val err = process.errorStream.bufferedReader().readText()
            process.waitFor()
            if (err.isNotBlank()) Log.d(TAG, "shell stderr: ${err.take(200)}")
            out.ifBlank { null }
        } catch (e: Exception) {
            Log.e(TAG, "shell fail: ${e.message}")
            null
        }
    }

    /** Shizuku 13 me newProcess private hai — reflection se access karo */
    private fun newShizukuProcess(cmd: Array<String>): Process? {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            m.invoke(null, cmd, null, null) as? Process
        } catch (e: Exception) {
            Log.e(TAG, "shizuku newProcess reflection fail: ${e.message}")
            null
        }
    }

    /** Kisi permission ko silently grant karo (Shizuku) */
    suspend fun grantPermission(pkg: String, permission: String): Boolean {
        val out = shell("pm grant $pkg $permission")
        // pm grant kuch output nahi deta success pe — dobara check karo
        return shell("dumpsys package $pkg | grep -A1 $permission")?.contains("granted=true") == true || out != null
    }

    /** System setting padho (Shizuku) */
    suspend fun getSystemSetting(key: String): String? =
        shell("settings get system $key")?.trim()

    /** Current foreground app (Shizuku — accessibility se bhi tez!) */
    suspend fun foregroundApp(): String? {
        // Shizuku se dumpsys
        val out = shell("dumpsys activity activities | grep -E 'mFocusedApp' | head -1")
        if (out != null) {
            val m = Regex("([a-zA-Z0-9._]+)/").find(out)
            if (m != null) return m.groupValues[1]
        }
        // Fallback: accessibility
        return JarvisAccessibilityService.instance?.currentPackage()?.ifBlank { null }
    }

    /** Battery level (Shizuku fast path) */
    suspend fun batteryLevel(): Int? {
        val out = shell("dumpsys battery | grep level") ?: return null
        return Regex("level: (\\d+)").find(out)?.groupValues?.get(1)?.toIntOrNull()
    }

    /** Level ka human-readable naam */
    fun levelName(): String = when (currentLevel()) {
        Level.SHIZUKU -> "⚡ Shizuku (max power!)"
        Level.ACCESSIBILITY -> "♿ Accessibility"
        Level.BASIC -> "📱 Basic"
    }
}
