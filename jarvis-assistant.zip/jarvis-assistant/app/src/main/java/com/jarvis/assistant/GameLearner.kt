package com.jarvis.assistant

import android.content.Context
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.serialization.json.*

/**
 * GAME LEARNER 🎮 — khud seekh ke khelega!
 *
 * DUAL BRAIN:
 *   ⚡ REFLEX (on-device, free, fast) — color/shape dekh ke turant react
 *   🧠 STRATEGY (Gemini, slow) — naye situations me sochega
 *
 * LEARNING LOOP:
 *   1. EXPLORE → naye game me befikr try karo, observe karo
 *   2. HYPOTHESIZE → "ye button shayad jump karta hai"
 *   3. TEST → try karo, score dekho
 *   4. REMEMBER → kaam kiya to skill banao, fail hua to mistake diary me!
 *
 * Seekhne ke baad: Reflex ko sikha do → phir FREE + FAST khelega!
 */
class GameLearner(private val context: Context) {

    private val json = Json { ignoreUnknownKeys = true }
    private val gestureMemory = GestureMemory(context)
    private val reflex = ReflexEngine()

    data class GameState(
        val score: Int,
        val screenDesc: String,
        val isGameOver: Boolean,
        val isNewHighScore: Boolean
    )

    /**
     * Naya game seekho!
     * @param packageName game ka package
     * @param learnMinutes kitne minute seekhna hai
     */
    suspend fun learn(
        packageName: String,
        learnMinutes: Int = 10,
        onProgress: (String) -> Unit = {}
    ) = withContext(Dispatchers.Default) {
        val apiKey = PromptManager(context).getApiKey()
        onProgress("🎮 $packageName seekh raha hun! Pehle observe karunga...")

        // Game kholo
        openGame(packageName)
        delay(3000)

        val endTime = System.currentTimeMillis() + learnMinutes * 60 * 1000L
        var lastScore = 0
        val mistakeDiary = mutableListOf<String>()
        val winningMoves = mutableListOf<String>()

        // Phase 1: EXPLORE (pehle 30%) — befikr try karo
        onProgress("🔍 Phase 1: Explore — naye moves try kar raha hun...")
        val exploreEnd = System.currentTimeMillis() + (learnMinutes * 60 * 1000L * 0.3).toLong()

        while (System.currentTimeMillis() < exploreEnd) {
            val state = observeGame(apiKey)
            if (state.isGameOver) {
                mistakeDiary.add("Game over hua — pichhle moves risky the")
                restartGame()
                delay(2000)
                continue
            }

            // Random exploratory action
            val action = exploreAction()
            val scoreBefore = state.score
            doAction(action)
            delay(1500)

            val newState = observeGame(apiKey)
            val scoreDelta = newState.score - scoreBefore

            if (scoreDelta > 0) {
                winningMoves.add("$action → score +$scoreDelta ✅")
                onProgress("✅ Seekha: $action se score badha!")
            } else if (newState.isGameOver) {
                mistakeDiary.add("❌ $action ke baad game over! Ye mat karna.")
                onProgress("❌ Galti se seekha: $action dangerous hai")
            }
        }

        // Phase 2: STRATEGIZE — Gemini se strategy banao
        onProgress("🧠 Phase 2: Strategy bana raha hun...")
        val strategy = buildStrategy(packageName, winningMoves, mistakeDiary, apiKey)

        // Phase 3: PRACTICE — strategy ke saath khelo
        onProgress("🎯 Phase 3: Strategy ke saath practice...")
        while (System.currentTimeMillis() < endTime) {
            val state = observeGame(apiKey)
            if (state.isGameOver) {
                restartGame()
                delay(2000)
                continue
            }
            // Strategy follow karo, kabhi-kabhi reflex!
            val action = if (Math.random() < 0.7) {
                strategyAction(strategy, state)
            } else {
                reflex.react(state.screenDesc) // fast reflex!
            }
            doAction(action)
            delay(1200)
        }

        // Seekha hua sab save karo!
        saveLearnings(packageName, strategy, winningMoves, mistakeDiary)
        onProgress("🎓 Seekh complete! ${winningMoves.size} winning moves, ${mistakeDiary.size} mistakes se seekha!")
    }

    /**
     * Seekha hua game khelo (fast mode — reflex zyada, Gemini kam!)
     */
    suspend fun play(
        packageName: String,
        playMinutes: Int,
        taskId: String = "",
        onProgress: (String) -> Unit = {}
    ) = withContext(Dispatchers.Default) {
        val apiKey = PromptManager(context).getApiKey()
        val learnings = getLearnings(packageName)

        openGame(packageName)
        delay(3000)

        val endTime = System.currentTimeMillis() + playMinutes * 60 * 1000L
        var moves = 0

        while (System.currentTimeMillis() < endTime) {
            if (taskId.isNotBlank()) {
                val cp = AppDatabase.get(context).taskDao().byId(taskId)
                if (cp == null || cp.status == "failed") break
                if (cp.status == "paused") { delay(5000); continue }
            }

            val state = observeGame(apiKey)
            if (state.isGameOver) {
                onProgress("💀 Game over! Score: ${state.score} — restart kar raha hun")
                restartGame()
                delay(2000)
                continue
            }

            // 80% reflex (fast+free), 20% strategy (smart)
            val action = if (Math.random() < 0.8 && learnings != null) {
                reflex.reactWithMemory(state.screenDesc, learnings)
            } else {
                strategyAction(learnings?.strategy ?: "score badhao", state)
            }
            doAction(action)
            moves++

            if (moves % 10 == 0) onProgress("🎮 $moves moves, score: ${state.score}")

            // Reflex speed: sirf 800ms wait!
            delay(800)
        }
        onProgress("🎮 Game session khatam! Total moves: $moves")
    }

    // ============ Helpers ============

    private suspend fun openGame(packageName: String) = withContext(Dispatchers.Main) {
        try {
            val pm = context.packageManager
            val intent = pm.getLaunchIntentForPackage(packageName) ?: return@withContext
            intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (e: Exception) { Log.e("GameLearn", "open fail: ${e.message}") }
    }

    private suspend fun observeGame(apiKey: String): GameState {
        val svc = JarvisAccessibilityService.instance
        val text = withContext(Dispatchers.Main) { svc?.readScreen() ?: "" }

        // Score nikalo (numbers dhoondho)
        val score = Regex("(score|points)[^\\d]*(\\d+)", RegexOption.IGNORE_CASE)
            .find(text)?.groupValues?.get(2)?.toIntOrNull()
            ?: Regex("\\b\\d{2,6}\\b").find(text)?.value?.toIntOrNull() ?: 0

        val isGameOver = text.contains(Regex("game over|try again|restart", RegexOption.IGNORE_CASE))

        return GameState(score, text.take(500), isGameOver, false)
    }

    private fun exploreAction(): String {
        // Random: tap ya swipe
        return if (Math.random() < 0.5) {
            val x = (200 + Math.random() * 600).toInt()
            val y = (400 + Math.random() * 1200).toInt()
            "tap:$x,$y"
        } else {
            val dirs = listOf("up", "down", "left", "right")
            "swipe:${dirs.random()}"
        }
    }

    private suspend fun doAction(action: String) = withContext(Dispatchers.Main) {
        val svc = JarvisAccessibilityService.instance ?: return@withContext
        try {
            withContext(Dispatchers.Default) {
                when {
                    action.startsWith("tap:") -> {
                        val (x, y) = action.removePrefix("tap:").split(",").map { it.toInt() }
                        var done = false
                        svc.tap(x, y) { done = it }
                        delay(500)
                    }
                    action.startsWith("swipe:") -> {
                        val dir = action.removePrefix("swipe:")
                        // GestureMemory se calibrated swipe lo!
                        val (dx, dy, dur) = gestureMemory.getSwipe("current_game", dir)
                        val cx = 540; val cy = 1100
                        svc.swipe(cx, cy, cx + dx, cy + dy, dur)
                    }
                }
            }
        } catch (e: Exception) { Log.e("GameLearn", "action fail: ${e.message}") }
    }

    private suspend fun buildStrategy(
        pkg: String, wins: List<String>, mistakes: List<String>, apiKey: String
    ): String {
        if (apiKey.isBlank()) return "score badhao, game over se bacho"
        val client = GeminiClient(apiKey)
        return client.chat(
            """Game khelna seekh raha hun. Mere observations:
               Winning moves: ${wins.take(10).joinToString("; ")}
               Mistakes: ${mistakes.take(10).joinToString("; ")}
               Is game ke liye 3-4 line ki STRATEGY batao — kya karna chahiye, kya nahi.
               Short aur actionable likho.""",
            "", "Strategy banao:"
        ).getOrNull()?.trim()?.take(500) ?: "score badhao, game over se bacho"
    }

    private fun strategyAction(strategy: String, state: GameState): String {
        // Simple: strategy me "swipe" word hai to swipe, nahi to tap center
        return if (strategy.contains("swipe", ignoreCase = true)) {
            "swipe:${listOf("up", "down", "left", "right").random()}"
        } else {
            "tap:540,1100"
        }
    }

    private suspend fun restartGame() = withContext(Dispatchers.Main) {
        val svc = JarvisAccessibilityService.instance ?: return@withContext
        withContext(Dispatchers.Default) {
            svc.clickText("restart") || svc.clickText("try again") || svc.clickText("play again")
                    || svc.clickText("Replay")
        }
    }

    private suspend fun saveLearnings(
        pkg: String, strategy: String, wins: List<String>, mistakes: List<String>
    ) = withContext(Dispatchers.IO) {
        // Skill me save karo
        SkillLibrary(context).saveSkill(
            name = "Play $pkg",
            trigger = "$pkg game khelna",
            stepsJson = """{"strategy": "$strategy", "winning_moves": ${wins.size}}"""
        )
        // Mistake diary memory me
        val mm = MemoryManager(context)
        mistakes.take(5).forEach { mm.remember("learning", "Game $pkg: $it", 6) }
        mm.remember("fact", "Game $pkg strategy: ${strategy.take(150)}", 7)
    }

    private suspend fun getLearnings(pkg: String): GameLearning? = withContext(Dispatchers.IO) {
        val skill = SkillLibrary(context).findSkill("Play $pkg") ?: return@withContext null
        GameLearning(skill.stepsJson)
    }

    data class GameLearning(val strategy: String)
}

/**
 * REFLEX ENGINE ⚡ — sochta nahi, REACT karta hai!
 * On-device, zero API cost, millisecond response.
 */
class ReflexEngine {
    /**
     * Screen description se turant action decide karo (bina AI ke!)
     */
    fun react(screenDesc: String): String {
        val lower = screenDesc.lowercase()
        return when {
            // Danger words dikhe to bachne wala action
            lower.contains("danger") || lower.contains("warning") -> "swipe:up"
            // Score badhane ka mauka
            lower.contains("bonus") || lower.contains("reward") -> "tap:540,1100"
            // Default: center tap
            else -> "tap:540,1100"
        }
    }

    fun reactWithMemory(screenDesc: String, learning: GameLearner.GameLearning): String {
        // Learned strategy ke keywords se quick decision
        val strat = learning.strategy.lowercase()
        return when {
            strat.contains("left") && Math.random() < 0.4 -> "swipe:left"
            strat.contains("right") && Math.random() < 0.4 -> "swipe:right"
            strat.contains("up") && Math.random() < 0.4 -> "swipe:up"
            strat.contains("jump") -> "swipe:up"
            else -> react(screenDesc)
        }
    }
}

/**
 * GESTURE MEMORY 📏 — "kab kitna swipe karna hai" yaad rakhta hai!
 * Har game ke liye calibrated: direction → (dx, dy, duration)
 */
class GestureMemory(private val context: Context) {
    private val prefs get() =
        context.getSharedPreferences("jarvis_gestures", Context.MODE_PRIVATE)

    /** Calibrated swipe lo (default: medium swipe) */
    fun getSwipe(gamePkg: String, direction: String): Triple<Int, Int, Long> {
        val key = "${gamePkg}_$direction"
        val saved = prefs.getString(key, null)
        if (saved != null) {
            val (dx, dy, dur) = saved.split(",").map { it.toLong() }
            return Triple(dx.toInt(), dy.toInt(), dur)
        }
        // Default calibration
        return when (direction) {
            "up" -> Triple(0, -400, 200)
            "down" -> Triple(0, 400, 200)
            "left" -> Triple(-300, 0, 200)
            "right" -> Triple(300, 0, 200)
            else -> Triple(0, -300, 200)
        }
    }

    /** Nayi calibration save karo (seekhne ke baad) */
    fun calibrate(gamePkg: String, direction: String, dx: Int, dy: Int, durationMs: Long) {
        prefs.edit().putString("${gamePkg}_$direction", "$dx,$dy,$durationMs").apply()
    }
}
