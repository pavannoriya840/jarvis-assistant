package com.jarvis.assistant

import android.telecom.Call
import android.telecom.CallScreeningService
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * CALL SCREENER 📞 — anjaan calls Jarvis handle karega!
 *
 * - Unknown/spam number aaye → silently decline + tumko notify
 * - Contacts se aaye → normal ring hone do
 * - Tum Settings me "Call screening app" me Jarvis select karo
 *
 * Future: full interactive screening ("kaun bol raha hai?" puchna)
 * ke liye CallScreeningService ka respond API use hoga.
 */
class JarvisCallScreener : CallScreeningService() {

    override fun onScreenCall(callDetails: Call.Details) {
        try {
            val number = callDetails.handle?.schemeSpecificPart ?: "Unknown"
            val isSpam = isSpamNumber(number)

            Log.d("CallScreen", "Incoming: $number (spam=$isSpam)")

            val response = CallResponse.Builder()
                .setDisallowCall(isSpam)           // spam hai to kaat do!
                .setRejectCall(false)
                .setSkipCallLog(false)
                .setSkipNotification(isSpam)       // spam ki notification bhi mat dikhao
                .build()

            respondToCall(callDetails, response)

            if (isSpam) {
                // User ko batao
                TaskScheduler(this).notify(
                    "Jarvis 📞",
                    "Spam call block ki: $number"
                )
                val mm = MemoryManager(this)
                CoroutineScope(Dispatchers.IO).launch {
                    mm.remember("fact", "Spam call blocked: $number", importance = 4)
                }
            }
        } catch (e: Exception) {
            Log.e("CallScreen", "screen fail: ${e.message}")
        }
    }

    /** Spam detection (basic — bad me smart hoga!) */
    private fun isSpamNumber(number: String): Boolean {
        // Bahut chhota/lamba number, ya known spam patterns
        val digits = number.filter { it.isDigit() }
        if (digits.length < 7) return true // invalid
        // 140-series (telemarketing India me)
        if (digits.startsWith("140")) return true
        return false
    }
}
