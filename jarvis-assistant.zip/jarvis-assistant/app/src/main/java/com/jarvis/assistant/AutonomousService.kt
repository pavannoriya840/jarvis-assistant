package com.jarvis.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.jarvis.assistant.ui.MainActivity
import kotlinx.coroutines.*

/**
 * AUTONOMOUS SERVICE — Jarvis background me khud kaam karta hai.
 *
 * Har 45 minute me ek "think cycle":
 *   context jama karo → Gemini se pucho → safe kaam khud karo → risky ke liye pucho
 *
 * User kabhi bhi MainActivity ke toggle se ON/OFF kar sakta hai.
 */
class AutonomousService : Service() {

    companion object {
        const val CHANNEL_ID = "jarvis_autonomous_svc"
        const val NOTIF_ID = 201
        const val ACTION_THINK_NOW = "com.jarvis.assistant.THINK_NOW"
        const val PREFS = "jarvis_autonomy"
        const val KEY_ENABLED = "enabled"
        // Think har kitne minute me (default 45)
        const val THINK_INTERVAL_MIN = 45L

        fun isEnabled(ctx: Context): Boolean =
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)

        fun setEnabled(ctx: Context, enabled: Boolean) {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, enabled).apply()
            val intent = Intent(ctx, AutonomousService::class.java)
            if (enabled) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ctx.startForegroundService(intent)
                else ctx.startService(intent)
            } else {
                ctx.stopService(intent)
            }
        }
    }

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var thinkJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIF_ID, buildNotification("Jarvis autonomous mode ON 🧠"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_THINK_NOW) {
            scope.launch { runThinkCycle() }
        } else {
            startLoop()
        }
        return START_STICKY
    }

    private fun startLoop() {
        thinkJob?.cancel()
        thinkJob = scope.launch {
            // Pehla cycle 2 min baad (service settle hone do), phir har 45 min
            delay(2 * 60 * 1000L)
            while (isActive && isEnabled(this@AutonomousService)) {
                runThinkCycle()
                delay(THINK_INTERVAL_MIN * 60 * 1000L)
            }
        }
    }

    private suspend fun runThinkCycle() {
        try {
            Log.d("JarvisAuto", "Think cycle shuru...")
            val summary = AutonomyEngine(this).think()
            Log.d("JarvisAuto", "Think cycle result:\n$summary")
            updateNotification("Aakhri check: ${summary.lines().firstOrNull()?.take(60) ?: "kuch nahi"}")
        } catch (e: Exception) {
            Log.e("JarvisAuto", "Think cycle fail: ${e.message}")
        }
    }

    /** Bahar se turant think karwao (notification aane pe) */
    fun thinkNow() {
        scope.launch { runThinkCycle() }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Jarvis Autonomous Service", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Jarvis Autonomous 🧠")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification(text))
    }

    override fun onDestroy() {
        thinkJob?.cancel()
        scope.cancel()
        super.onDestroy()
    }
}
