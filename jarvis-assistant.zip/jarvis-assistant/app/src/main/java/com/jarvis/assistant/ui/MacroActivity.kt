package com.jarvis.assistant.ui

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.jarvis.assistant.MacroManager
import com.jarvis.assistant.databinding.ActivityMacroBinding
import kotlinx.coroutines.launch

/**
 * Macro list: saare saved macros dikhao, chalao, delete karo.
 * Naya macro = MainActivity se voice command: "macro record karo [naam]"
 */
class MacroActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMacroBinding
    private lateinit var macros: MacroManager
    private val names = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMacroBinding.inflate(layoutInflater)
        setContentView(binding.root)
        macros = MacroManager(this)

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, names)
        binding.macroList.adapter = adapter

        binding.macroList.setOnItemClickListener { _, _, pos, _ ->
            val name = names[pos]
            Toast.makeText(this, "Chala raha hun: $name", Toast.LENGTH_SHORT).show()
            macros.runMacro(
                name,
                onStep = { step -> runOnUiThread { binding.statusText.text = step } },
                onDone = { ok, msg ->
                    runOnUiThread {
                        binding.statusText.text = msg
                        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }

        binding.macroList.setOnItemLongClickListener { _, _, pos, _ ->
            val name = names[pos]
            AlertDialog.Builder(this)
                .setTitle("Delete macro?")
                .setMessage("'$name' hamesha ke liye delete ho jayega")
                .setPositiveButton("Delete") { _, _ ->
                    lifecycleScope.launch {
                        macros.listMacros().firstOrNull { it.name == name }?.let {
                            macros.deleteMacro(it)
                            loadMacros()
                        }
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
            true
        }

        binding.helpText.text = """
            Macro kaise banaye:
            1. Main screen pe bolo: "macro record karo zomato order"
            2. Phone pe wo steps karo jo repeat karne hain
            3. Bolo: "macro save karo"
            4. Phir kabhi bhi bolo: "macro chalao zomato order"

            Macro yahan list me dikhega — tap karke chalao, long-press karke delete karo.
        """.trimIndent()

        loadMacros()
    }

    private fun loadMacros() {
        lifecycleScope.launch {
            names.clear()
            names.addAll(macros.listMacros().map { it.name })
            (binding.macroList.adapter as ArrayAdapter<*>).notifyDataSetChanged()
            binding.statusText.text = if (names.isEmpty()) "Koi macro nahi — pehle record karo!" else "${names.size} macros"
        }
    }
}
