package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import kotlinx.coroutines.*
import kotlinx.serialization.json.*
import java.util.Calendar

/**
 * JARVIS BRAIN v2.0 — SUPER SMART EDITION 🧠
 *
 * 1. FUNCTION CALLING: Gemini khud tools call karta hai (agentic loop)
 * 2. SMART MEMORY: sirf relevant summaries context me
 * 3. ROUTINE LEARNING: har command se seekhta hai
 * 4. SELF-HEALING: macro fail ho to khud fix karta hai
 * 5. VISION READY: screenshot dekh ke decide kar sakta hai
 */
class JarvisBrain(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val promptManager = PromptManager(context)
    private val memoryManager = MemoryManager(context)
    private val macroManager = MacroManager(context)
    private val scheduler = TaskScheduler(context)
    private val selfHealing = SelfHealingMacro(context)
    private val routineLearner = RoutineLearner(context)

    var onSpeak: (String) -> Unit = {}
    var onStatus: (String) -> Unit = {}
    var onAction: (String) -> Unit = {}

    companion object {
        const val SMART_SYSTEM_PROMPT = """
            Tum JARVIS ho — user ke phone ka super-intelligent AI assistant, Iron Man ke Jarvis jaisa.
            Tum Hinglish me baat karte ho, short aur decisive.

            Tumhare paas TOOLS hain. Jab user kuch karne ko kahe, to seedha TOOL CALL karo — sirf text mat likho.
            - Reminder chahiye → schedule_reminder call karo
            - App kholni hai → open_app call karo
            - Screen pe kuch tap karna hai → tap_text call karo
            - Kuch type karna hai → type_text call karo
            - Macro chalana hai → run_macro call karo
            - Important baat yaad rakhni hai → remember call karo
            - Screen dekhni hai → read_screen call karo

            Rules:
            - Pehle tool use karo, phir user ko short me batao kya kiya
            - Agar multiple steps hain, saare tools ek ke baad ek call karo
            - Kabhi jhooth mat bolo — tool fail ho to batao
            - Jawab 2-3 lines me, Hinglish me
            - User ki privacy: sensitive data kabhi bahar mat bhejo
        """.trimIndent()
    }

    /** Main entry: user ne kuch kaha */
    fun handleCommand(input: String) {
        val cmd = input.trim()
        if (cmd.isEmpty()) return
        onStatus("Soch raha hun... 🧠")

        // Routine learner ko feed karo (background me seekhta rahega)
        routineLearner.observe(cmd)

        scope.launch {
            // Quick local commands (bina API ke)
            if (handleLocal(cmd)) return@launch

            // Agentic loop with function calling
            runAgentic(cmd)
        }
    }

    private suspend fun runAgentic(cmd: String) {
        val apiKey = promptManager.getApiKey()
        if (apiKey.isBlank()) {
            speak("Pehle Settings me apni Gemini API key daalo! aistudio.google.com se free me milti hai.")
            return
        }

        // Custom prompt hai ya default smart prompt?
        val customPrompt = promptManager.getPrompt()
        val systemPrompt = if (customPrompt == PromptManager.DEFAULT_PROMPT) SMART_SYSTEM_PROMPT else customPrompt

        val memories = withContext(Dispatchers.IO) { memoryManager.recallBlock() }

        // Current screen context (agar accessibility ON hai)
        val screenContext = withContext(Dispatchers.Default) {
            val svc = JarvisAccessibilityService.instance
            if (svc != null) {
                val pkg = svc.currentPackage()
                val text = svc.readScreen().take(800)
                "App: $pkg\nScreen text:\n$text"
            } else ""
        }

        val client = SmartGeminiClient(apiKey)
        onStatus("Jarvis kaam kar raha hai... ⚡")

        val result = client.agenticChat(
            systemPrompt = systemPrompt,
            memoryContext = memories,
            screenContext = screenContext,
            userMessage = cmd,
            executor = { name, args -> executeFunction(name, args) }
        )

        result.fold(
            onSuccess = { agentResult ->
                if (agentResult.functionsCalled.isNotEmpty()) {
                    onStatus("✅ ${agentResult.functionsCalled.size} actions kiye")
                }
                speak(agentResult.finalReply)
                // Seekho is exchange se
                learnFrom(cmd, agentResult.finalReply, apiKey)
            },
            onFailure = { e ->
                speak("Problem ho gayi: ${e.message?.take(120)}")
            }
        )
    }

    /**
     * Gemini ke function calls ko execute karo
     */
    private suspend fun executeFunction(name: String, args: JsonObject): GeminiFunctions.FunctionResult {
        return withContext(Dispatchers.Main) {
            try {
                when (name) {
                    "schedule_reminder" -> {
                        val title = args["title"]?.jsonPrimitive?.content ?: "Reminder"
                        val inMinutes = args["in_minutes"]?.jsonPrimitive?.intOrNull
                        val atTime = args["at_time"]?.jsonPrimitive?.content
                        val triggerAt = when {
                            inMinutes != null -> System.currentTimeMillis() + inMinutes * 60_000L
                            atTime != null -> parseTimeToday(atTime)
                            else -> System.currentTimeMillis() + 60_000L
                        }
                        scheduler.ensureChannel()
                        var doneId = -1L
                        scheduler.schedule(title, "", triggerAt) { doneId = it }
                        // Wait for insert
                        delay(500)
                        GeminiFunctions.FunctionResult(name, true, "Reminder lag gaya: '$title'")
                    }
                    "open_app" -> {
                        val appName = args["app_name"]?.jsonPrimitive?.content ?: ""
                        val ok = openApp(appName)
                        GeminiFunctions.FunctionResult(name, ok,
                            if (ok) "$appName khol diya" else "$appName nahi mila")
                    }
                    "tap_text" -> {
                        val text = args["text"]?.jsonPrimitive?.content ?: ""
                        val svc = JarvisAccessibilityService.instance
                            ?: return@withContext GeminiFunctions.FunctionResult(name, false, "Accessibility OFF hai")
                        val ok = withContext(Dispatchers.Default) { svc.clickText(text) }
                        GeminiFunctions.FunctionResult(name, ok,
                            if (ok) "'$text' pe tap kiya" else "'$text' screen pe nahi mila")
                    }
                    "type_text" -> {
                        val text = args["text"]?.jsonPrimitive?.content ?: ""
                        val svc = JarvisAccessibilityService.instance
                            ?: return@withContext GeminiFunctions.FunctionResult(name, false, "Accessibility OFF hai")
                        val ok = withContext(Dispatchers.Default) { svc.typeText("", text) }
                        GeminiFunctions.FunctionResult(name, ok,
                            if (ok) "Type kiya: $text" else "Type nahi ho paya")
                    }
                    "scroll" -> {
                        val dir = args["direction"]?.jsonPrimitive?.content ?: "down"
                        val svc = JarvisAccessibilityService.instance
                        if (dir == "up") svc?.scrollUp() else svc?.scrollDown()
                        GeminiFunctions.FunctionResult(name, true, "Scroll $dir kiya")
                    }
                    "go_back" -> {
                        JarvisAccessibilityService.instance?.goBack()
                        GeminiFunctions.FunctionResult(name, true, "Back gaya")
                    }
                    "run_macro" -> {
                        val macroName = args["macro_name"]?.jsonPrimitive?.content ?: ""
                        val result = runMacroSmart(macroName)
                        GeminiFunctions.FunctionResult(name, result.success, result.message)
                    }
                    "remember" -> {
                        val fact = args["fact"]?.jsonPrimitive?.content ?: ""
                        val cat = args["category"]?.jsonPrimitive?.content ?: "fact"
                        withContext(Dispatchers.IO) {
                            memoryManager.remember(cat, fact, importance = 7)
                        }
                        GeminiFunctions.FunctionResult(name, true, "Yaad rakh liya: $fact")
                    }
                    "read_screen" -> {
                        val svc = JarvisAccessibilityService.instance
                            ?: return@withContext GeminiFunctions.FunctionResult(name, false, "Accessibility OFF hai")
                        val text = withContext(Dispatchers.Default) { svc.readScreen().take(1000) }
                        GeminiFunctions.FunctionResult(name, true, "Screen:\n$text")
                    }
                    else -> GeminiFunctions.FunctionResult(name, false, "Unknown function: $name")
                }
            } catch (e: Exception) {
                GeminiFunctions.FunctionResult(name, false, "Error: ${e.message}")
            }
        }
    }

    /** Macro ko self-healing ke saath chalao */
    private suspend fun runMacroSmart(name: String): SelfHealingMacro.HealReport {
        val apiKey = promptManager.getApiKey()
        var report: SelfHealingMacro.HealReport? = null
        withContext(Dispatchers.IO) {
            val dao = com.jarvis.assistant.data.AppDatabase.get(context).macroDao()
            val macro = dao.byName(name.lowercase().trim())
            if (macro == null) {
                report = SelfHealingMacro.HealReport(false, 0, 0, emptyList(), -1, "Macro '$name' nahi mila")
                return@withContext
            }
            val steps = SelfHealingMacro.parseSteps(macro.stepsJson)
            report = selfHealing.execute(
                steps,
                goal = "Macro: $name",
                apiKey = apiKey,
                onProgress = { onStatus(it) }
            )
        }
        return report!!
    }

    /** "17:00" → aaj ke us time ka millis */
    private fun parseTimeToday(hhmm: String): Long {
        return try {
            val parts = hhmm.split(":")
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, parts[0].toInt())
            cal.set(Calendar.MINUTE, parts[1].toInt())
            cal.set(Calendar.SECOND, 0)
            var millis = cal.timeInMillis
            if (millis < System.currentTimeMillis()) millis += 24 * 60 * 60 * 1000
            millis
        } catch (e: Exception) {
            System.currentTimeMillis() + 60_000L
        }
    }

    // ============ Quick Local Commands (no API) ============

    private suspend fun handleLocal(cmd: String): Boolean {
        val lower = cmd.lowercase()

        if (lower.startsWith("macro record karo")) {
            val name = lower.removePrefix("macro record karo").trim()
            if (name.isNotEmpty()) {
                macroManager.startRecording(name)
                speak("🔴 Recording shuru: '$name'. Steps karo, phir bolo 'macro save karo'")
                onAction("recording:$name")
            } else speak("Naam bhi bolo! Jaise: macro record karo zomato order")
            return true
        }
        if (lower == "macro save karo" || lower == "recording band karo") {
            macroManager.stopAndSave { ok ->
                speak(if (ok) "Macro save ho gaya! 🎉" else "Kuch record nahi hua")
                onAction("recording:stop")
            }
            return true
        }
        if (lower.startsWith("yaad rakho ")) {
            val fact = cmd.substring(10).trim()
            withContext(Dispatchers.IO) { memoryManager.remember("fact", fact, 8) }
            speak("Yaad rakh liya! 🧠")
            return true
        }
        if (lower == "wapas" || lower == "back") {
            JarvisAccessibilityService.instance?.goBack()
            return true
        }
        if (lower == "home") {
            JarvisAccessibilityService.instance?.goHome()
            return true
        }
        if (lower.contains("apna prompt") || lower.contains("prompt edit")) {
            speak("Settings khol raha hun!")
            onAction("open_settings")
            return true
        }
        return false
    }

    private fun openApp(appName: String): Boolean {
        val pm = context.packageManager
        val clean = appName.lowercase().replace(" ", "")
        val apps = pm.getInstalledApplications(0)
        val match = apps.firstOrNull {
            val label = try { pm.getApplicationLabel(it).toString().lowercase() } catch (_: Exception) { "" }
            label.contains(appName.lowercase()) || it.packageName.lowercase().contains(clean)
        } ?: return false
        val intent = pm.getLaunchIntentForPackage(match.packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }

    private fun learnFrom(userMsg: String, reply: String, apiKey: String) {
        scope.launch(Dispatchers.IO) {
            val client = SmartGeminiClient(apiKey)
            // Purane simple client ka extractMemory use karo
            val simple = GeminiClient(apiKey)
            val summary = simple.extractMemory(userMsg, reply)
            if (!summary.isNullOrBlank()) {
                val cat = when {
                    summary.contains("pasand", true) || summary.contains("prefer", true) -> "preference"
                    summary.contains("roz", true) || summary.contains("daily", true) -> "routine"
                    else -> "fact"
                }
                memoryManager.remember(cat, summary, 6)
            }
        }
    }

    private fun speak(text: String) {
        onStatus("Bol raha hun... 🗣️")
        onSpeak(text)
    }

    fun destroy() {
        scope.cancel()
    }
}
