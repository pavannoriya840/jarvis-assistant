package com.jarvis.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Long task ke Pause/Resume/Stop buttons */
class TaskControlReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getStringExtra(LongTaskEngine.EXTRA_TASK_ID) ?: return
        CoroutineScope(Dispatchers.IO).launch {
            val engine = LongTaskEngine(context)
            when (intent.action) {
                LongTaskEngine.ACTION_PAUSE -> {
                    engine.pauseTask(taskId)
                    Log.d("JarvisTask", "Task $taskId paused")
                }
                LongTaskEngine.ACTION_RESUME -> {
                    engine.resumeTask(taskId)
                    Log.d("JarvisTask", "Task $taskId resumed")
                }
                LongTaskEngine.ACTION_STOP -> {
                    engine.stopTask(taskId)
                    Log.d("JarvisTask", "Task $taskId stopped")
                }
            }
        }
    }
}
