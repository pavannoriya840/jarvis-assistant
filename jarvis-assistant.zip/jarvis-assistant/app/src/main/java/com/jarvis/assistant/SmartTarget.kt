package com.jarvis.assistant

/**
 * HYBRID TARGETING — Phase A (lean core)
 *
 * User directive: "Text/ID se click achhi baat hai, lekin coordinate ka
 * option BHI rakho — jab jiski zaroorat ho tab use karo."
 *
 * Rule: semantic (text/id/desc) PEHLE, coordinates FALLBACK ya explicit.
 * Koi nayi dependency nahi — size same!
 */

/** Tap ka target — semantic ya coordinates */
sealed class Target {
    data class Text(val query: String) : Target()       // screen text se dhoondho
    data class Id(val viewId: String) : Target()         // view-id se dhoondho
    data class Desc(val desc: String) : Target()         // content-desc se dhoondho
    data class XY(val x: Int, val y: Int) : Target()     // explicit coordinates (jab zaroorat ho!)
}

object SmartTarget {

    /**
     * Target pe tap karo.
     * @param fallbackXY semantic fail ho jaye to in coordinates pe tap karo (null = no fallback)
     */
    fun tap(
        service: JarvisAccessibilityService,
        target: Target,
        fallbackXY: Pair<Int, Int>? = null
    ): Boolean {
        val ok = when (target) {
            is Target.Text -> service.clickText(target.query)
            is Target.Id -> service.clickById(target.viewId)
            is Target.Desc -> service.clickText(target.desc) // findByText text+desc dono check karta hai
            is Target.XY -> {
                service.tap(target.x, target.y)
                true
            }
        }
        if (!ok && fallbackXY != null) {
            service.tap(fallbackXY.first, fallbackXY.second)
            return true
        }
        return ok
    }

    /**
     * Smart chain: text → id → desc → coordinates.
     * Jo mile pehle, usi pe tap. Sab fail → false.
     */
    fun tapChain(
        service: JarvisAccessibilityService,
        text: String? = null,
        viewId: String? = null,
        desc: String? = null,
        xy: Pair<Int, Int>? = null
    ): Boolean {
        text?.let { if (service.clickText(it)) return true }
        viewId?.let { if (service.clickById(it)) return true }
        desc?.let { if (service.clickText(it)) return true }
        xy?.let { service.tap(it.first, it.second); return true }
        return false
    }

    /** Type karne ke liye field dhoondho — hint se ya pehla editable */
    fun type(
        service: JarvisAccessibilityService,
        hint: String,
        text: String
    ): Boolean = service.typeText(hint, text)
}
