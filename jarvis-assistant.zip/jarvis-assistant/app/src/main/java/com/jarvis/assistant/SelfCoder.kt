package com.jarvis.assistant

import android.content.Context
import android.util.Log
import com.jarvis.assistant.data.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*

/**
 * SELF-CODER 💻 — Jarvis khud naye skills "program" karta hai!
 *
 * (Agent-level self-coding: naye skill definitions, strategies,
 *  aur prompt improvements generate karta hai. JVM bytecode nahi —
 *  wo Android pe runtime me possible nahi, ye honest approach hai!)
 *
 * Kaise kaam karta hai:
 * 1. Koi task baar-baar fail ho raha hai ya naya pattern dikha
 * 2. SelfCoder analyze karta hai: "purana tareeka kyun fail hua?"
 * 3. Gemini se NAYA skill program karwata hai (structured steps)
 * 4. Test karta hai → kaam kiya to save, nahi to dobara try
 * 5. Apne system prompt me improvement bhi likh sakta hai!
 */
class SelfCoder(private val context: Context) {

    private val json = Json { ignoreUnknownKeys = true }

    data class CodedSkill(
        val name: String,
        val trigger: String,
        val steps: List<SkillStep>,
        val verification: String  // kaise pata chalega kaam hua?
    )

    data class SkillStep(
        val action: String,   // "tap" | "type" | "scroll" | "open_app" | "wait" | "verify"
        val target: String,
        val value: String = ""
    )

    /**
     * Naya skill program karo!
     * @param taskDescription kya karna hai (jaise "Zomato se biryani order karna")
     * @param pastFailures pehle kya galat hua (optional)
     */
    suspend fun codeNewSkill(
        taskDescription: String,
        pastFailures: String = "",
        onProgress: (String) -> Unit = {}
    ): CodedSkill? = withContext(Dispatchers.Default) {
        val apiKey = PromptManager(context).getApiKey()
        if (apiKey.isBlank()) return@withContext null

        onProgress("💻 SelfCoder program likh raha hai...")

        val client = GeminiClient(apiKey)
        val resp = client.chat(
            """Tum Jarvis ke SelfCoder ho. Ek naye skill ka PROGRAM likho.
               Task: $taskDescription
               ${if (pastFailures.isNotBlank()) "Pichhli failures: $pastFailures\nInse seekh ke behtar program likho!" else ""}

               Sirf JSON me jawab do:
               {
                 "name": "skill ka naam",
                 "trigger": "kab use karni hai",
                 "steps": [
                   {"action": "open_app|tap|type|scroll|wait|verify", "target": "kya", "value": "text ya empty"},
                   ...
                 ],
                 "verification": "kaise pata chalega task complete hua?"
               }
               Max 12 steps. Har step precise likho (jaise target me exact button text).""",
            "", "Skill program karo:"
        ).getOrNull() ?: return@withContext null

        try {
            val clean = resp.substringAfter("{").substringBeforeLast("}")
            val obj = json.parseToJsonElement("{$clean}").jsonObject

            val steps = obj["steps"]?.jsonArray?.map { el ->
                val s = el.jsonObject
                SkillStep(
                    s["action"]?.jsonPrimitive?.content ?: "tap",
                    s["target"]?.jsonPrimitive?.content ?: "",
                    s["value"]?.jsonPrimitive?.content ?: ""
                )
            } ?: return@withContext null

            val skill = CodedSkill(
                obj["name"]?.jsonPrimitive?.content ?: taskDescription.take(30),
                obj["trigger"]?.jsonPrimitive?.content ?: taskDescription,
                steps,
                obj["verification"]?.jsonPrimitive?.content ?: ""
            )

            // Save karo!
            val stepsJson = buildJsonArray {
                steps.forEach { s ->
                    addJsonObject {
                        put("action", s.action)
                        put("target", s.target)
                        put("value", s.value)
                    }
                }
            }.toString()

            SkillLibrary(context).saveSkill(skill.name, skill.trigger, stepsJson)
            onProgress("💻 Skill programmed: ${skill.name} (${steps.size} steps)!")

            // Memory me yaad rakho
            MemoryManager(context).remember(
                "fact", "Self-coded skill: ${skill.name}", importance = 7
            )

            skill
        } catch (e: Exception) {
            Log.e("SelfCoder", "parse fail: ${e.message}")
            null
        }
    }

    /**
     * Apne system prompt ko improve karo (past mistakes se seekh ke!)
     */
    suspend fun improveOwnPrompt(): String = withContext(Dispatchers.Default) {
        val apiKey = PromptManager(context).getApiKey()
        if (apiKey.isBlank()) return@withContext "API key nahi hai"

        val pm = PromptManager(context)
        val current = pm.getPrompt()

        // Recent learnings nikalo
        val learnings = AppDatabase.get(context).memoryDao()
            .byCategory("learning", 10)
            .joinToString("\n") { "- ${it.summary}" }

        if (learnings.isBlank()) return@withContext "Abhi koi nayi seekh nahi — prompt already best hai!"

        val client = GeminiClient(apiKey)
        val improved = client.chat(
            """Tum Jarvis ka SelfCoder ho. Iska system prompt improve karo.
               Current prompt: $current
               Recent learnings (galtiyon se): $learnings

               Naya prompt do jo ye learnings include kare. Sirf improved prompt do,
               koi explanation nahi. 15 lines max.""",
            "", "Prompt improve karo:"
        ).getOrNull()?.trim()

        if (!improved.isNullOrBlank() && improved.length > 50) {
            pm.setPrompt(improved.take(2000))
            MemoryManager(context).remember("fact", "SelfCoder ne apna prompt improve kiya!", 8)
            "Apna prompt khud improve kar liya! 🧠✨"
        } else {
            "Prompt already optimal hai!"
        }
    }
}
