package com.jarvis.assistant

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * MCP CLIENT — v6.0 Phase 1 (lean, ZERO nayi dependency!)
 *
 * Model Context Protocol: 1000+ ready-made tools (DB, GitHub, web, files...)!
 * Minimal JSON-RPC over Streamable HTTP.
 *
 * Setup: Settings me MCP server URL daalo (jaise http://laptop:3000/mcp).
 * Bina server ke ye disabled rehta hai — kuch tootega nahi!
 */
class McpClient(private val context: Context) {

    data class Tool(val name: String, val description: String)

    private val json = Json { ignoreUnknownKeys = true }
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val prefs get() =
        context.getSharedPreferences("mcp", Context.MODE_PRIVATE)

    var serverUrl: String
        get() = prefs.getString("server_url", "") ?: ""
        set(v) = prefs.edit().putString("server_url", v.trim()).apply()

    val isConfigured: Boolean get() = serverUrl.isNotBlank()

    private var idCounter = 1

    /** Ek JSON-RPC call */
    private suspend fun rpc(
        method: String,
        params: JsonObject = buildJsonObject {}
    ): Result<JsonObject> = withContext(Dispatchers.IO) {
        try {
            val body = buildJsonObject {
                put("jsonrpc", "2.0")
                put("id", idCounter++)
                put("method", method)
                put("params", params)
            }.toString()
            val req = Request.Builder()
                .url(serverUrl.trimEnd('/'))
                .post(body.toRequestBody("application/json".toMediaType()))
                .header("Accept", "application/json, text/event-stream")
                .build()
            http.newCall(req).execute().use { resp ->
                val text = resp.body?.string() ?: ""
                if (!resp.isSuccessful)
                    return@withContext Result.failure(Exception("MCP HTTP ${resp.code}"))
                // SSE stream ho to data: line nikalo, nahi to plain JSON
                val clean = text.lineSequence()
                    .firstOrNull { it.startsWith("data:") }
                    ?.removePrefix("data:")?.trim() ?: text
                val obj = json.parseToJsonElement(clean).jsonObject
                obj["error"]?.jsonObject?.let {
                    return@withContext Result.failure(
                        Exception("MCP: ${it["message"]?.jsonPrimitive?.content}")
                    )
                }
                Result.success(obj["result"]?.jsonObject ?: buildJsonObject {})
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private suspend fun initialize(): Boolean {
        val r = rpc("initialize", buildJsonObject {
            put("protocolVersion", "2025-06-18")
            putJsonObject("capabilities") {}
            putJsonObject("clientInfo") {
                put("name", "jarvis-android")
                put("version", "6.0")
            }
        })
        if (r.isSuccess) rpc("notifications/initialized")
        return r.isSuccess
    }

    /** Server pe kaun-kaun se tools hain? */
    suspend fun listTools(): Result<List<Tool>> {
        if (!isConfigured)
            return Result.failure(Exception("MCP server set nahi hai — Settings me URL daalo"))
        if (!initialize())
            return Result.failure(Exception("MCP handshake fail — server chal raha hai?"))
        return rpc("tools/list").map { result ->
            result["tools"]?.jsonArray?.map { t ->
                val o = t.jsonObject
                Tool(
                    o["name"]?.jsonPrimitive?.content ?: "",
                    o["description"]?.jsonPrimitive?.content ?: ""
                )
            } ?: emptyList()
        }
    }

    /** MCP tool call karo */
    suspend fun callTool(name: String, args: Map<String, String>): Result<String> {
        if (!isConfigured)
            return Result.failure(Exception("MCP server set nahi hai"))
        if (!initialize())
            return Result.failure(Exception("MCP handshake fail"))
        return rpc("tools/call", buildJsonObject {
            put("name", name)
            putJsonObject("arguments") {
                args.forEach { (k, v) -> put(k, v) }
            }
        }).map { it.toString().take(2000) }
    }
}
