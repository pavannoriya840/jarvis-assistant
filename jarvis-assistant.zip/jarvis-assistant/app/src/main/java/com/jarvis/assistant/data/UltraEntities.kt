package com.jarvis.assistant.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Long task ka checkpoint — crash/restart ke baad wahin se resume! */
@Entity(tableName = "task_checkpoints")
data class TaskCheckpoint(
    @PrimaryKey val taskId: String,
    val goal: String,
    val taskType: String,       // "generic" | "chat" | "instagram" | "game"
    val status: String,         // "running" | "paused" | "done" | "failed"
    val currentStep: Int = 0,
    val totalSteps: Int = 0,
    val stateJson: String = "{}",  // task-specific state (resume ke liye)
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

/** Skill Library: seekhi hui skill jo dobara use hogi */
@Entity(tableName = "skills")
data class Skill(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val trigger: String,        // kab use karni hai (description)
    val stepsJson: String,      // kaise karni hai
    val successRate: Float = 1.0f,
    val useCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

/** Automation Rule: "jab X ho to Y karo" — voice se banayi hui */
@Entity(tableName = "automation_rules")
data class AutomationRule(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,           // "Mummy ka message aaye to batana"
    val triggerType: String,    // "notification" | "time" | "app_open"
    val triggerJson: String,    // {"app": "WhatsApp", "from": "Mummy", "contains": "..."}
    val actionType: String,     // "notify" | "speak" | "run_macro" | "remind"
    val actionJson: String,
    val enabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
