package com.jarvis.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.util.Log
import java.util.Locale

/**
 * JARVIS VOICE 🗣️ — uski apni pehchan!
 *
 * 2 modes:
 * 1. SYSTEM TTS PROFILE (free, abhi): pitch/rate tune karke "Jarvis wali"
 *    heavy voice. Sabse acchi Hindi voice auto-select.
 * 2. VOICE CLONING HOOK (future/paid): ElevenLabs jaisi service ka
 *    API key daalo → asli cloned voice!
 *
 * NOTE: Sacchi voice cloning ke liye paid service chahiye
 * (ElevenLabs/PlayHT ~$5/month). Uske bina ye best-effort tuning hai.
 */
class JarvisVoice(private val context: Context) {

    companion object {
        // Jarvis voice profile
        const val PITCH = 0.75f   // thodi heavy
        const val RATE = 0.95f    // thoda slow, confident
    }

    private var tts: TextToSpeech? = null

    /** Best Hindi voice dhoondho */
    fun init(onReady: () -> Unit = {}) {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                try {
                    val voices = tts?.voices ?: emptySet()
                    // Hindi voice prefer karo
                    val hindiVoice = voices.firstOrNull { v ->
                        v.locale.language == "hi" && !v.isNetworkConnectionRequired
                    } ?: voices.firstOrNull { v ->
                        v.locale.language == "hi"
                    } ?: voices.firstOrNull { v ->
                        v.name.contains("male", ignoreCase = true)
                    }
                    if (hindiVoice != null) {
                        tts?.voice = hindiVoice
                        Log.d("JarvisVoice", "Voice: ${hindiVoice.name}")
                    }
                    tts?.language = Locale("hi", "IN")
                    tts?.setPitch(PITCH)
                    tts?.setSpeechRate(RATE)
                } catch (e: Exception) {
                    Log.e("JarvisVoice", "voice setup: ${e.message}")
                }
                onReady()
            }
        }
    }

    fun speak(text: String) {
        tts?.setPitch(PITCH)
        tts?.setSpeechRate(RATE)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    fun shutdown() {
        tts?.shutdown()
        tts = null
    }

    /**
     * VOICE CLONING (future): agar user ElevenLabs API key de to
     * yahan se cloned voice chalegi. Abhi placeholder — key nahi to system voice.
     */
    suspend fun hasClonedVoice(): Boolean {
        return PromptManager(context).getVoiceCloneKey().isNotBlank()
    }
}
