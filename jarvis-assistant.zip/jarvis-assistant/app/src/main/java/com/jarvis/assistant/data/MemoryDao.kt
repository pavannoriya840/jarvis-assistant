package com.jarvis.assistant.data

import androidx.room.*

@Dao
interface MemoryDao {
    @Insert
    suspend fun insert(memory: Memory): Long

    @Query("SELECT * FROM memories ORDER BY (importance * 2 + useCount) DESC, lastUsed DESC LIMIT :limit")
    suspend fun topMemories(limit: Int = 20): List<Memory>

    @Query("SELECT * FROM memories WHERE category = :category ORDER BY importance DESC LIMIT :limit")
    suspend fun byCategory(category: String, limit: Int = 10): List<Memory>

    @Query("SELECT * FROM memories WHERE summary LIKE '%' || :keyword || '%' ORDER BY importance DESC LIMIT :limit")
    suspend fun search(keyword: String, limit: Int = 10): List<Memory>

    @Query("UPDATE memories SET lastUsed = :now, useCount = useCount + 1 WHERE id = :id")
    suspend fun markUsed(id: Long, now: Long = System.currentTimeMillis())

    @Delete
    suspend fun delete(memory: Memory)

    @Query("DELETE FROM memories WHERE importance < 3 AND useCount = 0 AND createdAt < :olderThan")
    suspend fun pruneWeak(olderThan: Long)
}

@Dao
interface ReminderDao {
    @Insert
    suspend fun insert(reminder: Reminder): Long

    @Query("SELECT * FROM reminders WHERE done = 0 AND triggerAt <= :now ORDER BY triggerAt ASC")
    suspend fun due(now: Long = System.currentTimeMillis()): List<Reminder>

    @Query("SELECT * FROM reminders WHERE done = 0 ORDER BY triggerAt ASC")
    suspend fun upcoming(): List<Reminder>

    @Query("UPDATE reminders SET done = 1 WHERE id = :id")
    suspend fun markDone(id: Long)

    @Delete
    suspend fun delete(reminder: Reminder)
}

@Dao
interface MacroDao {
    @Insert
    suspend fun insert(macro: Macro): Long

    @Query("SELECT * FROM macros ORDER BY name ASC")
    suspend fun all(): List<Macro>

    @Query("SELECT * FROM macros WHERE name = :name LIMIT 1")
    suspend fun byName(name: String): Macro?

    @Delete
    suspend fun delete(macro: Macro)
}

@Dao
interface ApprovalDao {
    @Insert
    suspend fun insert(approval: PendingApproval): Long

    @Query("SELECT * FROM pending_approvals WHERE id = :id LIMIT 1")
    suspend fun byId(id: Long): PendingApproval?

    @Query("DELETE FROM pending_approvals WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM pending_approvals WHERE createdAt < :olderThan")
    suspend fun prune(olderThan: Long)
}

@Dao
interface TaskDao {
    @Insert
    suspend fun insert(task: TaskCheckpoint)

    @Query("SELECT * FROM task_checkpoints WHERE taskId = :taskId LIMIT 1")
    suspend fun byId(taskId: String): TaskCheckpoint?

    @Query("UPDATE task_checkpoints SET status = :status, currentStep = :step, stateJson = :state, updatedAt = :now WHERE taskId = :taskId")
    suspend fun update(taskId: String, status: String, step: Int, state: String, now: Long = System.currentTimeMillis())

    @Query("SELECT * FROM task_checkpoints WHERE status = 'paused' OR status = 'running' ORDER BY updatedAt DESC")
    suspend fun resumable(): List<TaskCheckpoint>

    @Query("DELETE FROM task_checkpoints WHERE taskId = :taskId")
    suspend fun delete(taskId: String)
}

@Dao
interface SkillDao {
    @Insert
    suspend fun insert(skill: Skill): Long

    @Query("SELECT * FROM skills ORDER BY useCount DESC, successRate DESC")
    suspend fun all(): List<Skill>

    @Query("SELECT * FROM skills WHERE name LIKE '%' || :keyword || '%' OR trigger LIKE '%' || :keyword || '%' ORDER BY successRate DESC LIMIT 5")
    suspend fun search(keyword: String): List<Skill>

    @Query("UPDATE skills SET useCount = useCount + 1, successRate = ((successRate * useCount) + :success) / (useCount + 1) WHERE id = :id")
    suspend fun recordResult(id: Long, success: Float)

    @Query("DELETE FROM skills WHERE successRate < 0.3 AND useCount > 5")
    suspend fun pruneBad()

    @Delete
    suspend fun delete(skill: Skill)
}

@Dao
interface RuleDao {
    @Insert
    suspend fun insert(rule: AutomationRule): Long

    @Query("SELECT * FROM automation_rules WHERE enabled = 1")
    suspend fun enabled(): List<AutomationRule>

    @Query("SELECT * FROM automation_rules ORDER BY createdAt DESC")
    suspend fun all(): List<AutomationRule>

    @Query("UPDATE automation_rules SET enabled = :enabled WHERE id = :id")
    suspend fun setEnabled(id: Long, enabled: Boolean)

    @Delete
    suspend fun delete(rule: AutomationRule)
}
