package com.jarvis.assistant.data

import androidx.room.*

@Dao
interface MemoryDao {
    @Insert
    suspend fun insert(memory: Memory): Long

    @Query("SELECT * FROM memories ORDER BY (importance * 2 + useCount) DESC, lastUsed DESC LIMIT :limit")
    suspend fun topMemories(limit: Int = 20): List<Memory>

    @Query("SELECT * FROM memories WHERE category = :category ORDER BY importance DESC LIMIT :limit")
    suspend fun byCategory(category: String, limit: Int = 10): List<Memory>

    @Query("SELECT * FROM memories WHERE summary LIKE '%' || :keyword || '%' ORDER BY importance DESC LIMIT :limit")
    suspend fun search(keyword: String, limit: Int = 10): List<Memory>

    @Query("UPDATE memories SET lastUsed = :now, useCount = useCount + 1 WHERE id = :id")
    suspend fun markUsed(id: Long, now: Long = System.currentTimeMillis())

    @Delete
    suspend fun delete(memory: Memory)

    @Query("DELETE FROM memories WHERE importance < 3 AND useCount = 0 AND createdAt < :olderThan")
    suspend fun pruneWeak(olderThan: Long)
}

@Dao
interface ReminderDao {
    @Insert
    suspend fun insert(reminder: Reminder): Long

    @Query("SELECT * FROM reminders WHERE done = 0 AND triggerAt <= :now ORDER BY triggerAt ASC")
    suspend fun due(now: Long = System.currentTimeMillis()): List<Reminder>

    @Query("SELECT * FROM reminders WHERE done = 0 ORDER BY triggerAt ASC")
    suspend fun upcoming(): List<Reminder>

    @Query("UPDATE reminders SET done = 1 WHERE id = :id")
    suspend fun markDone(id: Long)

    @Delete
    suspend fun delete(reminder: Reminder)
}

@Dao
interface MacroDao {
    @Insert
    suspend fun insert(macro: Macro): Long

    @Query("SELECT * FROM macros ORDER BY name ASC")
    suspend fun all(): List<Macro>

    @Query("SELECT * FROM macros WHERE name = :name LIMIT 1")
    suspend fun byName(name: String): Macro?

    @Delete
    suspend fun delete(macro: Macro)
}
