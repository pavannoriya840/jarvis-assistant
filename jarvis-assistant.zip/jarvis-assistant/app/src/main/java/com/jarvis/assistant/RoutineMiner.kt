package com.jarvis.assistant

import android.content.Context
import java.util.Calendar

/**
 * ROUTINE MINER — Phase C Smart Brain (lean!)
 *
 * KAIST SHIRBT-style: PURPOSE-based patterns, app-independent!
 * "Roz 9 baje payment karta hai" — WhatsApp se Telegram switch ho jaye
 * to bhi routine NAHI tootegi (app ka naam store hi nahi hota)!
 *
 * Privacy: sirf (purpose, hour) counts — content kabhi nahi!
 */
class RoutineMiner(private val context: Context) {

    private val prefs =
        context.getSharedPreferences("routine_miner", Context.MODE_PRIVATE)

    /** Ek event log karo. purpose: "payment", "chatting", "music", "alarm"... */
    fun log(purpose: String) {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val key = "${purpose.lowercase()}@$hour"
        prefs.edit().putInt(key, prefs.getInt(key, 0) + 1).apply()
    }

    /** Kya ye purpose abhi (±1hr) routine hai? 3+ repeats = routine! */
    fun isRoutineNow(purpose: String): Boolean {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        var total = 0
        for (h in hour - 1..hour + 1) {
            total += prefs.getInt("${purpose.lowercase()}@$h", 0)
        }
        return total >= 3
    }

    /** Abhi ke time ki saari strong routines */
    fun routinesNow(): List<String> {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val seen = mutableSetOf<String>()
        for (key in prefs.all.keys) {
            val purpose = key.substringBefore("@")
            if (purpose.isNotBlank() && isRoutineNow(purpose)) seen.add(purpose)
        }
        return seen.toList()
    }
}
