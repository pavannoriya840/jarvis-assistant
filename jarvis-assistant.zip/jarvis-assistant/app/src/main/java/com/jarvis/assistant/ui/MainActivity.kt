package com.jarvis.assistant.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.jarvis.assistant.AppUsageTracker
import com.jarvis.assistant.AutonomousService
import com.jarvis.assistant.JarvisAccessibilityService
import com.jarvis.assistant.JarvisBrain
import com.jarvis.assistant.OpenWakeWordManager
import com.jarvis.assistant.ProactiveEngine
import com.jarvis.assistant.PromptManager
import com.jarvis.assistant.VoiceManager
import com.jarvis.assistant.WakeWordManager
import com.jarvis.assistant.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

/**
 * Main screen: bada mic button, conversation log, status.
 * Bolna hai to mic dabao → bolo → Jarvis jawab dega.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var brain: JarvisBrain
    private var voice: VoiceManager? = null
    private var wakeWord: WakeWordManager? = null // Picovoice (optional, needs key)
    private var openWakeWord: OpenWakeWordManager? = null // FREE, no account! (default)
    private var proactive: ProactiveEngine? = null

    companion object {
        private const val REQ_AUDIO = 100
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        brain = JarvisBrain(this)
        brain.onSpeak = { text ->
            appendChat("Jarvis", text)
            voice?.speak(text) { runOnUiThread { binding.statusText.text = "Taiyaar" } }
        }
        brain.onStatus = { runOnUiThread { binding.statusText.text = it } }
        brain.onAction = { action ->
            when {
                action == "open_settings" -> startActivity(Intent(this, SettingsActivity::class.java))
                action.startsWith("recording:") -> runOnUiThread {
                    binding.statusText.text = if (action == "recording:stop") "Taiyaar" else "🔴 Recording: ${action.removePrefix("recording:")}"
                }
            }
        }

        voice = VoiceManager(
            this,
            onResult = { heard ->
                appendChat("Tum", heard)
                brain.handleCommand(heard)
            },
            onError = { err ->
                runOnUiThread {
                    binding.statusText.text = "Taiyaar"
                    Toast.makeText(this, err, Toast.LENGTH_SHORT).show()
                }
            }
        )

        binding.micButton.setOnClickListener {
            if (checkAudioPermission()) {
                binding.statusText.text = "Sun raha hun..."
                voice?.startListening()
            }
        }

        binding.sendButton.setOnClickListener {
            val text = binding.inputText.text.toString().trim()
            if (text.isNotEmpty()) {
                binding.inputText.text.clear()
                appendChat("Tum", text)
                brain.handleCommand(text)
            }
        }

        binding.settingsButton.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.macroButton.setOnClickListener {
            startActivity(Intent(this, MacroActivity::class.java))
        }

        binding.accessibilityButton.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Jarvis ko enable karo!", Toast.LENGTH_LONG).show()
        }

        // Proactive engine: sahi time pe suggestions
        proactive = ProactiveEngine(this) { suggestion ->
            appendChat("Jarvis 💡", suggestion)
            voice?.speak(suggestion)
        }

        // Wake word: "Hey Jarvis" bolte hi mic on
        // DEFAULT: OpenWakeWord (FREE, koi account/key nahi chahiye!)
        openWakeWord = OpenWakeWordManager(this) {
            runOnUiThread {
                binding.statusText.text = "Haan? Sun raha hun... 🎤"
                voice?.speak("Haan?") { voice?.startListening() }
            }
        }
        if (checkAudioPermission()) {
            Thread {
                val ok = openWakeWord?.start() ?: false
                runOnUiThread {
                    if (ok) appendChat("Jarvis", "👂 Wake word ON hai — 'Hey Jarvis' bolo, main jag jaunga!")
                }
            }.start()
        }

        // OPTIONAL: Picovoice (agar kabhi key mile to) — default OFF
        // wakeWord = WakeWordManager(this) { ... }
        // wakeWord?.start()

        checkFirstRun()

        // Thodi der baad proactive check
        binding.root.postDelayed({
            proactive?.check()
        }, 3000)

        // Autonomous mode toggle
        binding.autonomousSwitch.isChecked = AutonomousService.isEnabled(this)
        binding.autonomousSwitch.setOnCheckedChangeListener { _, checked ->
            AutonomousService.setEnabled(this, checked)
            if (checked) {
                appendChat("Jarvis 🧠", "Autonomous mode ON! Ab main har 45 min me khud sochunga aur kaam karunga. Risky kaam se pehle tumse puchunga. Notifications ka access do taaki OTP aur important alerts pakad sakun!")
                // Notification access mangao
                startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
                // Usage access (routine learning ke liye)
                if (!AppUsageTracker(this).hasPermission()) {
                    Toast.makeText(this, "Usage access bhi ON karo — routine learning ke liye!", Toast.LENGTH_LONG).show()
                    AppUsageTracker(this).openSettings()
                }
            } else {
                appendChat("Jarvis", "Autonomous mode OFF. Ab sirf bolne pe kaam karunga.")
            }
        }
    }

    private fun checkFirstRun() {
        lifecycleScope.launch {
            val key = PromptManager(this@MainActivity).getApiKey()
            if (key.isBlank()) {
                appendChat("Jarvis", "Namaste! Main Jarvis hun. Pehle Settings me apni Gemini API key daalo (aistudio.google.com se free me milti hai), phir hum baat karenge!")
            } else {
                appendChat("Jarvis", "Wapas aane pe khushi hui! Bolo, kya karun?")
            }
            updateAccessibilityStatus()
        }
    }

    private fun updateAccessibilityStatus() {
        val enabled = JarvisAccessibilityService.isEnabled()
        binding.accessibilityStatus.text =
            if (enabled) "✅ Screen control ON" else "⚠️ Screen control OFF — enable karo"
    }

    override fun onResume() {
        super.onResume()
        updateAccessibilityStatus()
    }

    private fun appendChat(who: String, text: String) {
        runOnUiThread {
            binding.chatLog.append("\n$who: $text\n")
            binding.chatScroll.post { binding.chatScroll.fullScroll(android.view.View.FOCUS_DOWN) }
        }
    }

    private fun checkAudioPermission(): Boolean {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), REQ_AUDIO)
            return false
        }
        return true
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_AUDIO && res.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            binding.micButton.performClick()
        }
    }

    override fun onDestroy() {
        voice?.destroy()
        wakeWord?.stop()
        openWakeWord?.stop()
        brain.destroy()
        super.onDestroy()
    }
}
