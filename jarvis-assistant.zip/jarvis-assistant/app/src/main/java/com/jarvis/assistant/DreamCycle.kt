package com.jarvis.assistant

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.jarvis.assistant.data.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * DREAM CYCLE 🌙 — ULTRAGOD LEVEL!
 *
 * Jab tum so rahe ho (raat 3 baje, phone charging pe),
 * Jarvis "sapne dekhta" hai:
 *
 * 1. 🧹 MEMORY CLEANUP — bekar purani memories delete
 * 2. 📚 SKILL REVIEW — kharab skills (low success rate) hatao
 * 3. 📓 MISTAKE REVIEW — galtiyon se final seekh nikalo
 * 4. ☀️ TOMORROW PREP — kal ka plan banao, briefing taiyaar karo
 * 5. 🔮 RULE CHECK — purane rules abhi bhi relevant hain?
 *
 * Subah utho → Jarvis bolega: "Good morning! Raat ko maine ye seekha,
 * aaj ka plan ye hai!"
 */
class DreamWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            Log.d("DreamCycle", "🌙 Dream shuru...")
            val db = AppDatabase.get(applicationContext)
            val report = mutableListOf<String>()

            // 1. Memory cleanup
            val monthAgo = System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000
            db.memoryDao().pruneWeak(monthAgo)
            report.add("Purani bekar memories saaf ki")

            // 2. Skill review — kharab skills hatao
            db.skillDao().pruneBad()
            val skills = db.skillDao().all()
            report.add("${skills.size} skills healthy hain")

            // 3. Pending approvals saaf karo (24h purane)
            db.approvalDao().prune(System.currentTimeMillis() - 24 * 60 * 60 * 1000)

            // 4. Kal ki taiyaari — Gemini se
            val apiKey = PromptManager(applicationContext).getApiKey()
            if (apiKey.isNotBlank()) {
                val mm = MemoryManager(applicationContext)
                val memories = mm.recallBlock(20)
                val reminders = db.reminderDao().upcoming().take(5)
                val reminderTitles = reminders.joinToString { r -> r.title }

                val client = GeminiClient(apiKey)
                val briefing = client.chat(
                    """Tum Jarvis ho. Raat ke 3 baje "dream" kar rahe ho.
                       Kal ke liye user ki briefing taiyaar karo (subah 8 baje bologi).
                       Memories: $memories
                       Pending reminders: $reminderTitles
                       
                       3-4 line me: (1) aaj kya seekha, (2) kal kya important hai, (3) ek smart suggestion.
                       Warm aur concise likho, Hinglish me.""",
                    "", "Kal ki briefing banao:"
                ).getOrNull()

                if (!briefing.isNullOrBlank()) {
                    // Briefing ko kal subah ke liye save karo
                    mm.remember("fact", "Morning briefing (ready): ${briefing.take(300)}", importance = 9)
                    report.add("Kal ki briefing taiyaar!")
                }

                // 5. Mistake consolidation
                val mistakes = db.memoryDao().byCategory("learning", 10)
                if (mistakes.size >= 3) {
                    val consolidated = client.chat(
                        """Ye meri galtiyon ki list hai: ${mistakes.joinToString("; ") { it.summary }}
                           Inse 2-3 GOLDEN RULES nikalo jo mujhe hamesha yaad rakhne chahiye.
                           Short me, numbered list me.""",
                        "", "Golden rules banao:"
                    ).getOrNull()
                    if (!consolidated.isNullOrBlank()) {
                        mm.remember("learning", "Golden rules: ${consolidated.take(300)}", importance = 10)
                        report.add("Galtiyon se golden rules banaye!")
                    }
                }
            }

            Log.d("DreamCycle", "🌙 Dream complete: ${report.joinToString(", ")}")
            Result.success()
        } catch (e: Exception) {
            Log.e("DreamCycle", "Dream fail: ${e.message}")
            Result.retry()
        }
    }
}
